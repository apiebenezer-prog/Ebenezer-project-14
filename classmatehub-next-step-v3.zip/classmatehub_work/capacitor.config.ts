import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.classmatehub.rica',
  appName: 'ClassmateHub',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
