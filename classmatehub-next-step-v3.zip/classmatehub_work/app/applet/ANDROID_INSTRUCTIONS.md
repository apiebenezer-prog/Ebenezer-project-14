# Converting Classmate Hub to an Android App (.apk / .aab)

This guide provides simple, step-by-step instructions to run Classmate Hub locally, make your edits, and convert it into an Android Application.

---

## 1. Running the Project Locally

### Prerequisites
- Node.js (version 18 or newer)
- npm or yarn

### Steps
1. Unzip `classmatehub-website.zip` into a folder.
2. Open your terminal in that folder:
   ```bash
   cd classmatehub-website
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
5. Open `http://localhost:3000` in your browser.

---

## 2. Converting to an Android App (Method 1: Capacitor - Recommended)

Capacitor is the modern, official tool to wrap React Vite applications into native Android apps with full device API access.

### Step 1: Build the Web App
```bash
npm run build
```

### Step 2: Install Capacitor
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
```

### Step 3: Initialize Capacitor
```bash
npx cap init "Classmate Hub" "com.classmatehub.app" --web-dir dist
```

### Step 4: Add the Android Platform
```bash
npx cap add android
```

### Step 5: Sync Web Code into Android Project
```bash
npx cap sync
```

### Step 6: Open in Android Studio & Generate APK
```bash
npx cap open android
```
- In Android Studio:
  - Click **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
  - Your installable `.apk` file will be generated in `android/app/build/outputs/apk/debug/app-debug.apk`!
  - You can install this directly onto any Android phone or tablet.

---

## 3. Converting to an Android App (Method 2: Google Bubblewrap PWA to APK)

Classmate Hub is already configured as a Progressive Web App (PWA) with a `manifest.json` and service worker (`sw.js`). You can turn it into an official Google Play Store Android APK using Google's Bubblewrap tool:

```bash
# Install Google Bubblewrap CLI
npm install -g @bubblewrap/cli

# Initialize APK from your live URL
bubblewrap init --manifest https://ais-pre-6sdv2e5x6rjxiigales5q4-11884513737.europe-west2.run.app/manifest.json

# Build the Android APK
bubblewrap build
```

---

## 4. Key Files to Customize
- `src/App.tsx`: Main app routing, state, and Firebase live listeners.
- `src/components/`:
  - `Navbar.tsx`: Top header, school logo, data saver mode, and profile menu.
  - `Chat/`: General discussion channel and WhatsApp-style Direct Messages.
  - `CloudLocker/`: Cloud files, lecture notes, past questions, and locker storage.
  - `AcademicVault/`: Grade 11 courses, schedules, and assignment submissions.
  - `Auth/`: Student login, registration, and role management.
- `public/manifest.json`: Android app name, icons, background colors, and orientation.
- `public/icon-512.png` & `public/icon-192.png`: Android launcher icons.
