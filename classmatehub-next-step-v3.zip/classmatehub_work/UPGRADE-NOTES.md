# ClassmateHub upgrade notes

This update intentionally preserves the existing React + TypeScript application, its RICA identity, Firebase integration, Gemini AI endpoints, and current feature components.

## Improvements included

- Updated the PWA manifest to identify the installable app as ClassmateHub while retaining the 11 Graders OF RICA portal identity and existing launch shortcuts.
- Improved global mobile/tablet behavior with safe-area support, touch-friendly interaction, visible keyboard focus, and reduced-motion accessibility support.
- Kept browser zoom enabled for accessibility.
- Reworked the service worker cache version and behavior: app shell and same-origin static assets can be cached; API and cross-origin Firebase requests are deliberately not intercepted or cached; the app shell is used as a navigation fallback when offline.
- Updated installation copy to distinguish cached application resources from live cloud features, which require connectivity.
- Added a clipboard fallback when secure clipboard access is unavailable.

## Important behavior notes

- A PWA is installed from the hosted HTTPS website; the website does not itself bundle all user data onto a different phone.
- Users sign in on each device. Shared messages, accounts, assignments, and files require the configured Firebase/backend services and network access.
- iPhone installation is done through Safari's Share menu → Add to Home Screen. Android and Windows installation options depend on the browser and PWA eligibility.
- Offline support is for the app shell and eligible static assets. It does not promise offline live chat, AI requests, or cloud file synchronization.

## Validation status

- `public/manifest.json` parses as valid JSON.
- `public/sw.js` passes Node's JavaScript syntax check.
- A full Vite/TypeScript production build could not be run in this environment because dependency installation timed out. Run `npm install` (or the project's supported Bun install) and then `npm run build` before deploying.

## Before publishing

1. Confirm the Firebase project's authorized domains include the production host.
2. Confirm Firestore rules are appropriate for the school's actual users and roles.
3. Set `GEMINI_API_KEY` as a server-side environment secret; do not put it in client-side source.
4. Deploy over HTTPS and test sign-in, chat, file upload/download, AI assistance, and installation on Android, Windows, and iPhone.

## Follow-up responsive polish

- Updated the app shell to use dynamic viewport sizing and prevent horizontal overflow on mobile browsers.
- Added global safe-area, touch, keyboard-focus, reduced-motion, form-zoom, and standalone-display refinements without replacing existing component behavior.
- Added browser metadata for dark color-scheme and telephone-number detection.

## Verification boundary

- Re-checked `public/manifest.json` as valid JSON and `public/sw.js` with Node's syntax checker.
- The complete production build and live Firebase/Gemini flows remain unverified because dependencies are not installed in this workspace and deployment is currently rate-limited. Do not treat these changes as a production-tested release until `npm install`, `npm run lint`, and `npm run build` succeed and the app's real accounts/services are tested.


## Repeatable release checks

Run `npm run check:pwa` to validate the PWA manifest, referenced icons, registration snippet, service-worker API/cross-origin exclusions, and offline navigation fallback without installing dependencies. This is a focused release check, not a substitute for `npm run lint`, `npm run build`, or live-service testing.

## Build and deployment checklist

1. Install dependencies with `npm install` or the package manager used by the project.
2. Run `npm run check:pwa`, `npm run lint`, and `npm run build`.
3. Configure production environment variables on the hosting service; never commit real API keys.
4. Confirm Firebase authorized domains and review Firestore security rules for the school's intended roles.
5. Test account creation/login, role permissions, class chat, direct messages, assignments, polls, file upload/download, and Gemini-powered study assistance with real test accounts.
6. Serve the app over HTTPS and test installation on Android Chrome, desktop Chrome/Edge on Windows, and Safari on iPhone.
7. Verify offline shell behavior separately from online features; chat, cloud data, and AI calls require connectivity.

## Latest hardening follow-up (2026-10-24)

- Poll option IDs are now stored separately on each new/seeded poll so Firestore rules can validate selected options. Vote writes require a server timestamp, and votes cannot be changed after a poll is closed.
- Poll creation/deletion no longer updates the local list before Firestore confirms the write. Poll-management actions now surface errors instead of silently failing; moderator/admin controls are shown for real accounts marked as authorized in the profile.
- AI API routes now have process-local request throttling and input-size bounds to reduce oversized requests and accidental spending spikes.
- The dependency-free release checker validates the latest poll metadata/rule requirements and AI request guards.

## Do not mistake static checks for release certification

The current archive has passed PWA and TypeScript syntax checks, but a full dependency install, type-check, production bundle, Firebase Emulator test suite, and live backend integration pass remain outstanding. Existing polls lacking `optionIds` require authorized migration. Also, current poll-vote documents are readable to signed-in classmates for client-side aggregation, so the vote records should not be described as anonymous. The process-local AI limiter is a first guard only and should be replaced or supplemented with verified Firebase identity and shared production rate limiting.
