import React, { useState, useRef, useEffect, useMemo } from 'react';
import Markdown from 'react-markdown';
import { 
  Sparkles, 
  Send, 
  Bot, 
  User, 
  Trash2, 
  Copy, 
  Check, 
  Code, 
  Volume2,
  VolumeX,
  RotateCcw,
  ThumbsUp,
  ThumbsDown,
  Zap, 
  Cpu,
  GraduationCap,
  Filter,
  Plus,
  MessageSquare,
  PanelLeft,
  PanelLeftClose,
  Edit3,
  Search,
  Share2,
  X,
  Clock
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../lib/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  limit 
} from 'firebase/firestore';
import { AIChatSession, AIChatMessage } from '../../types';

const chatSessionsStorageKey = (uid?: string) => `classmate_ai_chat_sessions_v2_${uid || 'guest'}`;
const activeSessionStorageKey = (uid?: string) => `classmate_ai_active_session_id_${uid || 'guest'}`;

// Custom code block with language header and copy button
const CodeBlock: React.FC<{ language?: string; code: string }> = ({ language, code }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="my-3 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 font-mono text-xs shadow-md">
      <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-900/90 border-b border-slate-800/80 text-slate-400 text-[11px]">
        <div className="flex items-center gap-1.5 font-medium text-slate-300">
          <Code className="w-3.5 h-3.5 text-purple-400" />
          <span className="font-semibold text-purple-300 uppercase tracking-wider text-[10px]">
            {language || 'code'}
          </span>
        </div>
        <button
          type="button"
          onClick={handleCopy}
          className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors cursor-pointer px-2 py-0.5 rounded hover:bg-slate-800"
          title="Copy code"
        >
          {copied ? (
            <>
              <Check className="w-3 h-3 text-emerald-400" />
              <span className="text-emerald-400 text-[10px] font-bold">Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3 text-slate-400" />
              <span className="text-[10px]">Copy code</span>
            </>
          )}
        </button>
      </div>
      <pre className="p-3.5 overflow-x-auto text-slate-200 text-xs leading-relaxed selection:bg-purple-900/50">
        <code>{code}</code>
      </pre>
    </div>
  );
};

const createDefaultWelcomeMessage = (): AIChatMessage => ({
  id: `welcome-${Date.now()}`,
  role: 'assistant',
  content: `### 🎓 Classmate AI Problem Solver
**Mode:** Plain-English Explanations • Step-by-Step Human Reasoning

Ask me any homework problem, math equation, biology topic, or assignment. I explain everything in **plain, simple language that any human can easily understand**:

- **🎯 Direct Answer First**: The bottom-line answer right at the top.
- **💡 The Simple Idea**: Clear, intuitive explanation in plain English without confusing academic jargon.
- **🪜 Step-by-Step in Plain Words**: What clues we have, which rule connects them, and how the calculation works line by line.
- **✍️ What to Write in Your Notebook**: A clean, ready-to-copy summary you can write directly onto paper!

*Type your question below or click any of the problem starters!*`,
  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  modelUsed: 'gemini-2.5-flash (Plain-English Solver)'
});

const createNewSession = (userId?: string, initialPrompt?: string): AIChatSession => {
  const id = `chat-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const title = initialPrompt 
    ? (initialPrompt.length > 38 ? initialPrompt.substring(0, 35) + '...' : initialPrompt)
    : 'New Chat';
  
  return {
    id,
    userId: userId || 'student',
    title,
    subject: 'All',
    persona: 'solver',
    messages: [createDefaultWelcomeMessage()],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
};

export const AIStudyAssistant: React.FC = () => {
  const { userProfile } = useAuth();
  
  // Sessions State
  const [sessions, setSessions] = useState<AIChatSession[]>(() => {
    try {
      const cached = localStorage.getItem(chatSessionsStorageKey(userProfile?.uid));
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {}
    return [createNewSession(userProfile?.uid)];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(() => {
    try {
      const cachedId = localStorage.getItem(activeSessionStorageKey(userProfile?.uid));
      if (cachedId) return cachedId;
    } catch (e) {}
    return sessions[0]?.id || '';
  });

  // UI State
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchFilter, setSearchFilter] = useState('');
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [feedbackState, setFeedbackState] = useState<Record<string, 'up' | 'down'>>({});
  const [shareNotice, setShareNotice] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Active Session Reference
  const activeSession = useMemo(() => {
    return sessions.find(s => s.id === activeSessionId) || sessions[0] || null;
  }, [sessions, activeSessionId]);

  const messages = activeSession?.messages || [];
  const systemPersona = activeSession?.persona || 'solver';
  const subjectContext = activeSession?.subject || 'All';

  // Ensure activeSessionId is valid
  useEffect(() => {
    if (sessions.length > 0 && !sessions.some(s => s.id === activeSessionId)) {
      setActiveSessionId(sessions[0].id);
    }
  }, [sessions, activeSessionId]);

  // Isolate cached study history per signed-in account on shared devices.
  useEffect(() => {
    const uid = userProfile?.uid || 'guest';
    try {
      const cached = localStorage.getItem(chatSessionsStorageKey(uid));
      const parsed = cached ? JSON.parse(cached) : [];
      const owned = Array.isArray(parsed) ? parsed.filter((session: AIChatSession) =>
        !session.userId || session.userId === uid
      ) : [];
      const nextSessions = owned.length ? owned : [createNewSession(uid)];
      setSessions(nextSessions);
      const savedActiveId = localStorage.getItem(activeSessionStorageKey(uid));
      setActiveSessionId(savedActiveId && nextSessions.some(session => session.id === savedActiveId)
        ? savedActiveId : nextSessions[0].id);
    } catch (e) {
      setSessions([createNewSession(uid)]);
    }
  }, [userProfile?.uid]);

  // Persist sessions to localStorage
  useEffect(() => {
    try {
      const uid = userProfile?.uid || 'guest';
      const ownedSessions = sessions.filter(session => !session.userId || session.userId === uid);
      if (ownedSessions.length > 0) {
        localStorage.setItem(chatSessionsStorageKey(uid), JSON.stringify(ownedSessions));
      }
      if (activeSessionId) {
        localStorage.setItem(activeSessionStorageKey(userProfile?.uid), activeSessionId);
      }
    } catch (e) {}
  }, [sessions, activeSessionId]);

  // Listen to Firestore for remote sessions synchronization
  useEffect(() => {
    const uid = userProfile?.uid;
    if (!uid || uid.startsWith('demo-') || uid.startsWith('local-')) return;
    try {
      const q = query(collection(db, 'ai_chats'), where('userId', '==', uid), limit(40));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const remoteSessions: AIChatSession[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as AIChatSession;
            if (data && data.id) {
              remoteSessions.push(data);
            }
          });

          if (remoteSessions.length > 0) {
            setSessions((prev) => {
              // Merge remote with local, preferring the one with newer updatedAt
              const map = new Map<string, AIChatSession>();
              prev.forEach(s => map.set(s.id, s));
              remoteSessions.forEach(rs => {
                const existing = map.get(rs.id);
                if (!existing || new Date(rs.updatedAt || 0) >= new Date(existing.updatedAt || 0)) {
                  map.set(rs.id, rs);
                }
              });
              const merged = Array.from(map.values()).sort((a, b) => 
                new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime()
              );
              return merged;
            });
          }
        }
      }, (err) => {
        console.warn('Firestore ai_chats sync notice:', err);
      });
      return () => unsubscribe();
    } catch (e) {
      console.warn('Firestore ai_chats listener error:', e);
    }
  }, [userProfile?.uid]);

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, isLoading]);

  // Clean up speech synthesis on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Helper to save session to Firestore and local state
  const saveSessionToCloudAndState = async (updatedSession: AIChatSession) => {
    setSessions((prev) => {
      const idx = prev.findIndex(s => s.id === updatedSession.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = updatedSession;
        return next;
      }
      return [updatedSession, ...prev];
    });

    try {
      await setDoc(doc(db, 'ai_chats', updatedSession.id), updatedSession);
    } catch (e) {
      console.warn('Could not sync chat session to Firestore:', e);
    }
  };

  const handleCreateNewChat = () => {
    const newSess = createNewSession(userProfile?.uid);
    setSessions(prev => [newSess, ...prev]);
    setActiveSessionId(newSess.id);
    saveSessionToCloudAndState(newSess);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const handleDeleteSession = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const remaining = sessions.filter(s => s.id !== sessionId);
    if (remaining.length === 0) {
      const fresh = createNewSession(userProfile?.uid);
      setSessions([fresh]);
      setActiveSessionId(fresh.id);
      saveSessionToCloudAndState(fresh);
    } else {
      setSessions(remaining);
      if (activeSessionId === sessionId) {
        setActiveSessionId(remaining[0].id);
      }
    }

    try {
      await deleteDoc(doc(db, 'ai_chats', sessionId));
    } catch (err) {}
  };

  const handleStartRename = (session: AIChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(session.id);
    setEditingTitle(session.title);
  };

  const handleSaveRename = (sessionId: string, e: React.MouseEvent | React.KeyboardEvent) => {
    e.stopPropagation();
    if (!editingTitle.trim()) {
      setEditingSessionId(null);
      return;
    }
    const target = sessions.find(s => s.id === sessionId);
    if (target) {
      const updated: AIChatSession = {
        ...target,
        title: editingTitle.trim(),
        updatedAt: new Date().toISOString()
      };
      saveSessionToCloudAndState(updated);
    }
    setEditingSessionId(null);
  };

  const handleUpdatePersona = (persona: 'solver' | 'coder' | 'professor' | 'exam_prep' | 'socratic') => {
    if (!activeSession) return;
    const updated: AIChatSession = {
      ...activeSession,
      persona,
      updatedAt: new Date().toISOString()
    };
    saveSessionToCloudAndState(updated);
  };

  const handleUpdateSubject = (subject: string) => {
    if (!activeSession) return;
    const updated: AIChatSession = {
      ...activeSession,
      subject,
      updatedAt: new Date().toISOString()
    };
    saveSessionToCloudAndState(updated);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const queryText = textToSend || inputText;
    if (!queryText.trim() || isLoading || !activeSession) return;

    const userMessage: AIChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: queryText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const isFirstUserMessage = activeSession.messages.filter(m => m.role === 'user').length === 0;
    let newTitle = activeSession.title;
    if (isFirstUserMessage || activeSession.title === 'New Chat') {
      newTitle = queryText.length > 40 ? queryText.substring(0, 36) + '...' : queryText;
    }

    const updatedMessages = [...activeSession.messages, userMessage];
    const sessionWithUserMsg: AIChatSession = {
      ...activeSession,
      title: newTitle,
      messages: updatedMessages,
      updatedAt: new Date().toISOString()
    };

    // Update state immediately
    await saveSessionToCloudAndState(sessionWithUserMsg);
    setInputText('');
    setIsLoading(true);

    try {
      const turns = updatedMessages
        .filter(m => !m.id.startsWith('welcome-'))
        .map(m => ({
          role: m.role === 'assistant' ? 'assistant' : 'user',
          text: m.content
        }));

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: turns,
          prompt: queryText,
          persona: systemPersona,
          subject: subjectContext !== 'All' ? subjectContext : undefined
        })
      });

      const data = await res.json();

      let assistantContent = '';
      let modelUsed = 'gemini-2.5-flash (Plain-English Solver)';

      if (data.success && data.result) {
        assistantContent = data.result;
        modelUsed = data.model || modelUsed;
      } else {
        assistantContent = `### ⚠️ Notice\n\n${data.error || 'Temporary connectivity hiccup. Please re-send your question.'}`;
      }

      const aiMessage: AIChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: assistantContent,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed
      };

      const finalSession: AIChatSession = {
        ...sessionWithUserMsg,
        messages: [...updatedMessages, aiMessage],
        updatedAt: new Date().toISOString()
      };

      await saveSessionToCloudAndState(finalSession);
    } catch (err: any) {
      const fallbackAiMsg: AIChatMessage = {
        id: `ai-err-${Date.now()}`,
        role: 'assistant',
        content: '### ⚠️ Network Disconnected\nUnable to reach AI gateway. Please verify your connection and try again.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      const finalSession: AIChatSession = {
        ...sessionWithUserMsg,
        messages: [...updatedMessages, fallbackAiMsg],
        updatedAt: new Date().toISOString()
      };
      await saveSessionToCloudAndState(finalSession);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleCopyMessage = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShareTranscript = () => {
    if (!activeSession) return;
    const transcript = activeSession.messages.map(m => 
      `### ${m.role === 'user' ? 'Student' : 'AI Plain-English Solver'} (${m.timestamp}):\n${m.content}\n`
    ).join('\n---\n\n');
    navigator.clipboard.writeText(transcript);
    setShareNotice(true);
    setTimeout(() => setShareNotice(false), 2500);
  };

  const handleSpeak = (text: string, id: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanText = text
      .replace(/###|\*\*|`|_/g, '')
      .replace(/\[.*?\]/g, '')
      .replace(/https?:\/\/\S+/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleFeedback = (id: string, type: 'up' | 'down') => {
    setFeedbackState(prev => ({
      ...prev,
      [id]: prev[id] === type ? (null as any) : type
    }));
  };

  const handleClearCurrentSession = () => {
    if (!activeSession) return;
    const resetSession: AIChatSession = {
      ...activeSession,
      messages: [createDefaultWelcomeMessage()],
      updatedAt: new Date().toISOString()
    };
    saveSessionToCloudAndState(resetSession);
  };

  // Filtered Sessions for Search
  const filteredSessions = useMemo(() => {
    if (!searchFilter.trim()) return sessions;
    const term = searchFilter.toLowerCase();
    return sessions.filter(s => s.title.toLowerCase().includes(term));
  }, [sessions, searchFilter]);

  const quickPrompts = [
    { 
      label: '🦠 Biology: 4 Virus Shapes', 
      prompt: 'Please solve this Biology assignment in plain, simple English: Describe the 4 basic shapes of a virus (Helical, Polyhedral, Enveloped, and Complex), list the labeled parts to draw in my notebook, and state the function of each part in everyday words.' 
    },
    { 
      label: '🧮 Math: Integration by Parts', 
      prompt: 'Solve step-by-step in plain English: How do I calculate the integral of x * e^(2x) dx using integration by parts? Explain what each step means in simple words, avoid unreadable raw code symbols, and give me a clear "What to write in your notebook" section.' 
    },
    { 
      label: '⚡ Physics: Crate on a Ramp', 
      prompt: 'Solve in plain, human-understandable English: A 5 kg crate slides down a 30° ramp with kinetic friction 0.20. What is its acceleration? Walk me through the forces step-by-step in plain words with a notebook-ready summary.' 
    },
    { 
      label: '🧪 Chem: Buffer pH Simply', 
      prompt: 'Explain in plain English: What is a buffer solution, and how do we calculate its pH if we have 0.15 M acetic acid and 0.20 M sodium acetate? Walk through the simple arithmetic step-by-step.' 
    },
    { 
      label: '💻 Code: Two-Sum in Simple Words', 
      prompt: 'Explain the classic Two-Sum coding problem in plain English. Provide clean Python code, explain the logic with an everyday analogy, and explain what O(N) time means in simple human words.' 
    },
    { 
      label: '🎯 Quiz: 4 High-Yield Biology Questions', 
      prompt: 'Give me 4 practice test questions about viruses, cell theory, and genetics with plain-English answer explanations and tips for my exam.' 
    }
  ];

  const subjects = ['All', 'Mathematics', 'Computer Science', 'Physics', 'Chemistry', 'Biology', 'Engineering', 'Economics'];

  return (
    <div className="flex-1 flex h-full bg-slate-950 overflow-hidden relative">
      {/* ChatGPT-Style Left History Sidebar */}
      <div 
        className={`${
          isSidebarOpen ? 'w-64 sm:w-72 border-r border-slate-800/80' : 'w-0 border-r-0'
        } transition-all duration-200 bg-slate-950/95 flex flex-col shrink-0 overflow-hidden z-20`}
      >
        {/* Sidebar Header with New Chat */}
        <div className="p-3 border-b border-slate-800/80 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-amber-400" />
              <span className="text-xs font-bold text-white tracking-tight uppercase">Chat History</span>
            </div>
            <button
              type="button"
              onClick={() => setIsSidebarOpen(false)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Close sidebar"
            >
              <PanelLeftClose className="w-4 h-4" />
            </button>
          </div>

          <button
            type="button"
            onClick={handleCreateNewChat}
            className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500/20 via-amber-400/15 to-yellow-500/10 hover:from-amber-500/30 hover:to-yellow-500/20 border border-amber-500/40 text-amber-300 font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm active:scale-98"
          >
            <Plus className="w-4 h-4 text-amber-400 stroke-[2.5]" />
            <span>New Chat</span>
          </button>

          {/* Search chats */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder="Search chat history..."
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-2.5 py-1.5 text-[11px] text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500/60"
            />
            {searchFilter && (
              <button 
                type="button" 
                onClick={() => setSearchFilter('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

        {/* Conversation List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          <div className="text-[10px] font-bold text-slate-500 uppercase px-2 py-1 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Saved Chats ({filteredSessions.length})
          </div>

          {filteredSessions.length === 0 ? (
            <div className="p-4 text-center text-slate-500 text-xs">
              No conversations found.
            </div>
          ) : (
            filteredSessions.map((sess) => {
              const isActive = sess.id === activeSessionId;
              const isEditing = editingSessionId === sess.id;

              return (
                <div
                  key={sess.id}
                  onClick={() => {
                    setActiveSessionId(sess.id);
                  }}
                  className={`group relative flex items-center justify-between px-2.5 py-2 rounded-xl text-xs cursor-pointer transition-all ${
                    isActive
                      ? 'bg-slate-800/90 text-white font-medium border border-amber-500/40 shadow-sm'
                      : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                    {isEditing ? (
                      <input
                        type="text"
                        autoFocus
                        value={editingTitle}
                        onChange={(e) => setEditingTitle(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSaveRename(sess.id, e);
                          if (e.key === 'Escape') setEditingSessionId(null);
                        }}
                        className="bg-slate-950 text-white text-xs px-1.5 py-0.5 rounded border border-amber-500/60 focus:outline-none w-full"
                        onClick={(e) => e.stopPropagation()}
                      />
                    ) : (
                      <span className="truncate text-[12px]">{sess.title}</span>
                    )}
                  </div>

                  {/* Actions (Rename & Delete) */}
                  <div className="flex items-center gap-1 shrink-0 ml-1">
                    {isEditing ? (
                      <>
                        <button
                          type="button"
                          onClick={(e) => handleSaveRename(sess.id, e)}
                          className="p-1 text-emerald-400 hover:text-emerald-300 rounded"
                          title="Save title"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingSessionId(null);
                          }}
                          className="p-1 text-slate-400 hover:text-white rounded"
                          title="Cancel"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </>
                    ) : (
                      <div className={`flex items-center gap-0.5 ${isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'} transition-opacity`}>
                        <button
                          type="button"
                          onClick={(e) => handleStartRename(sess, e)}
                          className="p-1 text-slate-400 hover:text-amber-300 rounded"
                          title="Rename chat"
                        >
                          <Edit3 className="w-3 h-3" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleDeleteSession(sess.id, e)}
                          className="p-1 text-slate-400 hover:text-rose-400 rounded"
                          title="Delete chat"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-2.5 border-t border-slate-800/80 bg-slate-950/80 text-[10px] text-slate-400 flex items-center justify-between">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
            Cloud & Local Synced
          </span>
          <span className="font-mono text-slate-400">{sessions.length} chats</span>
        </div>
      </div>

      {/* Main Conversation Screen */}
      <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
        {/* Top Chat Header */}
        <div className="p-3 md:px-5 md:py-2.5 border-b border-slate-800/80 bg-slate-900/70 backdrop-blur-md shrink-0 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-2.5 min-w-0">
            {!isSidebarOpen && (
              <button
                type="button"
                onClick={() => setIsSidebarOpen(true)}
                className="p-2 text-slate-400 hover:text-white rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
                title="Open Chat History"
              >
                <PanelLeft className="w-4 h-4" />
              </button>
            )}

            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 flex items-center justify-center shadow-md shadow-amber-500/20 border border-amber-300/40 text-slate-950 shrink-0">
              <GraduationCap className="w-4 h-4 text-slate-950 stroke-[2.3]" />
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="text-xs sm:text-sm font-bold text-white tracking-tight truncate max-w-[200px] sm:max-w-xs">
                  {activeSession?.title || 'Classmate AI Problem Solver'}
                </h1>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono font-bold border border-amber-500/30 shrink-0">
                  Plain-English
                </span>
              </div>
              <p className="text-[10px] text-slate-400 truncate">
                ChatGPT conversation history saved permanently
              </p>
            </div>
          </div>

          {/* Mode, Subject, and Actions */}
          <div className="flex items-center gap-1.5 flex-wrap justify-end">
            {/* Quick New Chat Button */}
            <button
              type="button"
              onClick={handleCreateNewChat}
              className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-400 text-xs font-semibold rounded-xl flex items-center gap-1 transition-colors cursor-pointer"
              title="Start New Chat"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              <span className="hidden sm:inline text-[11px]">New Chat</span>
            </button>

            {/* Persona Selector */}
            <div className="flex items-center bg-slate-950/90 border border-slate-800 rounded-xl p-1 text-xs">
              <span className="text-[10px] text-slate-400 font-semibold px-1">Mode:</span>
              <select
                value={systemPersona}
                onChange={(e) => handleUpdatePersona(e.target.value as any)}
                className="bg-transparent text-white text-[11px] font-medium focus:outline-none pr-1 cursor-pointer"
              >
                <option value="solver" className="bg-slate-900 text-white">🧠 Plain-English Solver</option>
                <option value="coder" className="bg-slate-900 text-white">💻 Coding & Logic</option>
                <option value="professor" className="bg-slate-900 text-white">🎓 Deep Breakdown</option>
                <option value="exam_prep" className="bg-slate-900 text-white">🎯 Exam Review</option>
                <option value="socratic" className="bg-slate-900 text-white">⚡ Guided Hints</option>
              </select>
            </div>

            {/* Subject Context */}
            <div className="hidden md:flex items-center bg-slate-950/90 border border-slate-800 rounded-xl p-1 text-xs">
              <Filter className="w-3 h-3 text-slate-400 ml-1 mr-0.5" />
              <select
                value={subjectContext}
                onChange={(e) => handleUpdateSubject(e.target.value)}
                className="bg-transparent text-white text-[11px] font-medium focus:outline-none pr-1 cursor-pointer"
              >
                {subjects.map(s => (
                  <option key={s} value={s} className="bg-slate-900 text-white">{s}</option>
                ))}
              </select>
            </div>

            {/* Share / Copy transcript */}
            <button
              type="button"
              onClick={handleShareTranscript}
              title="Copy entire chat transcript"
              className="p-1.5 text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-xl transition-colors cursor-pointer text-xs flex items-center gap-1"
            >
              <Share2 className="w-3.5 h-3.5" />
              {shareNotice && <span className="text-[10px] text-emerald-400 font-bold">Copied!</span>}
            </button>

            {/* Reset current chat */}
            <button
              type="button"
              onClick={handleClearCurrentSession}
              title="Reset this chat"
              className="p-1.5 text-slate-400 hover:text-rose-400 bg-slate-900/80 hover:bg-rose-500/10 border border-slate-800 rounded-xl transition-colors cursor-pointer text-xs"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Chat Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            const isSpeaking = speakingId === msg.id;
            const userFeedback = feedbackState[msg.id];

            return (
              <div
                key={msg.id}
                className={`flex gap-3.5 max-w-4xl ${isUser ? 'ml-auto justify-end' : 'mr-auto justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 flex items-center justify-center shrink-0 shadow-md border border-amber-300/40 text-slate-950 mt-1">
                    <GraduationCap className="w-4 h-4 text-slate-950 stroke-[2.3]" />
                  </div>
                )}

                <div className={`flex flex-col gap-1.5 max-w-[88%] sm:max-w-[85%] ${isUser ? 'items-end' : 'items-start'}`}>
                  {/* Sender title & timestamp */}
                  <div className="flex items-center gap-2 px-1">
                    <span className="text-[11px] font-semibold text-slate-400">
                      {isUser ? (userProfile?.displayName || 'You') : 'Classmate AI'}
                    </span>
                    <span className="text-[10px] text-slate-400">{msg.timestamp}</span>
                    {!isUser && msg.modelUsed && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-900 border border-slate-800 text-amber-300 font-mono">
                        Plain-English
                      </span>
                    )}
                  </div>

                  {/* Message Bubble */}
                  <div
                    className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed transition-all shadow-sm ${
                      isUser
                        ? 'bg-amber-500 text-slate-950 font-medium rounded-tr-sm selection:bg-amber-600'
                        : 'bg-slate-900/90 border border-slate-800/90 text-slate-100 rounded-tl-sm selection:bg-amber-500/20'
                    }`}
                  >
                    {isUser ? (
                      <p className="whitespace-pre-wrap font-medium">{msg.content}</p>
                    ) : (
                      <div className="prose prose-invert max-w-none text-xs sm:text-sm space-y-3">
                        <Markdown
                          components={{
                            code(props) {
                              const { children, className } = props;
                              const match = /language-(\w+)/.exec(className || '');
                              const codeString = String(children).replace(/\n$/, '');
                              return match ? (
                                <CodeBlock language={match[1]} code={codeString} />
                              ) : (
                                <code className="bg-slate-950 text-amber-300 px-1.5 py-0.5 rounded font-mono text-[11px] border border-slate-800">
                                  {children}
                                </code>
                              );
                            },
                            h1: ({ children }) => <h1 className="text-base font-bold text-white mt-3 mb-2">{children}</h1>,
                            h2: ({ children }) => <h2 className="text-sm font-bold text-amber-300 mt-3 mb-1.5 flex items-center gap-1.5">{children}</h2>,
                            h3: ({ children }) => <h3 className="text-xs sm:text-sm font-bold text-amber-400 mt-2.5 mb-1">{children}</h3>,
                            h4: ({ children }) => <h4 className="text-xs font-bold text-amber-200 mt-2 mb-1">{children}</h4>,
                            p: ({ children }) => <p className="mb-2 leading-relaxed text-slate-200">{children}</p>,
                            ul: ({ children }) => <ul className="list-disc pl-5 space-y-1 mb-2 text-slate-200">{children}</ul>,
                            ol: ({ children }) => <ol className="list-decimal pl-5 space-y-1 mb-2 text-slate-200">{children}</ol>,
                            li: ({ children }) => <li className="leading-relaxed">{children}</li>,
                            blockquote: ({ children }) => (
                              <blockquote className="border-l-2 border-amber-500 pl-3 italic text-amber-200 my-2 bg-amber-500/5 py-1 rounded-r">
                                {children}
                              </blockquote>
                            )
                          }}
                        >
                          {msg.content}
                        </Markdown>
                      </div>
                    )}

                    {/* Action Toolbar for AI responses */}
                    {!isUser && (
                      <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-800/80 text-slate-400">
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleCopyMessage(msg.content, msg.id)}
                            className="p-1.5 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1"
                            title="Copy answer"
                          >
                            {copiedId === msg.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                            <span className="text-[10px]">{copiedId === msg.id ? 'Copied!' : 'Copy'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleSpeak(msg.content, msg.id)}
                            className={`p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1 ${
                              isSpeaking ? 'text-amber-400 bg-amber-500/10' : 'hover:text-white'
                            }`}
                            title={isSpeaking ? 'Stop reading' : 'Read aloud in plain English'}
                          >
                            {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                            <span className="text-[10px]">{isSpeaking ? 'Stop' : 'Listen'}</span>
                          </button>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleFeedback(msg.id, 'up')}
                            className={`p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer ${
                              userFeedback === 'up' ? 'text-emerald-400 bg-emerald-500/10' : 'hover:text-white'
                            }`}
                            title="Helpful explanation"
                          >
                            <ThumbsUp className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleFeedback(msg.id, 'down')}
                            className={`p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer ${
                              userFeedback === 'down' ? 'text-rose-400 bg-rose-500/10' : 'hover:text-white'
                            }`}
                            title="Needs simplification"
                          >
                            <ThumbsDown className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 text-slate-300 mt-1">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3.5 max-w-3xl mr-auto items-start">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 flex items-center justify-center shrink-0 shadow-md text-slate-950">
                <GraduationCap className="w-4 h-4 animate-bounce text-slate-950" />
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-sm p-4 text-xs text-slate-300 flex items-center gap-3 shadow-md">
                <div className="flex gap-1.5 items-center">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-bounce [animation-delay:-0.3s]" />
                  <span className="w-2 h-2 rounded-full bg-yellow-400 animate-bounce [animation-delay:-0.15s]" />
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce" />
                </div>
                <span className="text-slate-300 text-xs font-medium">
                  Solving step-by-step in plain English for your notebook...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Bottom Input Section */}
        <div className="p-3 md:p-4 border-t border-slate-800/80 bg-slate-900/80 backdrop-blur-md shrink-0 space-y-2.5">
          {/* Quick problem prompt chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs no-scrollbar">
            <span className="text-[10px] uppercase font-bold text-amber-400 shrink-0 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-400" />
              Try solving:
            </span>
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(qp.prompt)}
                className="px-2.5 py-1 rounded-xl bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800 text-[11px] text-slate-300 hover:text-white transition-all shrink-0 cursor-pointer text-left"
              >
                {qp.label}
              </button>
            ))}
          </div>

          {/* Input box */}
          <div className="relative flex items-end gap-2 bg-slate-950/90 border border-slate-800 rounded-2xl p-2 focus-within:border-amber-500/80 transition-all shadow-inner">
            <textarea
              ref={textareaRef}
              id="ai-chat-input"
              rows={2}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask any homework problem, math equation, or science question in plain English... [Enter to send, Shift+Enter for newline]"
              className="flex-1 bg-transparent text-xs sm:text-sm text-white placeholder:text-slate-400 resize-none p-2 focus:outline-none max-h-32"
            />

            <button
              id="ai-send-btn"
              type="button"
              disabled={!inputText.trim() || isLoading}
              onClick={() => handleSendMessage()}
              className="p-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-bold shadow-md shadow-amber-500/25 transition-all disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer shrink-0 active:scale-95"
              title="Send Question to Plain-English Solver"
            >
              {isLoading ? <RotateCcw className="w-4 h-4 animate-spin text-slate-950" /> : <Send className="w-4 h-4 text-slate-950 stroke-[2.5]" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
