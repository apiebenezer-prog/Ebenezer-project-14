import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Timer, 
  Play, 
  Pause, 
  RotateCcw, 
  Users, 
  Headphones, 
  Sparkles, 
  Volume2, 
  Coffee, 
  Flame, 
  CheckCircle2, 
  Radio,
  Plus
} from 'lucide-react';
import { UserProfile, StudyGroup } from '../../types';

interface StudyGroupsAndTimerProps {
  studyGroups: StudyGroup[];
  allUsers: UserProfile[];
  onCreateGroup: (group: Omit<StudyGroup, 'id'>) => void;
  onJoinGroup: (groupId: string) => void;
}

export const StudyGroupsAndTimer: React.FC<StudyGroupsAndTimerProps> = ({
  studyGroups,
  allUsers,
  onCreateGroup,
  onJoinGroup
}) => {
  const { userProfile, updateUserStatus } = useAuth();
  const [timerMode, setTimerMode] = useState<'pomodoro' | 'shortBreak' | 'longBreak'>('pomodoro');
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [completedSessions, setCompletedSessions] = useState(3);
  const [activeAudioPreset, setActiveAudioPreset] = useState<'rain' | 'whitenoise' | 'lofi' | 'off'>('off');

  // Study group modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [groupTitle, setGroupTitle] = useState('');
  const [groupSubject, setGroupSubject] = useState('Algorithms');
  const [groupDesc, setGroupDesc] = useState('');

  // Handle timer countdown
  useEffect(() => {
    let interval: any = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      if (timerMode === 'pomodoro') {
        setCompletedSessions(prev => prev + 1);
        setTimeLeft(5 * 60);
        setTimerMode('shortBreak');
      } else {
        setTimeLeft(25 * 60);
        setTimerMode('pomodoro');
      }
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, timerMode]);

  const switchMode = (mode: 'pomodoro' | 'shortBreak' | 'longBreak') => {
    setIsRunning(false);
    setTimerMode(mode);
    if (mode === 'pomodoro') setTimeLeft(25 * 60);
    else if (mode === 'shortBreak') setTimeLeft(5 * 60);
    else setTimeLeft(15 * 60);
  };

  const toggleTimer = () => {
    const nextState = !isRunning;
    setIsRunning(nextState);
    if (nextState && userProfile?.status !== 'studying') {
      updateUserStatus('studying', 'Focused in Pomodoro Study Session');
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const studyingClassmates = allUsers.filter(u => u.status === 'studying');

  const handleCreateGroupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupTitle.trim()) return;

    onCreateGroup({
      title: groupTitle,
      subject: groupSubject,
      description: groupDesc || 'Active group study room for problem sets',
      members: userProfile ? [userProfile.uid] : [],
      isLive: true,
      scheduledTime: 'Active Now'
    });

    setGroupTitle('');
    setGroupDesc('');
    setShowCreateModal(false);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-y-auto">
      {/* Header */}
      <div className="p-4 md:p-6 border-b border-slate-800 bg-slate-900/50 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-600/25">
            <Timer className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-white tracking-tight">Study Hub & Live Focus Rooms</h1>
              <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold rounded-full border border-emerald-500/30">
                Live Collaboration
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Synchronized Pomodoro focus sessions, virtual study rooms, and active peer study roster
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="p-4 md:p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Pomodoro Timer & Rooms */}
        <div className="lg:col-span-2 space-y-6">
          {/* Pomodoro Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 relative overflow-hidden flex flex-col items-center justify-center text-center shadow-xl">
            {/* Ambient Background Glow */}
            <div className={`absolute inset-0 opacity-15 blur-3xl transition-colors ${
              timerMode === 'pomodoro' ? 'bg-indigo-600' : 'bg-emerald-600'
            }`} />

            {/* Mode Selectors */}
            <div className="flex items-center gap-2 p-1 bg-slate-950/80 rounded-2xl border border-slate-800 mb-6 text-xs font-semibold relative z-10">
              <button
                type="button"
                onClick={() => switchMode('pomodoro')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  timerMode === 'pomodoro' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                Focus Session (25m)
              </button>
              <button
                type="button"
                onClick={() => switchMode('shortBreak')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  timerMode === 'shortBreak' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                Short Break (5m)
              </button>
              <button
                type="button"
                onClick={() => switchMode('longBreak')}
                className={`px-4 py-2 rounded-xl transition-all ${
                  timerMode === 'longBreak' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                Long Break (15m)
              </button>
            </div>

            {/* Huge Digital Timer */}
            <div className="my-2 relative z-10">
              <div className="text-6xl md:text-8xl font-extrabold font-mono tracking-tighter text-white drop-shadow-md">
                {formatTime(timeLeft)}
              </div>
              <div className="text-xs text-slate-400 mt-2 flex items-center justify-center gap-2">
                <Flame className="w-4 h-4 text-amber-400" />
                <span><strong>{completedSessions}</strong> Focus Sessions Completed Today</span>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-4 mt-6 relative z-10">
              <button
                id="toggle-pomodoro-timer-btn"
                type="button"
                onClick={toggleTimer}
                className={`px-8 py-3.5 rounded-2xl font-bold text-sm flex items-center gap-2.5 shadow-lg transition-all active:scale-95 ${
                  isRunning 
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30' 
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
                }`}
              >
                {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-white" />}
                <span>{isRunning ? 'Pause Focus' : 'Start Focus Session'}</span>
              </button>

              <button
                id="reset-pomodoro-timer-btn"
                type="button"
                onClick={() => switchMode(timerMode)}
                title="Reset Timer"
                className="p-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Virtual Study Rooms Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">Live Virtual Study Rooms</h3>
                <p className="text-xs text-slate-400">Join a peer room or create your own topic squad</p>
              </div>
              <button
                id="create-study-room-btn"
                type="button"
                onClick={() => setShowCreateModal(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-md transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Create Study Room</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {studyGroups.map((group) => {
                const isMember = group.members.includes(userProfile?.uid || '');
                return (
                  <div
                    key={group.id}
                    id={`study-group-card-${group.id}`}
                    className="p-4 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/30">
                          {group.subject}
                        </span>
                        {group.isLive && (
                          <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                            <Radio className="w-3 h-3 animate-pulse" /> Live Room
                          </span>
                        )}
                      </div>
                      <h4 className="text-sm font-bold text-white">{group.title}</h4>
                      <p className="text-xs text-slate-400 mt-1">{group.description}</p>
                    </div>

                    <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <Users className="w-3.5 h-3.5 text-indigo-400" />
                        <span>{group.members.length} Classmates Joined</span>
                      </div>

                      <button
                        type="button"
                        onClick={() => onJoinGroup(group.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                          isMember 
                            ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/30' 
                            : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                        }`}
                      >
                        {isMember ? 'Joined ✓' : 'Join Room'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Classmates Currently Studying */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">Studying Right Now</h3>
              </div>
              <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold rounded-full">
                {studyingClassmates.length} Active
              </span>
            </div>

            <div className="space-y-2.5">
              {studyingClassmates.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">
                  No one is currently marked in study mode. Start your Pomodoro session to lead the study wave!
                </p>
              ) : (
                studyingClassmates.map((student) => (
                  <div
                    key={student.uid}
                    className="p-2.5 bg-slate-950/60 border border-slate-800/80 rounded-xl flex items-center gap-3"
                  >
                    <div className="relative">
                      <img
                        src={student.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${student.uid}`}
                        alt={student.displayName}
                        className="w-8 h-8 rounded-lg object-cover bg-slate-800"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-500 border border-slate-950" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-semibold text-white truncate">{student.displayName}</div>
                      <div className="text-[10px] text-emerald-400 truncate">
                        {student.customStatusMessage || 'Focused Study'}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Create Study Room Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-white">Create Virtual Study Room</h3>

            <form onSubmit={handleCreateGroupSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Room Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Chapter 5 Algorithms Marathon"
                  value={groupTitle}
                  onChange={(e) => setGroupTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Subject</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Algorithms"
                  value={groupSubject}
                  onChange={(e) => setGroupSubject(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Description / Topic</label>
                <textarea
                  rows={3}
                  placeholder="What is this study squad reviewing?"
                  value={groupDesc}
                  onChange={(e) => setGroupDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl"
                >
                  Launch Room
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
