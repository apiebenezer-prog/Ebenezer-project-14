import React, { useState, useEffect } from 'react';
import { SchoolLogo } from '../SchoolLogo';
import { 
  Smartphone, 
  Monitor, 
  Download, 
  Share, 
  PlusSquare, 
  CheckCircle2, 
  Sparkles, 
  X, 
  Copy, 
  Check, 
  ExternalLink,
  Info,
  ShieldCheck
} from 'lucide-react';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [detectedPlatform, setDetectedPlatform] = useState<'android' | 'ios' | 'desktop'>('android');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);
  const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

  useEffect(() => {
    // Detect OS / Platform
    const userAgent = navigator.userAgent || navigator.vendor || (window as any).opera;
    if (/iPad|iPhone|iPod/.test(userAgent) && !(window as any).MSStream) {
      setDetectedPlatform('ios');
    } else if (/android/i.test(userAgent)) {
      setDetectedPlatform('android');
    } else {
      setDetectedPlatform('desktop');
    }

    // Check if already installed in true standalone mode (outside iframe)
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true;
    if (isStandalone && !isInIframe) {
      setIsInstalled(true);
    }

    // Listen for Chrome/Edge install prompt
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  if (!isOpen) return null;

  const currentDirectUrl = window.location.href;
  const shareMessage = `📚 11 Graders OF RICA - Official Campus Study & Cloud Locker Portal\nJoin our class study group, shared cloud locker, and real-time chat:\n${currentDirectUrl}`;

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(currentDirectUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2500);
    } catch {
      window.prompt('Copy the ClassmateHub link:', currentDirectUrl);
    }
  };

  const handleShareApp = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: '11 Graders OF RICA',
          text: '📚 Join 11 Graders OF RICA - Official Campus Study & Cloud Locker Portal for our class:',
          url: currentDirectUrl,
        });
        return;
      } catch (err) {
        // Fallback to clipboard
      }
    }
    try {
      await navigator.clipboard.writeText(shareMessage);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2500);
    } catch {
      window.prompt('Copy this message to share ClassmateHub:', shareMessage);
    }
  };

  const handleNativeInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        id="install-modal-container"
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden max-h-[90vh] flex flex-col"
      >
        <button
          id="close-install-modal"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-xl bg-slate-800/60 hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4 shrink-0">
          <SchoolLogo size="lg" showRing={true} />
          <div>
            <div className="flex flex-col">
              <h2 className="text-lg font-extrabold text-white tracking-tight font-['Outfit',sans-serif] leading-tight">
                11 Graders
              </h2>
              <span className="text-amber-400 font-['Cinzel',serif] tracking-widest text-xs font-bold leading-tight drop-shadow-[0_0_8px_rgba(251,191,36,0.3)]">
                OF RICA
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">Install & share the official ClassmateHub portal</p>
          </div>
        </div>

        {/* Platform Selector */}
        <div className="flex items-center gap-1 p-1 bg-slate-950/80 rounded-2xl border border-slate-800 mb-4 text-xs font-medium shrink-0">
          <button
            type="button"
            onClick={() => setDetectedPlatform('android')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl transition-all cursor-pointer ${detectedPlatform === 'android' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Samsung & Android</span>
          </button>
          <button
            type="button"
            onClick={() => setDetectedPlatform('ios')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl transition-all cursor-pointer ${detectedPlatform === 'ios' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>iPhone / iPad</span>
          </button>
          <button
            type="button"
            onClick={() => setDetectedPlatform('desktop')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl transition-all cursor-pointer ${detectedPlatform === 'desktop' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>PC & Mac</span>
          </button>
        </div>

        <div className="overflow-y-auto space-y-4 pr-1 flex-1">
          {isInIframe && (
            <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-xs space-y-2.5">
              <div className="flex items-center gap-2 text-amber-300 font-bold">
                <Info className="w-4 h-4 shrink-0" />
                <span>Why it didn't appear on your Home Screen yet:</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Mobile browsers (Chrome, Samsung Internet, and Safari) <strong>block web previews and iframes</strong> from installing directly to your phone's launcher for security.
              </p>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                To put the real <strong>11 Graders OF RICA</strong> icon on your phone's home screen, tap <strong>"Open Direct App"</strong> below, then use your browser's menu to install:
              </p>
              <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
                <a
                  href={currentDirectUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:flex-1 py-2.5 px-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer text-center"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Open Direct App in Chrome / Browser</span>
                </a>
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="w-full sm:w-auto py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'Copied Link!' : 'Copy Link'}</span>
                </button>
              </div>
            </div>
          )}

          {isInstalled ? (
            <div className="p-5 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-center space-y-2">
              <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-emerald-300">11 Graders OF RICA Is Installed!</h3>
              <p className="text-xs text-slate-300">
                You are running ClassmateHub as an installed app. Cached app resources may open offline; live chat, cloud files, and account sync need an internet connection.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {detectedPlatform === 'android' && (
                <div className="space-y-3.5 p-4 bg-slate-950/70 border border-slate-800 rounded-2xl text-xs text-slate-300">
                  <div className="font-semibold text-white text-sm flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-emerald-400" />
                      <span>Installing on Samsung Galaxy (S26 Ultra / Android)</span>
                    </div>
                  </div>

                  {deferredPrompt && (
                    <button
                      id="trigger-android-pwa-install"
                      type="button"
                      onClick={handleNativeInstall}
                      className="w-full py-3 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-semibold rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 cursor-pointer active:scale-95 transition-all"
                    >
                      <Download className="w-4 h-4" />
                      <span>Install ClassmateHub on Android</span>
                    </button>
                  )}

                  <div className="space-y-3 pt-1">
                    <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 space-y-1.5">
                      <div className="font-bold text-white text-xs text-emerald-400">Method A: Using Google Chrome on Galaxy</div>
                      <ol className="space-y-1.5 list-decimal list-inside text-[11px] text-slate-300">
                        <li>Open the app URL in <strong>Chrome</strong>.</li>
                        <li>Tap the <strong>three dots menu (⋮)</strong> in the top-right.</li>
                        <li>Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
                        <li>Tap <strong>Install</strong> to confirm.</li>
                      </ol>
                    </div>

                    <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 space-y-1.5">
                      <div className="font-bold text-white text-xs text-cyan-400">Method B: Using Samsung Internet Browser</div>
                      <ol className="space-y-1.5 list-decimal list-inside text-[11px] text-slate-300">
                        <li>Open the link in <strong>Samsung Internet</strong>.</li>
                        <li>Tap the <strong>Tools menu (☰)</strong> at the bottom right.</li>
                        <li>Select <strong>"Add page to"</strong> → <strong>"Home screen"</strong> or <strong>"App screen"</strong>.</li>
                        <li>Tap <strong>Add</strong>.</li>
                      </ol>
                    </div>
                  </div>
                </div>
              )}

              {detectedPlatform === 'ios' && (
                <div className="space-y-3 p-4 bg-slate-950/70 border border-slate-800 rounded-2xl text-xs text-slate-300">
                  <div className="font-semibold text-white text-sm mb-2 flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-indigo-400" />
                    <span>Installing on iPhone / iPad (Safari)</span>
                  </div>
                  <ol className="space-y-2.5">
                    <li className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-indigo-600/30 text-indigo-400 font-bold flex items-center justify-center shrink-0 text-[11px]">1</span>
                      <span>Tap the <strong>Share</strong> button <Share className="w-3.5 h-3.5 inline text-indigo-400 mx-1" /> at the bottom of Safari.</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-indigo-600/30 text-indigo-400 font-bold flex items-center justify-center shrink-0 text-[11px]">2</span>
                      <span>Scroll down and tap <strong>"Add to Home Screen"</strong> <PlusSquare className="w-3.5 h-3.5 inline text-indigo-400 mx-1" />.</span>
                    </li>
                    <li className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-indigo-600/30 text-indigo-400 font-bold flex items-center justify-center shrink-0 text-[11px]">3</span>
                      <span>Tap <strong>Add</strong> in the top right corner.</span>
                    </li>
                  </ol>
                </div>
              )}

              {detectedPlatform === 'desktop' && (
                <div className="space-y-3 p-4 bg-slate-950/70 border border-slate-800 rounded-2xl text-xs text-slate-300">
                  <div className="font-semibold text-white text-sm mb-2 flex items-center gap-2">
                    <Monitor className="w-4 h-4 text-indigo-400" />
                    <span>Installing on PC / Mac (Chrome, Edge, Brave)</span>
                  </div>
                  {deferredPrompt ? (
                    <button
                      id="trigger-desktop-pwa-install"
                      type="button"
                      onClick={handleNativeInstall}
                      className="w-full py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Install ClassmateHub on this computer</span>
                    </button>
                  ) : (
                    <p className="leading-relaxed">
                      Click the <strong>Install icon <Download className="w-3.5 h-3.5 inline text-indigo-400 mx-1" /></strong> in your browser's address bar (or click browser menu ⋮ → <em>"Install ClassmateHub..."</em>) to create a desktop app window.
                    </p>
                  )}
                </div>
              )}

              {/* Features included */}
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 pt-1">
                <div className="p-2.5 bg-slate-950/50 rounded-xl border border-slate-800/80 flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Cached App Shell</span>
                </div>
                <div className="p-2.5 bg-slate-950/50 rounded-xl border border-slate-800/80 flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Cloud Sync When Online</span>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={handleShareApp}
            className="px-4 py-2 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 hover:text-white border border-indigo-500/30 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer"
          >
            {copiedShare ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share className="w-3.5 h-3.5" />}
            <span>{copiedShare ? 'Share Message Copied!' : 'Share App with Classmates'}</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
