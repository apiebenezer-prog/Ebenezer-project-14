import React, { useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  FolderLock, 
  UploadCloud, 
  FileText, 
  FileCode, 
  FileSpreadsheet, 
  Lock, 
  Globe, 
  Download, 
  Trash2, 
  Search, 
  Filter, 
  Plus, 
  Tag, 
  Eye, 
  ShieldAlert, 
  HardDrive, 
  Sparkles, 
  CheckCircle2, 
  X,
  File
} from 'lucide-react';
import { CloudFile } from '../../types';

interface CloudStorageLockerProps {
  files: CloudFile[];
  onUploadFile: (file: Omit<CloudFile, 'id' | 'createdAt' | 'downloadCount'>) => Promise<void>;
  onDeleteFile: (fileId: string) => Promise<void>;
  onIncrementDownload: (fileId: string) => void;
}

export const CloudStorageLocker: React.FC<CloudStorageLockerProps> = ({
  files,
  onUploadFile,
  onDeleteFile,
  onIncrementDownload
}) => {
  const { userProfile, isAdmin, isSuperAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<'my-locker' | 'class-shared' | 'admin-audit'>('class-shared');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [previewFile, setPreviewFile] = useState<CloudFile | null>(null);

  // Upload Form State
  const [fileName, setFileName] = useState('');
  const [subject, setSubject] = useState('Computer Science & Engineering');
  const [category, setCategory] = useState<CloudFile['category']>('notes');
  const [isPublic, setIsPublic] = useState(false);
  const [tagsInput, setTagsInput] = useState('');
  const [description, setDescription] = useState('');
  const [fileContentData, setFileContentData] = useState<string>('');
  const [fileSizeBytes, setFileSizeBytes] = useState<number>(0);
  const [fileMime, setFileMime] = useState<string>('text/plain');
  const [isUploading, setIsUploading] = useState(false);

  // Filtered files based on active tab and search
  const filteredFiles = useMemo(() => {
    return files.filter((file) => {
      // Visibility Filter: strictly enforce individual user isolation
      if (activeTab === 'my-locker') {
        if (!userProfile?.uid) return false;
        if (file.userId !== userProfile.uid) return false;
      } else if (activeTab === 'class-shared') {
        if (!file.isPublic) return false;
      } else if (activeTab === 'admin-audit') {
        if (!isAdmin) return false;
      }

      // Category filter
      if (selectedCategory !== 'all' && file.category !== selectedCategory) {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = file.name.toLowerCase().includes(q);
        const matchSubj = file.subject.toLowerCase().includes(q);
        const matchTags = file.tags.some(t => t.toLowerCase().includes(q));
        const matchUser = file.userName.toLowerCase().includes(q);
        return matchName || matchSubj || matchTags || matchUser;
      }

      return true;
    });
  }, [files, activeTab, selectedCategory, searchQuery, userProfile, isAdmin]);

  const handleFileUploadInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      setFileSizeBytes(file.size);
      setFileMime(file.type || 'application/octet-stream');

      const reader = new FileReader();
      reader.onload = (event) => {
        setFileContentData(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateFileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileName.trim()) return;

    setIsUploading(true);
    try {
      const tags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);
      await onUploadFile({
        userId: userProfile?.uid || 'guest-user',
        userName: userProfile?.displayName || 'Classmate',
        userAvatar: userProfile?.photoURL,
        name: fileName,
        category,
        subject,
        size: fileSizeBytes || 1024 * 350,
        mimeType: fileMime,
        fileData: fileContentData || 'data:text/plain;base64,Q2xhc3NtYXRlIEh1YiBOb3RlcyAmIFN0dWR5IE1hdGVyaWFs',
        isPublic,
        tags: tags.length ? tags : [subject, category],
        description: description || 'Study resource saved to cloud storage'
      });

      // Reset form
      setFileName('');
      setDescription('');
      setTagsInput('');
      setFileContentData('');
      setIsUploadModalOpen(false);
    } catch (error) {
      console.error('Error saving file:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDownload = (file: CloudFile) => {
    onIncrementDownload(file.id);
    const link = document.createElement('a');
    link.href = file.fileData || 'data:text/plain;charset=utf-8,' + encodeURIComponent(`[${file.name}]\nSubject: ${file.subject}\nCategory: ${file.category}\n\n${file.description || 'Classmate Hub Study File'}`);
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getCategoryBadge = (cat: CloudFile['category']) => {
    switch (cat) {
      case 'past_questions': return { label: 'Past Questions', color: 'bg-rose-500/20 text-rose-300 border-rose-500/30' };
      case 'notes': return { label: 'Lecture Notes', color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' };
      case 'slides': return { label: 'Slides', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' };
      case 'code': return { label: 'Code & Scripts', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' };
      case 'assignments': return { label: 'Assignment', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' };
      default: return { label: 'Document', color: 'bg-slate-500/20 text-slate-300 border-slate-500/30' };
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
      {/* Header */}
      <div className="p-4 md:p-6 border-b border-slate-800 bg-slate-900/50 shrink-0">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-indigo-600/25">
              <FolderLock className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-white tracking-tight">Cloud Storage Locker</h1>
                <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold rounded-full">
                  Multi-Device Synced
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Encrypted private personal files & collaborative class study repository
              </p>
            </div>
          </div>

          <button
            id="upload-new-file-btn"
            type="button"
            onClick={() => setIsUploadModalOpen(true)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold text-xs rounded-xl shadow-lg shadow-indigo-600/25 transition-all"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload New File</span>
          </button>
        </div>

        {/* Storage Navigation Tabs */}
        <div className="flex items-center gap-2 mt-6 overflow-x-auto pb-1">
          <button
            id="tab-my-locker"
            type="button"
            onClick={() => setActiveTab('my-locker')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 ${
              activeTab === 'my-locker' 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>My Private Locker</span>
          </button>

          <button
            id="tab-class-shared"
            type="button"
            onClick={() => setActiveTab('class-shared')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 ${
              activeTab === 'class-shared' 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Class Shared Repository</span>
          </button>

          {isAdmin && (
            <button
              id="tab-admin-audit"
              type="button"
              onClick={() => setActiveTab('admin-audit')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 ${
                activeTab === 'admin-audit' 
                  ? 'bg-purple-600 text-white shadow-md' 
                  : 'bg-slate-900 border border-purple-900/50 text-purple-300 hover:text-white'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-purple-300" />
              <span>Admin Master File Audit</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 border-b border-slate-800 bg-slate-900/20 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
          <input
            id="storage-search-input"
            type="text"
            placeholder="Search by file name, subject, or tag..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          {['all', 'notes', 'past_questions', 'slides', 'code', 'assignments'].map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize shrink-0 transition-colors ${
                selectedCategory === cat 
                  ? 'bg-slate-800 text-white font-semibold border border-slate-700' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Files Grid / List */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6">
        {filteredFiles.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center p-6 bg-slate-900/40 border border-dashed border-slate-800 rounded-2xl">
            <HardDrive className="w-12 h-12 text-slate-400 mb-3" />
            <h3 className="text-sm font-semibold text-slate-300">No files found</h3>
            <p className="text-xs text-slate-400 max-w-sm mt-1">
              {activeTab === 'my-locker' 
                ? 'Your private locker is empty. Upload your lecture notes, past exams, and personal study files.'
                : 'No shared resources in this category yet. Be the first to share!'}
            </p>
            <button
              type="button"
              onClick={() => setIsUploadModalOpen(true)}
              className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl transition-colors"
            >
              Upload First File
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredFiles.map((file) => {
              const badge = getCategoryBadge(file.category);
              const isOwner = file.userId === userProfile?.uid;

              return (
                <div
                  key={file.id}
                  id={`file-card-${file.id}`}
                  className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-4 flex flex-col justify-between transition-all group shadow-sm hover:shadow-md"
                >
                  <div>
                    {/* Card Top: Category Badge & Privacy Indicator */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${badge.color}`}>
                        {badge.label}
                      </span>
                      <div className="flex items-center gap-1.5 text-[11px]">
                        {file.isPublic ? (
                          <span className="flex items-center gap-1 text-emerald-400 font-medium bg-emerald-500/10 px-2 py-0.5 rounded-md">
                            <Globe className="w-3 h-3" />
                            <span>Shared</span>
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-amber-400 font-medium bg-amber-500/10 px-2 py-0.5 rounded-md">
                            <Lock className="w-3 h-3" />
                            <span>Private Locker</span>
                          </span>
                        )}
                      </div>
                    </div>

                    {/* File Title & Subject */}
                    <div className="flex items-start gap-3 mb-2">
                      <div className="w-10 h-10 rounded-xl bg-slate-800 text-indigo-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                        {file.category === 'code' ? <FileCode className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4 className="text-xs font-bold text-white truncate group-hover:text-indigo-300 transition-colors" title={file.name}>
                          {file.name}
                        </h4>
                        <p className="text-[11px] text-slate-400 truncate">{file.subject}</p>
                      </div>
                    </div>

                    {/* Description */}
                    {file.description && (
                      <p className="text-[11px] text-slate-400 line-clamp-2 my-2 leading-relaxed">
                        {file.description}
                      </p>
                    )}

                    {/* Tags */}
                    {file.tags && file.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 my-2">
                        {file.tags.slice(0, 3).map((tag, idx) => (
                          <span key={idx} className="text-[10px] px-1.5 py-0.5 bg-slate-950 text-slate-400 rounded">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Card Bottom: Metadata & Actions */}
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <div className="flex items-center gap-2">
                      <span>{formatFileSize(file.size)}</span>
                      <span>•</span>
                      <span>{file.downloadCount} dl</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setPreviewFile(file)}
                        title="View Details"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDownload(file)}
                        title="Download to Device"
                        className="p-1.5 rounded-lg text-indigo-400 hover:text-indigo-300 hover:bg-indigo-950/50 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>

                      {(isOwner || isAdmin) && (
                        <button
                          type="button"
                          onClick={() => onDeleteFile(file.id)}
                          title="Delete File"
                          className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/50 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Upload Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsUploadModalOpen(false)}
              className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-lg bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
                <UploadCloud className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Upload Cloud Study Material</h3>
                <p className="text-xs text-slate-400">Save to your private locker or share with the class</p>
              </div>
            </div>

            <form onSubmit={handleCreateFileSubmit} className="space-y-4 text-xs">
              {/* File Picker */}
              <div className="p-4 border-2 border-dashed border-slate-700 hover:border-indigo-500 rounded-xl text-center bg-slate-950/50 cursor-pointer transition-colors relative">
                <input
                  id="cloud-file-input"
                  type="file"
                  onChange={handleFileUploadInput}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                />
                <File className="w-8 h-8 text-indigo-400 mx-auto mb-2" />
                <p className="font-semibold text-slate-200">
                  {fileName || 'Click to select or drag and drop files here'}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  PDF, DOCX, PPTX, SQL, ZIP, Code, Markdown (Max 15MB)
                </p>
              </div>

              <div>
                <label className="block font-medium text-slate-300 mb-1">File Name / Document Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Distributed_Systems_Midterm_Review.pdf"
                  value={fileName}
                  onChange={(e) => setFileName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-300 mb-1">Course / Subject</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Algorithms"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-300 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="notes">Lecture Notes</option>
                    <option value="past_questions">Past Examination Papers</option>
                    <option value="slides">Lecture Slides</option>
                    <option value="code">Code & Problem Solutions</option>
                    <option value="assignments">Assignment Template</option>
                    <option value="other">Other Material</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-300 mb-1">Tags (Comma separated)</label>
                <input
                  type="text"
                  placeholder="Midterm, Raft, Solved, HighYield"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-300 mb-1">Summary / Description</label>
                <textarea
                  rows={2}
                  placeholder="Brief summary of what this document covers..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Privacy Setting */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <span className="font-semibold text-slate-200 block">Cloud Privacy & Permissions</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setIsPublic(false)}
                    className={`p-2.5 rounded-lg border flex items-center gap-2 text-left transition-all ${
                      !isPublic 
                        ? 'bg-amber-500/10 border-amber-500 text-amber-300 font-semibold' 
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Lock className="w-4 h-4 shrink-0" />
                    <div>
                      <div className="text-xs">Private Locker</div>
                      <div className="text-[10px] opacity-75">Only you & Admin</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsPublic(true)}
                    className={`p-2.5 rounded-lg border flex items-center gap-2 text-left transition-all ${
                      isPublic 
                        ? 'bg-emerald-500/10 border-emerald-500 text-emerald-300 font-semibold' 
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Globe className="w-4 h-4 shrink-0" />
                    <div>
                      <div className="text-xs">Share with Class</div>
                      <div className="text-[10px] opacity-75">All classmates</div>
                    </div>
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 hover:text-white rounded-xl"
                >
                  Cancel
                </button>
                <button
                  id="submit-cloud-upload-btn"
                  type="submit"
                  disabled={isUploading}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl flex items-center gap-1.5 shadow-md shadow-indigo-600/30 disabled:opacity-50"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>{isUploading ? 'Encrypting & Syncing...' : 'Save to Cloud'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* File Preview Modal */}
      {previewFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative space-y-4">
            <button
              onClick={() => setPreviewFile(null)}
              className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-lg bg-slate-800"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-800 text-indigo-400 flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">{previewFile.name}</h3>
                <p className="text-xs text-slate-400">{previewFile.subject} • {formatFileSize(previewFile.size)}</p>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-2">
              <div>
                <span className="text-slate-400 block">Uploaded By:</span>
                <span className="text-white font-semibold">{previewFile.userName}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Description:</span>
                <p className="text-slate-300 leading-relaxed">{previewFile.description || 'No description provided.'}</p>
              </div>
              {previewFile.tags && (
                <div>
                  <span className="text-slate-400 block mb-1">Tags:</span>
                  <div className="flex flex-wrap gap-1">
                    {previewFile.tags.map((t, idx) => (
                      <span key={idx} className="px-2 py-0.5 bg-slate-900 text-indigo-300 rounded text-[10px]">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPreviewFile(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 hover:text-white text-xs rounded-xl"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  handleDownload(previewFile);
                  setPreviewFile(null);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download File</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
