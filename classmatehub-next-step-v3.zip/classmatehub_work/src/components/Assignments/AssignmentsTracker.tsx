import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  CheckSquare, 
  Plus, 
  Calendar, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  BookOpen, 
  Trash2, 
  X,
  Filter
} from 'lucide-react';
import { Assignment } from '../../types';

interface AssignmentsTrackerProps {
  assignments: Assignment[];
  onCreateAssignment: (assign: Omit<Assignment, 'id' | 'createdAt' | 'completedBy'>) => Promise<void>;
  onToggleAssignmentDone: (assignmentId: string) => Promise<void>;
  onDeleteAssignment: (assignmentId: string) => Promise<void>;
}

export const AssignmentsTracker: React.FC<AssignmentsTrackerProps> = ({
  assignments,
  onCreateAssignment,
  onToggleAssignmentDone,
  onDeleteAssignment
}) => {
  const { userProfile, isAdmin } = useAuth();
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'completed'>('all');
  const [showModal, setShowModal] = useState(false);

  // Form
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('Computer Science');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState<Assignment['priority']>('medium');

  const filteredAssignments = assignments.filter((item) => {
    const isDone = item.completedBy?.includes(userProfile?.uid || '');
    if (filterStatus === 'pending' && isDone) return false;
    if (filterStatus === 'completed' && !isDone) return false;
    if (filterPriority !== 'all' && item.priority !== filterPriority) return false;
    return true;
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !dueDate) return;

    await onCreateAssignment({
      title,
      subject,
      description,
      dueDate,
      priority,
      createdBy: userProfile?.uid || 'guest',
      createdByName: userProfile?.displayName || 'Classmate'
    });

    setTitle('');
    setDescription('');
    setDueDate('');
    setShowModal(false);
  };

  const getPriorityBadge = (p: Assignment['priority']) => {
    switch (p) {
      case 'high': return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'medium': return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      default: return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
      {/* Header */}
      <div className="p-4 md:p-6 border-b border-slate-800 bg-slate-900/50 shrink-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center shadow-lg shadow-amber-600/25">
              <CheckSquare className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">Assignments & Deadlines</h1>
              <p className="text-xs text-slate-400">
                Track homework, lab reports, and exam deadlines across all courses
              </p>
            </div>
          </div>

          <button
            id="create-assignment-btn"
            type="button"
            onClick={() => setShowModal(true)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Assignment</span>
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2 mt-5">
          <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1.5 rounded-lg transition-all ${filterStatus === 'all' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-white'}`}
            >
              All Deadlines
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('pending')}
              className={`px-3 py-1.5 rounded-lg transition-all ${filterStatus === 'pending' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-white'}`}
            >
              Pending
            </button>
            <button
              type="button"
              onClick={() => setFilterStatus('completed')}
              className={`px-3 py-1.5 rounded-lg transition-all ${filterStatus === 'completed' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-white'}`}
            >
              Completed ✓
            </button>
          </div>

          <div className="flex items-center gap-1 text-xs">
            {['all', 'high', 'medium', 'low'].map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setFilterPriority(p)}
                className={`px-2.5 py-1.5 rounded-lg border capitalize transition-colors ${
                  filterPriority === p 
                    ? 'bg-slate-800 text-white border-slate-700 font-semibold' 
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {p} Priority
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-3">
        {filteredAssignments.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-slate-400">
            <CheckSquare className="w-10 h-10 text-slate-400 mb-2" />
            <h4 className="text-sm font-semibold text-slate-300">No assignments found</h4>
            <p className="text-xs text-slate-400 max-w-xs mt-1">
              All caught up! Or add a new deadline for your classmates to see.
            </p>
          </div>
        ) : (
          filteredAssignments.map((item) => {
            const isDone = item.completedBy?.includes(userProfile?.uid || '');
            const canDelete = item.createdBy === userProfile?.uid || isAdmin;

            return (
              <div
                key={item.id}
                id={`assignment-card-${item.id}`}
                className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  isDone 
                    ? 'bg-slate-900/40 border-slate-800/60 opacity-75' 
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <button
                    type="button"
                    onClick={() => onToggleAssignmentDone(item.id)}
                    className={`p-1 mt-0.5 rounded-lg border transition-colors ${
                      isDone 
                        ? 'bg-emerald-500 text-white border-emerald-500' 
                        : 'border-slate-700 text-transparent hover:border-indigo-500'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getPriorityBadge(item.priority)}`}>
                        {item.priority} Priority
                      </span>
                      <span className="text-[11px] font-semibold text-indigo-400">
                        {item.subject}
                      </span>
                    </div>

                    <h4 className={`text-sm font-bold text-white mt-1 ${isDone ? 'line-through text-slate-400' : ''}`}>
                      {item.title}
                    </h4>
                    {item.description && (
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">{item.description}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    <span>Due: <strong>{item.dueDate}</strong></span>
                  </div>

                  {canDelete && (
                    <button
                      type="button"
                      onClick={() => onDeleteAssignment(item.id)}
                      className="p-2 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Create Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Add Course Assignment / Deadline</h3>
              <button onClick={() => setShowModal(false)} className="p-1 text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lab 4: B+ Tree Indexing"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">Course / Subject</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Database Systems"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Due Date</label>
                <input
                  type="date"
                  required
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Description / Submission Details</label>
                <textarea
                  rows={3}
                  placeholder="Requirements, portal links, or team guidelines..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl"
                >
                  Save Deadline
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
