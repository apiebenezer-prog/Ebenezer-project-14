import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  BarChart2, 
  Plus, 
  CheckCircle2, 
  Trash2, 
  Clock, 
  X, 
  Vote,
  Sparkles
} from 'lucide-react';
import { Poll } from '../../types';

interface ClassPollsProps {
  polls: Poll[];
  onCreatePoll: (question: string, optionTexts: string[]) => Promise<void>;
  onVotePoll: (pollId: string, optionId: string) => Promise<void>;
  onDeletePoll: (pollId: string) => Promise<void>;
}

export const ClassPolls: React.FC<ClassPollsProps> = ({
  polls,
  onCreatePoll,
  onVotePoll,
  onDeletePoll
}) => {
  const { userProfile, isAdmin } = useAuth();
  const [showModal, setShowModal] = useState(false);
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState<string[]>(['Option 1', 'Option 2']);
  const [formError, setFormError] = useState('');
  const isRealAccount = !!userProfile && !userProfile.uid.startsWith('demo-') && userProfile.uid !== 'guest';
  const canManagePolls = isRealAccount && isAdmin;

  const handleAddOption = () => {
    if (options.length < 6) {
      setOptions([...options, `Option ${options.length + 1}`]);
    }
  };

  const handleOptionTextChange = (index: number, text: string) => {
    const updated = [...options];
    updated[index] = text;
    setOptions(updated);
  };

  const handleRemoveOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index));
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || options.some(o => !o.trim())) return;

    setFormError('');
    try {
      await onCreatePoll(question.trim(), options.map(option => option.trim()));
      setQuestion('');
      setOptions(['Option 1', 'Option 2']);
      setShowModal(false);
    } catch (error) {
      setFormError(error instanceof Error ? error.message : 'The poll could not be saved. Please try again.');
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
      {/* Header */}
      <div className="p-4 md:p-6 border-b border-slate-800 bg-slate-900/50 shrink-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-600 flex items-center justify-center shadow-lg shadow-teal-600/25">
              <BarChart2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">Class Polls & Decisions</h1>
              <p className="text-xs text-slate-400">
                Vote on revision marathon timings, project topics, and study dates
              </p>
            </div>
          </div>

          {canManagePolls && <button
            id="create-poll-btn"
            type="button"
            onClick={() => { setFormError(''); setShowModal(true); }}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl shadow-lg shadow-indigo-600/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Poll</span>
          </button>}
        </div>
      </div>

      {/* Polls List */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
        {polls.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-slate-400">
            <Vote className="w-10 h-10 text-slate-400 mb-2" />
            <h4 className="text-sm font-semibold text-slate-300">No active polls</h4>
            <p className="text-xs text-slate-400 max-w-xs mt-1">
              Create a poll to decide group study times, project topics, or exam prep strategies.
            </p>
          </div>
        ) : (
          polls.map((poll) => {
            const totalVotes = poll.options.reduce((acc, curr) => acc + curr.votes.length, 0);
            const userVotedOptionId = poll.options.find(o => o.votes.includes(userProfile?.uid || ''))?.id;
            // Match the Firestore policy: only authorized moderators/admins can delete polls.
            const canDelete = canManagePolls;

            return (
              <div
                key={poll.id}
                id={`poll-card-${poll.id}`}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-sm md:text-base font-bold text-white leading-snug">{poll.question}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Created by {poll.createdByName} • {totalVotes} {totalVotes === 1 ? 'vote' : 'votes'} total
                    </p>
                  </div>

                  {canDelete && (
                    <button
                      type="button"
                      onClick={() => onDeletePoll(poll.id)}
                      className="p-1.5 text-rose-400 hover:text-rose-300 rounded-lg hover:bg-rose-950/40"
                      title="Delete Poll"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Options List */}
                <div className="space-y-2.5">
                  {poll.options.map((opt) => {
                    const percentage = totalVotes > 0 ? Math.round((opt.votes.length / totalVotes) * 100) : 0;
                    const isSelected = userVotedOptionId === opt.id;

                    return (
                      <button
                        key={opt.id}
                        type="button"
                        disabled={!isRealAccount || poll.isClosed}
                        title={!isRealAccount ? 'Sign in with a real account to vote' : poll.isClosed ? 'This poll is closed' : 'Vote for this option'}
                        onClick={() => onVotePoll(poll.id, opt.id)}
                        className={`w-full p-3 rounded-xl border text-left relative overflow-hidden transition-all flex items-center justify-between gap-3 disabled:cursor-not-allowed disabled:opacity-60 ${
                          isSelected 
                            ? 'border-indigo-500 bg-indigo-950/30' 
                            : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
                        }`}
                      >
                        {/* Progress Bar Background */}
                        <div
                          className="absolute inset-y-0 left-0 bg-indigo-600/20 transition-all duration-300"
                          style={{ width: `${percentage}%` }}
                        />

                        <div className="relative z-10 flex items-center gap-2.5 min-w-0">
                          <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                            isSelected ? 'border-indigo-400 bg-indigo-600 text-white' : 'border-slate-600'
                          }`}>
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5 fill-current" />}
                          </div>
                          <span className="text-xs font-semibold text-white truncate">{opt.text}</span>
                        </div>

                        <div className="relative z-10 text-xs font-mono font-bold text-slate-300 shrink-0">
                          <span>{percentage}%</span>
                          <span className="text-[10px] text-slate-400 font-normal ml-1">({opt.votes.length})</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Create Class Poll</h3>
              <button onClick={() => setShowModal(false)} className="p-1 text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-3 text-xs">
              {formError && <div role="alert" className="rounded-lg border border-rose-500/30 bg-rose-950/40 px-3 py-2 text-xs text-rose-200">{formError}</div>}
              <div>
                <label className="block text-slate-300 mb-1">Question / Topic</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Preferred date for Midterm Revision Session?"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-slate-300">Poll Options</label>
                {options.map((opt, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <input
                      type="text"
                      required
                      placeholder={`Option ${i + 1}`}
                      value={opt}
                      onChange={(e) => handleOptionTextChange(i, e.target.value)}
                      className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                    />
                    {options.length > 2 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveOption(i)}
                        className="p-2 text-rose-400 hover:bg-slate-800 rounded-lg"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}

                {options.length < 6 && (
                  <button
                    type="button"
                    onClick={handleAddOption}
                    className="text-indigo-400 hover:text-indigo-300 text-xs font-semibold flex items-center gap-1 mt-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Another Option</span>
                  </button>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl"
                >
                  Launch Poll
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
