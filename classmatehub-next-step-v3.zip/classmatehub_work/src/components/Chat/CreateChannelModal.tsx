import React, { useState } from 'react';
import { Hash, X, Lock, Globe } from 'lucide-react';
import { Channel } from '../../types';

interface CreateChannelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateChannel: (name: string, description: string, category: Channel['category'], isPrivate?: boolean) => Promise<void>;
}

export const CreateChannelModal: React.FC<CreateChannelModalProps> = ({
  isOpen,
  onClose,
  onCreateChannel
}) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Channel['category']>('courses');
  const [isPrivate, setIsPrivate] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    await onCreateChannel(name.toLowerCase().replace(/\s+/g, '-'), description, category, isPrivate);
    setName('');
    setDescription('');
    setIsPrivate(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isPrivate ? <Lock className="w-5 h-5 text-amber-400" /> : <Hash className="w-5 h-5 text-indigo-400" />}
            <h3 className="text-base font-bold text-white">
              {isPrivate ? 'Create Private Group' : 'Create Public Channel'}
            </h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {/* Privacy Type Selector */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => setIsPrivate(false)}
              className={`flex items-center justify-center gap-2 py-2 rounded-lg font-medium transition-all ${
                !isPrivate ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Public Channel</span>
            </button>
            <button
              type="button"
              onClick={() => setIsPrivate(true)}
              className={`flex items-center justify-center gap-2 py-2 rounded-lg font-medium transition-all ${
                isPrivate ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Private Group</span>
            </button>
          </div>

          <div>
            <label className="block text-slate-300 mb-1 font-medium">
              {isPrivate ? 'Private Group Name' : 'Channel Name'}
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-slate-500 font-bold">
                {isPrivate ? '🔒' : '#'}
              </span>
              <input
                type="text"
                required
                placeholder={isPrivate ? 'study-team-alpha' : 'computer-networks'}
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-white focus:outline-none focus:border-indigo-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 mb-1 font-medium">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="courses">Courses & Subjects</option>
              <option value="projects">Projects & Collaborations</option>
              <option value="exam-prep">Exam Prep & Past Papers</option>
              <option value="general">General Discussions</option>
              <option value="social">Campus Social</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 mb-1 font-medium">Description</label>
            <textarea
              rows={2}
              placeholder="What will classmates discuss here?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <p className="text-[11px] text-slate-400">
            {isPrivate
              ? '🔒 Private group messages are delivered and preserved forever for group members.'
              : '🌐 Public channel messages are visible to all 11th graders and saved permanently.'}
          </p>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl shadow-md shadow-indigo-600/25 transition-colors"
            >
              {isPrivate ? 'Create Private Group' : 'Create Channel'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
