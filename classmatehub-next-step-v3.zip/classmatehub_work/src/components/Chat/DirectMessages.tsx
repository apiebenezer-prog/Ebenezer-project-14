import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  MessageSquare, 
  Send, 
  Paperclip, 
  Search, 
  User, 
  Lock, 
  ShieldCheck, 
  Plus, 
  ArrowLeft,
  FileText,
  Download,
  CheckCheck,
  Clock,
  Check
} from 'lucide-react';
import { DirectConversation, ChatMessage, UserProfile, Attachment } from '../../types';

interface DirectMessagesProps {
  conversations: DirectConversation[];
  activeConversation: DirectConversation | null;
  onSelectConversation: (conv: DirectConversation) => void;
  onStartNewConversationWithUser: (user: UserProfile) => void;
  messages: ChatMessage[];
  onSendDirectMessage: (convId: string, text: string, attachments?: Attachment[]) => Promise<void>;
  allUsers: UserProfile[];
}

export const DirectMessages: React.FC<DirectMessagesProps> = ({
  conversations,
  activeConversation,
  onSelectConversation,
  onStartNewConversationWithUser,
  messages,
  onSendDirectMessage,
  allUsers
}) => {
  const { userProfile, isAdmin } = useAuth();
  const [inputText, setInputText] = useState('');
  const [searchUserQuery, setSearchUserQuery] = useState('');
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [sendError, setSendError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !activeConversation) return;

    const text = inputText;
    setSendError('');
    setInputText('');
    try {
      await onSendDirectMessage(activeConversation.id, text);
    } catch (error) {
      setInputText(text);
      setSendError(error instanceof Error ? error.message : 'Message was not saved. Please try again.');
    }
  };

  // Find other participant in conversation
  const getOtherParticipant = (conv: DirectConversation) => {
    const otherUid = conv.participants.find(p => p !== userProfile?.uid) || conv.participants[0];
    const details = conv.participantDetails?.[otherUid] || { displayName: 'Classmate', email: '' };
    return { uid: otherUid, ...details };
  };

  const filteredUsersToChat = allUsers.filter(u => {
    if (u.uid === userProfile?.uid) return false;
    if (searchUserQuery.trim()) {
      const q = searchUserQuery.toLowerCase();
      return u.displayName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || (u.major && u.major.toLowerCase().includes(q));
    }
    return true;
  });

  // Filter conversations for the current logged-in user so each user only sees chats they are part of
  const userConversations = userProfile?.uid
    ? conversations.filter(c => !c.participants || c.participants.length === 0 || c.participants.includes(userProfile.uid))
    : conversations;

  return (
    <div className="flex-1 flex h-full bg-slate-950 overflow-hidden">
      {/* Left Conversations Sidebar */}
      <div className={`w-full md:w-80 border-r border-slate-800 bg-slate-900/50 flex flex-col shrink-0 ${activeConversation ? 'hidden md:flex' : 'flex'}`}>
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-indigo-400" />
            <h2 className="text-sm font-bold text-white">Direct Messages</h2>
          </div>
          <button
            id="start-new-dm-btn"
            type="button"
            onClick={() => setShowNewChatModal(true)}
            className="p-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
            title="Start New Direct Message"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {userConversations.length === 0 ? (
            <div className="p-6 text-center text-slate-400 space-y-3">
              <p className="text-xs">No active direct message threads yet.</p>
              <button
                type="button"
                onClick={() => setShowNewChatModal(true)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors"
              >
                Find Classmate
              </button>
            </div>
          ) : (
            userConversations.map((conv) => {
              const other = getOtherParticipant(conv);
              const isSelected = activeConversation?.id === conv.id;
              const isSentByMe = conv.lastMessageSenderId === userProfile?.uid;
              const otherUid = other.uid;
              const isLastMessageRead = isSentByMe
                ? (conv.lastMessageReadBy || []).includes(otherUid)
                : true;
              const hasUnread = !isSentByMe && !!conv.lastMessageSenderId && !(conv.lastMessageReadBy || []).includes(userProfile?.uid || '');

              return (
                <button
                  key={conv.id}
                  id={`conv-item-${conv.id}`}
                  type="button"
                  onClick={() => onSelectConversation(conv)}
                  className={`w-full p-3 rounded-xl flex items-center gap-3 text-left transition-all ${
                    isSelected ? 'bg-slate-800 border border-slate-700' : 'hover:bg-slate-900'
                  }`}
                >
                  <div className="relative shrink-0">
                    <img
                      src={other.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${other.uid}`}
                      alt={other.displayName}
                      className="w-10 h-10 rounded-xl object-cover bg-slate-800"
                      referrerPolicy="no-referrer"
                    />
                    {hasUnread && (
                      <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900 animate-pulse" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-white truncate">{other.displayName}</h4>
                      {hasUnread && (
                        <span className="px-1.5 py-0.5 bg-emerald-500 text-[9px] font-bold text-white rounded-full">
                          NEW
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 truncate mt-0.5">
                      {isSentByMe && (
                        isLastMessageRead ? (
                          <CheckCheck className="w-3.5 h-3.5 text-sky-400 shrink-0 stroke-[2.5]" />
                        ) : (
                          <CheckCheck className="w-3.5 h-3.5 text-slate-500 shrink-0 stroke-[2]" />
                        )
                      )}
                      <span className="truncate">{conv.lastMessage || 'Click to start chatting'}</span>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Right Chat Panel */}
      <div className={`flex-1 flex flex-col bg-slate-950 ${!activeConversation ? 'hidden md:flex' : 'flex'}`}>
        {activeConversation ? (
          <>
            {/* Chat Header */}
            <div className="h-16 px-4 md:px-6 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => onSelectConversation(null as any)}
                  className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                {(() => {
                  const other = getOtherParticipant(activeConversation);
                  return (
                    <div className="flex items-center gap-3">
                      <img
                        src={other.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${other.uid}`}
                        alt={other.displayName}
                        className="w-8 h-8 rounded-xl object-cover bg-slate-800 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <h3 className="text-xs md:text-sm font-bold text-white flex items-center gap-1.5">
                          <span>{other.displayName}</span>
                          <span className="text-[10px] text-slate-400 font-normal">({other.email})</span>
                        </h3>
                        <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                          <Lock className="w-2.5 h-2.5" /> End-to-End Synced
                        </span>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Messenger Sync Counter */}
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-cyan-500/10 text-cyan-300 rounded-lg border border-cyan-500/20 text-[10px] font-mono font-semibold">
                <CheckCheck className="w-3 h-3 text-cyan-400 stroke-[2.5]" />
                <span>{messages.length} delivered</span>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-slate-400">
                  <Lock className="w-8 h-8 text-indigo-400 mb-2" />
                  <p className="text-xs">Private 1-on-1 classmate channel initialized.</p>
                </div>
              ) : (
                messages.map((msg, index) => {
                  const isMine = msg.userId === userProfile?.uid;
                  const otherParticipantUid = activeConversation.participants.find(p => p !== userProfile?.uid);
                  const isReadByRecipient = isMine && (
                    otherParticipantUid 
                      ? (msg.readBy || []).includes(otherParticipantUid) 
                      : ((msg.readBy && msg.readBy.length > 1) || msg.status === 'read')
                  );

                  return (
                    <div
                      key={msg.id}
                      className={`flex items-end gap-2.5 ${isMine ? 'justify-end' : 'justify-start'}`}
                    >
                      {!isMine && (
                        <img
                          src={msg.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${msg.userId}`}
                          alt={msg.userName}
                          className="w-7 h-7 rounded-lg object-cover bg-slate-800 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                      )}
                      <div className={`max-w-[75%] rounded-2xl p-3 text-xs leading-relaxed ${
                        isMine 
                          ? 'bg-indigo-600 text-white rounded-br-none shadow-md shadow-indigo-600/20' 
                          : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-none'
                      }`}>
                        <p className="whitespace-pre-wrap">{msg.text}</p>
                        
                        {/* Messenger Delivery Status & Count Under DM */}
                        <div className={`text-[10px] mt-2 pt-1.5 border-t flex items-center justify-between gap-2.5 select-none ${
                          isMine ? 'border-indigo-500/40 text-indigo-100' : 'border-slate-800 text-slate-400'
                        }`}>
                          <div className="flex items-center gap-1 font-medium">
                            {msg.status === 'sending' ? (
                              <>
                                <Clock className="w-3 h-3 text-amber-300 animate-spin" />
                                <span className="text-[9px]">Sending</span>
                              </>
                            ) : isReadByRecipient ? (
                              <>
                                <CheckCheck className="w-3.5 h-3.5 text-sky-300 stroke-[2.5]" />
                                <span className="text-[9px] font-bold text-sky-200">Read</span>
                              </>
                            ) : (
                              <>
                                <CheckCheck className={`w-3.5 h-3.5 ${isMine ? 'text-indigo-200/80' : 'text-slate-400'} stroke-[2]`} />
                                <span className="text-[9px] font-semibold">Delivered</span>
                              </>
                            )}
                            <span className="opacity-40">•</span>
                            <span className="font-mono text-[9px] font-bold">
                              Msg #{msg.deliveredCount ?? (index + 1)}
                            </span>
                          </div>
                          <span className={`text-[9px] ${isMine ? 'text-indigo-200' : 'text-slate-400'}`}>
                            {msg.createdAt ? new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'now'}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Box */}
            <div className="p-4 border-t border-slate-800 bg-slate-900/40 shrink-0">
              {sendError && <p role="alert" className="mb-2 text-xs text-rose-300">{sendError}</p>}
              <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                <input
                  id="direct-message-input"
                  type="text"
                  placeholder="Type a private message..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs md:text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
                />
                <button
                  id="dm-send-btn"
                  type="submit"
                  disabled={!inputText.trim()}
                  className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-md transition-colors disabled:opacity-40"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
            <MessageSquare className="w-12 h-12 text-slate-400 mb-3" />
            <h3 className="text-sm font-semibold text-white">Select or Start a Direct Message</h3>
            <p className="text-xs text-slate-400 max-w-sm mt-1">
              Communicate 1-on-1 with classmates to discuss homework, exam prep, or project teams.
            </p>
          </div>
        )}
      </div>

      {/* New DM Modal */}
      {showNewChatModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">Start Direct Message</h3>
              <button
                type="button"
                onClick={() => setShowNewChatModal(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search classmate by name or major..."
                value={searchUserQuery}
                onChange={(e) => setSearchUserQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="max-h-60 overflow-y-auto space-y-1">
              {filteredUsersToChat.length === 0 ? (
                <p className="text-center text-xs text-slate-400 py-4">No classmates found.</p>
              ) : (
                filteredUsersToChat.map((u) => (
                  <button
                    key={u.uid}
                    type="button"
                    onClick={() => {
                      onStartNewConversationWithUser(u);
                      setShowNewChatModal(false);
                    }}
                    className="w-full p-2.5 hover:bg-slate-800 rounded-xl flex items-center gap-3 text-left transition-colors"
                  >
                    <img
                      src={u.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${u.uid}`}
                      alt={u.displayName}
                      className="w-8 h-8 rounded-lg object-cover bg-slate-800 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-semibold text-white truncate">{u.displayName}</div>
                      <div className="text-[10px] text-slate-400 truncate">{u.major || u.email}</div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
