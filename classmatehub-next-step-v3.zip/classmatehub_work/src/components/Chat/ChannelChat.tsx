import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Hash, 
  Send, 
  Paperclip, 
  Smile, 
  Pin, 
  Trash2, 
  Reply, 
  MoreVertical, 
  Search, 
  Users, 
  FileText, 
  Download, 
  ShieldCheck, 
  X,
  FileCode,
  FileSpreadsheet,
  CheckCheck,
  Check,
  Clock,
  Lock,
  MessageCircle
} from 'lucide-react';
import { Channel, ChatMessage, Attachment } from '../../types';

interface ChannelChatProps {
  channel: Channel;
  messages: ChatMessage[];
  onSendMessage: (text: string, attachments?: Attachment[], replyTo?: ChatMessage) => Promise<void>;
  onDeleteMessage: (msgId: string) => Promise<void>;
  onTogglePinMessage: (msgId: string, isPinned: boolean) => Promise<void>;
  onToggleReaction: (msgId: string, emoji: string) => Promise<void>;
}

export const ChannelChat: React.FC<ChannelChatProps> = ({
  channel,
  messages,
  onSendMessage,
  onDeleteMessage,
  onTogglePinMessage,
  onToggleReaction
}) => {
  const { userProfile, isAdmin, isSuperAdmin } = useAuth();
  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showPinnedOnly, setShowPinnedOnly] = useState(false);
  const [replyingTo, setReplyingTo] = useState<ChatMessage | null>(null);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [showEmojiPickerForMsg, setShowEmojiPickerForMsg] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && attachments.length === 0) return;

    const text = inputText;
    const currentAttachments = [...attachments];
    const replyTarget = replyingTo || undefined;

    setInputText('');
    setAttachments([]);
    setReplyingTo(null);

    await onSendMessage(text, currentAttachments.length ? currentAttachments : undefined, replyTarget);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const attach: Attachment = {
          name: file.name,
          size: file.size,
          type: file.type || 'application/octet-stream',
          url: (event.target?.result as string) || ''
        };
        setAttachments(prev => [...prev, attach]);
      };
      reader.readAsDataURL(file);
    });
  };

  const filteredMessages = messages.filter((msg) => {
    if (showPinnedOnly && !msg.isPinned) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return msg.text.toLowerCase().includes(q) || msg.userName.toLowerCase().includes(q);
    }
    return true;
  });

  const pinnedCount = messages.filter(m => m.isPinned).length;

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
      {/* Channel Header */}
      <div className="h-16 px-4 md:px-6 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-slate-800 text-indigo-400 flex items-center justify-center shrink-0">
            {channel.isPrivate ? <Lock className="w-5 h-5 text-amber-400" /> : <Hash className="w-5 h-5" />}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-sm md:text-base font-bold text-white truncate">{channel.name}</h2>
              {channel.isPrivate ? (
                <span className="text-[10px] px-2 py-0.5 bg-amber-500/15 text-amber-300 font-semibold rounded-md flex items-center gap-1 border border-amber-500/30">
                  <Lock className="w-2.5 h-2.5" /> Private Group
                </span>
              ) : (
                <span className="text-[10px] px-2 py-0.5 bg-slate-800 text-slate-400 rounded-md capitalize hidden sm:inline">
                  {channel.category}
                </span>
              )}
              <span className="text-[10px] px-2 py-0.5 bg-cyan-500/10 text-cyan-300 font-mono font-semibold rounded-md border border-cyan-500/20 flex items-center gap-1">
                <CheckCheck className="w-3 h-3 text-cyan-400 stroke-[2.5]" />
                <span className="hidden sm:inline">Messenger:</span> {messages.length} delivered
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate max-w-md">{channel.description}</p>
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-2">
          {/* Search within Channel */}
          <div className="relative hidden md:block w-48">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search chat..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Pinned Messages Toggle */}
          <button
            id="pinned-messages-toggle"
            type="button"
            onClick={() => setShowPinnedOnly(!showPinnedOnly)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
              showPinnedOnly 
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' 
                : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
            }`}
          >
            <Pin className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Pinned</span>
            {pinnedCount > 0 && (
              <span className="text-[10px] px-1 bg-amber-500 text-slate-950 font-bold rounded">
                {pinnedCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Messages List */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
        {filteredMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-3">
              <Hash className="w-6 h-6 text-indigo-400" />
            </div>
            <h3 className="text-sm font-semibold text-white">Welcome to #{channel.name}!</h3>
            <p className="text-xs text-slate-400 max-w-sm mt-1">
              This is the start of the #{channel.name} channel. Share notes, ask questions, or say hello to your classmates.
            </p>
          </div>
        ) : (
          filteredMessages.map((msg, index) => {
            const isMine = msg.userId === userProfile?.uid;
            const canDelete = isMine || isAdmin || isSuperAdmin;
            const canPin = isAdmin || isSuperAdmin || userProfile?.role === 'moderator';

            return (
              <div
                key={msg.id}
                id={`message-${msg.id}`}
                className={`group flex items-start gap-3 p-2 rounded-2xl transition-colors hover:bg-slate-900/50 ${
                  msg.isPinned ? 'bg-amber-950/20 border border-amber-500/20' : ''
                }`}
              >
                {/* User Avatar */}
                <img
                  src={msg.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${msg.userId}`}
                  alt={msg.userName}
                  className="w-9 h-9 rounded-xl object-cover bg-slate-800 shrink-0 mt-0.5"
                  referrerPolicy="no-referrer"
                />

                <div className="flex-1 min-w-0">
                  {/* Sender Header */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-white">{msg.userName}</span>
                      {msg.userRole === 'admin' && (
                        <span className="text-[9px] px-1.5 py-0.2 bg-indigo-600 text-white rounded font-bold">
                          Admin
                        </span>
                      )}
                      {msg.userRole === 'moderator' && (
                        <span className="text-[9px] px-1.5 py-0.2 bg-purple-600 text-white rounded font-bold">
                          Mod
                        </span>
                      )}
                      <span className="text-[10px] text-slate-400">
                        {msg.createdAt ? new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'just now'}
                      </span>
                      {msg.isPinned && (
                        <span className="flex items-center gap-1 text-[10px] text-amber-400 font-semibold bg-amber-500/10 px-1.5 py-0.5 rounded">
                          <Pin className="w-3 h-3" /> Pinned
                        </span>
                      )}
                    </div>

                    {/* Action Bar (hover) */}
                    <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg p-1 transition-opacity">
                      {/* Emoji React */}
                      {['👍', '❤️', '💡', '🔥'].map((emoji) => (
                        <button
                          key={emoji}
                          type="button"
                          onClick={() => onToggleReaction(msg.id, emoji)}
                          className="hover:scale-125 px-1 text-xs transition-transform"
                        >
                          {emoji}
                        </button>
                      ))}

                      {/* Reply */}
                      <button
                        type="button"
                        onClick={() => setReplyingTo(msg)}
                        title="Reply to message"
                        className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800"
                      >
                        <Reply className="w-3.5 h-3.5" />
                      </button>

                      {/* Pin */}
                      {canPin && (
                        <button
                          type="button"
                          onClick={() => onTogglePinMessage(msg.id, !msg.isPinned)}
                          title={msg.isPinned ? 'Unpin message' : 'Pin message'}
                          className={`p-1 rounded hover:bg-slate-800 ${msg.isPinned ? 'text-amber-400' : 'text-slate-400 hover:text-white'}`}
                        >
                          <Pin className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {/* Delete */}
                      {canDelete && (
                        <button
                          type="button"
                          onClick={() => onDeleteMessage(msg.id)}
                          title="Delete message"
                          className="p-1 text-rose-400 hover:text-rose-300 rounded hover:bg-rose-950/50"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Reply Reference Preview */}
                  {msg.replyToText && (
                    <div className="my-1 pl-2 border-l-2 border-indigo-500 text-[11px] text-slate-400 line-clamp-1 bg-slate-900/50 py-0.5 rounded-r">
                      Replying to: <span className="text-slate-300 italic">{msg.replyToText}</span>
                    </div>
                  )}

                  {/* Message Body */}
                  <p className="text-xs md:text-sm text-slate-200 mt-1 whitespace-pre-wrap leading-relaxed">
                    {msg.text}
                  </p>

                  {/* Attachments */}
                  {msg.attachments && msg.attachments.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                      {msg.attachments.map((att, i) => (
                        <div
                          key={i}
                          className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between gap-2 text-xs"
                        >
                          <div className="flex items-center gap-2 truncate">
                            <FileText className="w-4 h-4 text-indigo-400 shrink-0" />
                            <span className="text-white truncate font-medium">{att.name}</span>
                          </div>
                          <a
                            href={att.url}
                            download={att.name}
                            className="p-1.5 text-indigo-400 hover:text-white hover:bg-indigo-600 rounded-lg transition-colors"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Reactions */}
                  {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {Object.entries(msg.reactions).map(([emoji, userList]) => {
                        const users = (userList || []) as string[];
                        const hasReacted = users.includes(userProfile?.uid || '');
                        return (
                          <button
                            key={emoji}
                            type="button"
                            onClick={() => onToggleReaction(msg.id, emoji)}
                            className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs transition-colors ${
                              hasReacted 
                                ? 'bg-indigo-600/30 border border-indigo-500/50 text-indigo-200' 
                                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            <span>{emoji}</span>
                            <span className="text-[10px] font-bold">{users.length}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {/* Messenger Delivery Status & Count Under Message */}
                  <div className="flex items-center gap-2 mt-2 pt-1.5 border-t border-slate-800/40 text-[10px] text-slate-400 select-none">
                    <div className="flex items-center gap-1 font-medium">
                      {msg.status === 'sending' ? (
                        <>
                          <Clock className="w-3 h-3 text-amber-400 animate-spin" />
                          <span className="text-amber-400">Sending...</span>
                        </>
                      ) : (
                        <>
                          <CheckCheck className="w-3.5 h-3.5 text-cyan-400 stroke-[2.5]" />
                          <span className="text-cyan-400 font-semibold">Delivered</span>
                        </>
                      )}
                    </div>
                    <span className="text-slate-600">•</span>
                    <div className="flex items-center gap-1 font-mono text-[10px]">
                      <span className="text-slate-400">Delivered:</span>
                      <span className="px-1.5 py-0.2 rounded bg-slate-800/90 text-cyan-300 font-bold border border-cyan-500/30">
                        Msg #{msg.deliveredCount ?? (index + 1)}
                      </span>
                    </div>
                    <span className="text-slate-600 hidden sm:inline">•</span>
                    <span className="text-[10px] text-slate-400 hidden sm:inline flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
                      Saved to cloud forever
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Replying Banner */}
      {replyingTo && (
        <div className="px-4 py-2 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between text-xs text-slate-300">
          <div className="flex items-center gap-2 truncate">
            <Reply className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span>Replying to <strong>{replyingTo.userName}</strong>:</span>
            <span className="text-slate-400 truncate italic">{replyingTo.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setReplyingTo(null)}
            className="p-1 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Attachments Preview Queue */}
      {attachments.length > 0 && (
        <div className="px-4 py-2 bg-slate-900 border-t border-slate-800 flex items-center gap-2 overflow-x-auto">
          {attachments.map((att, idx) => (
            <div key={idx} className="flex items-center gap-2 px-2.5 py-1 bg-slate-950 border border-slate-800 rounded-lg text-xs">
              <span className="truncate max-w-[150px] text-slate-200">{att.name}</span>
              <button
                type="button"
                onClick={() => setAttachments(attachments.filter((_, i) => i !== idx))}
                className="text-slate-400 hover:text-rose-400"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Message Input Box */}
      <div className="p-4 border-t border-slate-800 bg-slate-900/40 shrink-0">
        <form onSubmit={handleSend} className="flex items-center gap-2">
          {/* File attachment button */}
          <input
            type="file"
            multiple
            ref={fileInputRef}
            onChange={handleFileUpload}
            className="hidden"
          />
          <button
            id="chat-attach-file-btn"
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title="Attach study files or screenshots"
            className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors shrink-0"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          {/* Text Input */}
          <div className="flex-1 relative">
            <input
              id="channel-chat-input"
              type="text"
              placeholder={`Message #${channel.name}...`}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs md:text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Submit Button */}
          <button
            id="channel-send-message-btn"
            type="submit"
            disabled={!inputText.trim() && attachments.length === 0}
            className="p-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-xl shadow-md shadow-indigo-600/30 transition-all disabled:opacity-40 disabled:hover:from-indigo-600 shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
