import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Users, 
  Search, 
  MessageSquare, 
  Shield, 
  CheckCircle2, 
  BookOpen, 
  Mail, 
  Sparkles,
  Award,
  Filter,
  X
} from 'lucide-react';
import { UserProfile, UserStatus } from '../../types';

interface ClassmateDirectoryProps {
  allUsers: UserProfile[];
  onStartDirectMessage: (user: UserProfile) => void;
}

export const ClassmateDirectory: React.FC<ClassmateDirectoryProps> = ({
  allUsers,
  onStartDirectMessage
}) => {
  const { userProfile, isAdmin } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredUsers = allUsers.filter((u) => {
    if (filterStatus !== 'all' && u.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = u.displayName.toLowerCase().includes(q);
      const matchEmail = u.email.toLowerCase().includes(q);
      const matchMajor = u.major?.toLowerCase().includes(q) || false;
      const matchBio = u.bio?.toLowerCase().includes(q) || false;
      return matchName || matchEmail || matchMajor || matchBio;
    }
    return true;
  });

  const getStatusBadge = (status?: UserStatus) => {
    switch (status) {
      case 'online': return { label: 'Online Now', bg: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30 shadow-sm shadow-emerald-500/10' };
      case 'studying': return { label: 'Studying', bg: 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30 shadow-sm shadow-indigo-500/10' };
      case 'in_class': return { label: 'In Class', bg: 'bg-amber-500/15 text-amber-400 border-amber-500/30 shadow-sm shadow-amber-500/10' };
      case 'busy': return { label: 'Busy / Do Not Disturb', bg: 'bg-rose-500/15 text-rose-400 border-rose-500/30' };
      default: return { label: 'Offline', bg: 'bg-slate-800/80 text-slate-400 border-slate-700/80' };
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
      {/* Modern Header */}
      <div className="p-4 md:p-6 border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md shrink-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-600 via-teal-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-600/25 border border-cyan-400/20">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-white tracking-tight">Classmate Directory</h1>
                <span className="text-[10px] px-2.5 py-0.5 bg-cyan-500/20 text-cyan-300 font-extrabold rounded-full border border-cyan-500/30">
                  {allUsers.length} Enrolled
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Browse student profiles, custom avatars, study majors, and start live direct messaging
              </p>
            </div>
          </div>

          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              id="directory-search-input"
              type="text"
              placeholder="Search classmates by name, major, email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-800 rounded-2xl pl-10 pr-9 py-2.5 text-xs text-white placeholder:text-slate-400 focus:outline-none focus:border-cyan-500 transition-colors shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Status filters */}
        <div className="flex items-center gap-2 mt-5 overflow-x-auto pb-1 text-xs">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1 mr-1">
            <Filter className="w-3 h-3" />
            Filter:
          </span>
          {['all', 'online', 'studying', 'in_class', 'busy', 'offline'].map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setFilterStatus(st)}
              className={`px-3 py-1.5 rounded-xl border capitalize transition-all shrink-0 cursor-pointer text-xs ${
                filterStatus === st 
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white border-cyan-500 font-semibold shadow-md shadow-cyan-600/25' 
                  : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              {st.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Directory Grid */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredUsers.length === 0 ? (
          <div className="col-span-full py-16 flex flex-col items-center justify-center text-center text-slate-400">
            <Users className="w-12 h-12 text-slate-400 mb-3" />
            <p className="text-sm font-semibold text-slate-300">No classmates found matching filter</p>
            <p className="text-xs text-slate-400 mt-1">Try changing your search terms or status filter</p>
          </div>
        ) : (
          filteredUsers.map((user) => {
            const statusBadge = getStatusBadge(user.status);
            const isSelf = user.uid === userProfile?.uid;

            return (
              <div
                key={user.uid}
                id={`classmate-card-${user.uid}`}
                className="bg-slate-900/90 border border-slate-800/90 hover:border-indigo-500/40 rounded-3xl p-5 flex flex-col justify-between space-y-4 transition-all group shadow-sm hover:shadow-xl hover:shadow-indigo-500/5 backdrop-blur-md relative overflow-hidden"
              >
                {/* Subtle top glow accent for verified/admin */}
                {user.role === 'admin' && (
                  <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500" />
                )}

                <div>
                  {/* Avatar & Role Header */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3.5">
                      <div className="relative">
                        <div className="w-14 h-14 rounded-2xl p-0.5 bg-gradient-to-tr from-indigo-500 via-purple-500 to-cyan-500 shadow-md">
                          <img
                            src={user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`}
                            alt={user.displayName}
                            className="w-full h-full rounded-[14px] object-cover bg-slate-900"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <span className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-slate-900 ${
                          user.status === 'online' ? 'bg-emerald-500 ring-2 ring-emerald-500/20' :
                          user.status === 'studying' ? 'bg-indigo-500 ring-2 ring-indigo-500/20 animate-pulse' :
                          user.status === 'in_class' ? 'bg-amber-500' :
                          user.status === 'busy' ? 'bg-rose-500' : 'bg-slate-600'
                        }`} />
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors truncate max-w-[140px]">
                            {user.displayName}
                          </h3>
                          {user.isVerified && (
                            <span title="Verified Classmate" className="inline-flex items-center">
                              <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Mail className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate max-w-[140px]">{user.email}</span>
                        </div>
                      </div>
                    </div>

                    {user.role === 'admin' && (
                      <span className="text-[10px] font-extrabold px-2 py-0.5 bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-md shrink-0 shadow-sm">
                        ADMIN
                      </span>
                    )}
                    {user.role === 'moderator' && (
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-purple-600/30 text-purple-300 border border-purple-500/30 rounded-md shrink-0">
                        MOD
                      </span>
                    )}
                  </div>

                  {/* Major & Year */}
                  <div className="p-3 bg-slate-950/70 rounded-2xl border border-slate-800/80 text-xs space-y-1.5">
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-400 flex items-center gap-1">
                        <BookOpen className="w-3 h-3 text-indigo-400" />
                        <span>Major:</span>
                      </span>
                      <span className="font-semibold text-white truncate max-w-[160px]">{user.major || 'Computer Science'}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-400 flex items-center gap-1">
                        <Award className="w-3 h-3 text-violet-400" />
                        <span>Class Level:</span>
                      </span>
                      <span className="font-medium text-slate-200">{user.year || 'Year 2'}</span>
                    </div>
                  </div>

                  {/* Bio / Status message */}
                  <p className="text-xs text-slate-400 line-clamp-2 mt-3 leading-relaxed">
                    {user.customStatusMessage || user.bio || 'Classmate actively collaborating on assignments & study groups.'}
                  </p>
                </div>

                {/* Bottom Actions */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <span className={`text-[10px] font-semibold px-2.5 py-1 rounded-xl border ${statusBadge.bg}`}>
                    {statusBadge.label}
                  </span>

                  {isSelf ? (
                    <span className="text-[11px] text-indigo-300 font-medium bg-indigo-500/10 px-2.5 py-1 rounded-xl border border-indigo-500/20">
                      You (Current User)
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onStartDirectMessage(user)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/20 hover:bg-gradient-to-r hover:from-indigo-600 hover:to-violet-600 text-indigo-300 hover:text-white rounded-xl text-xs font-semibold transition-all border border-indigo-500/30 hover:border-transparent cursor-pointer active:scale-95 shadow-sm"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Direct Chat</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
