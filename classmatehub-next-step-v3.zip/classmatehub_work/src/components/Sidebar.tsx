import React from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Hash, 
  MessageSquare, 
  Lock, 
  HardDrive, 
  Sparkles, 
  Timer, 
  CheckSquare, 
  Users, 
  BarChart2, 
  Shield, 
  ShieldCheck, 
  Download, 
  Plus, 
  Volume2, 
  BookOpen, 
  FolderLock,
  GraduationCap,
  LogOut,
  User
} from 'lucide-react';
import { SchoolLogo } from './SchoolLogo';
import { Channel } from '../types';

export type ActiveTab = 
  | 'channels' 
  | 'direct-messages' 
  | 'storage-locker' 
  | 'ai-assistant' 
  | 'study-hub' 
  | 'assignments' 
  | 'directory' 
  | 'polls' 
  | 'admin';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  channels: Channel[];
  selectedChannelId: string;
  onSelectChannel: (channelId: string) => void;
  onOpenCreateChannel: () => void;
  onOpenTestModal: () => void;
  onOpenInstallModal: () => void;
  unreadCountMap: Record<string, number>;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  onOpenAuth?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  channels,
  selectedChannelId,
  onSelectChannel,
  onOpenCreateChannel,
  onOpenTestModal,
  onOpenInstallModal,
  unreadCountMap,
  isOpenMobile,
  onCloseMobile,
  onOpenAuth
}) => {
  const { userProfile, logout, isAdmin, isSuperAdmin } = useAuth();

  const handleTabClick = (tab: ActiveTab) => {
    setActiveTab(tab);
    onCloseMobile();
  };

  const handleChannelClick = (channelId: string) => {
    setActiveTab('channels');
    onSelectChannel(channelId);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div 
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-30 lg:hidden animate-in fade-in"
          onClick={onCloseMobile}
        />
      )}

      <aside className={`
        fixed lg:static top-16 bottom-0 left-0 z-40 w-72 bg-slate-900/95 lg:bg-slate-900/80 backdrop-blur-xl border-r border-slate-800/80 flex flex-col transition-all duration-200 ease-in-out shrink-0
        ${isOpenMobile ? 'translate-x-0 shadow-2xl' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Mobile Header Branding inside Drawer */}
        <div className="p-3 border-b border-slate-800/80 lg:hidden flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <SchoolLogo size="sm" showRing={true} />
            <div className="flex flex-col">
              <span className="font-extrabold text-white text-sm font-['Outfit',sans-serif] leading-tight">
                11 Graders
              </span>
              <span className="text-amber-400 font-['Cinzel',serif] tracking-[0.14em] text-xs font-bold leading-tight">
                OF RICA
              </span>
            </div>
          </div>
          <span className="text-[10px] px-2 py-0.5 bg-amber-500/15 text-amber-300 font-bold rounded-md border border-amber-500/30">
            RICA
          </span>
        </div>

        {/* Navigation Sections */}
        <div className="flex-1 overflow-y-auto p-3 space-y-6">
          {/* Main App Portals */}
          <div className="space-y-1">
            <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Campus Workspaces
            </div>

            <button
              id="sidebar-tab-storage"
              type="button"
              onClick={() => handleTabClick('storage-locker')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'storage-locker' 
                  ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-600/30' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <FolderLock className={`w-4 h-4 ${activeTab === 'storage-locker' ? 'text-white' : 'text-indigo-400'}`} />
                <span>Cloud Storage Locker</span>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-medium ${activeTab === 'storage-locker' ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'}`}>
                Files & Notes
              </span>
            </button>

            <button
              id="sidebar-tab-ai-assistant"
              type="button"
              onClick={() => handleTabClick('ai-assistant')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'ai-assistant' 
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/25 font-bold' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <GraduationCap className={`w-4 h-4 ${activeTab === 'ai-assistant' ? 'text-slate-950' : 'text-amber-400'}`} />
                <span>AI Problem Solver</span>
              </div>
              <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase ${activeTab === 'ai-assistant' ? 'bg-slate-950/20 text-slate-950' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'}`}>
                Solver
              </span>
            </button>

            <button
              id="sidebar-tab-study-hub"
              type="button"
              onClick={() => handleTabClick('study-hub')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'study-hub' 
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-600/30' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Timer className={`w-4 h-4 ${activeTab === 'study-hub' ? 'text-white' : 'text-emerald-400'}`} />
                <span>Study Hub & Pomodoro</span>
              </div>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400/50" />
            </button>

            <button
              id="sidebar-tab-assignments"
              type="button"
              onClick={() => handleTabClick('assignments')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'assignments' 
                  ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-lg shadow-amber-600/30' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <CheckSquare className={`w-4 h-4 ${activeTab === 'assignments' ? 'text-white' : 'text-amber-400'}`} />
                <span>Assignments & Deadlines</span>
              </div>
            </button>

            <button
              id="sidebar-tab-directory"
              type="button"
              onClick={() => handleTabClick('directory')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'directory' 
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-lg shadow-cyan-600/30' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Users className={`w-4 h-4 ${activeTab === 'directory' ? 'text-white' : 'text-cyan-400'}`} />
                <span>Classmates Directory</span>
              </div>
              <span className="text-[10px] text-cyan-300 font-bold bg-cyan-500/10 px-1.5 py-0.5 rounded-md">
                Live
              </span>
            </button>

            <button
              id="sidebar-tab-direct-messages"
              type="button"
              onClick={() => handleTabClick('direct-messages')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'direct-messages' 
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-600/30' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <MessageSquare className={`w-4 h-4 ${activeTab === 'direct-messages' ? 'text-white' : 'text-blue-400'}`} />
                <span>Direct Messages</span>
              </div>
            </button>

            <button
              id="sidebar-tab-polls"
              type="button"
              onClick={() => handleTabClick('polls')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'polls' 
                  ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-lg shadow-teal-600/30' 
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <BarChart2 className={`w-4 h-4 ${activeTab === 'polls' ? 'text-white' : 'text-teal-400'}`} />
                <span>Class Polls & Voting</span>
              </div>
            </button>
          </div>

          {/* Class Channels Section */}
          <div className="space-y-1">
            <div className="flex items-center justify-between px-3 py-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Class Channels
              </span>
              {(isAdmin || isSuperAdmin) && (
                <button
                  id="create-channel-btn"
                  type="button"
                  onClick={onOpenCreateChannel}
                  title="Create New Channel (Admin)"
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="space-y-1">
              {channels.map((ch) => {
                const isSelected = activeTab === 'channels' && selectedChannelId === ch.id;
                const unread = unreadCountMap[ch.id] || 0;
                return (
                  <button
                    key={ch.id}
                    id={`channel-btn-${ch.id}`}
                    type="button"
                    onClick={() => handleChannelClick(ch.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800/90 text-white font-semibold border-l-2 border-indigo-500 shadow-sm'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      {ch.isPrivate ? (
                        <Lock className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-amber-400' : 'text-amber-500/70'}`} />
                      ) : (
                        <Hash className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-indigo-400' : 'text-slate-400'}`} />
                      )}
                      <span className="truncate">{ch.name}</span>
                    </div>
                    {unread > 0 && (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 bg-indigo-600 text-white rounded-full">
                        {unread}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Admin & Security Section */}
          {(isAdmin || isSuperAdmin) && (
            <div className="space-y-1 pt-2 border-t border-slate-800/80">
              <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" />
                <span>Admin Administration</span>
              </div>

              <button
                id="sidebar-tab-admin"
                type="button"
                onClick={() => handleTabClick('admin')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'admin' 
                    ? 'bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-600/30' 
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Shield className={`w-4 h-4 ${activeTab === 'admin' ? 'text-white' : 'text-indigo-400'}`} />
                  <span>Admin Master Console</span>
                </div>
                <span className="text-[9px] px-1.5 py-0.5 bg-white/20 text-white rounded-md font-bold">
                  MASTER
                </span>
              </button>
            </div>
          )}
        </div>

        {/* Sidebar Footer Controls */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/50 space-y-2 shrink-0">
          {userProfile ? (
            <div className="flex items-center justify-between p-2 bg-slate-900/90 border border-slate-800 rounded-2xl">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-xl overflow-hidden shrink-0 bg-slate-800 border border-slate-700">
                  <img
                    src={userProfile.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${userProfile.uid}`}
                    alt={userProfile.displayName}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white truncate max-w-[120px]">{userProfile.displayName}</div>
                  <div className="text-[10px] text-slate-400 capitalize">{userProfile.role}</div>
                </div>
              </div>
              <button
                id="sidebar-signout-btn"
                type="button"
                onClick={async () => {
                  await logout();
                  onCloseMobile();
                }}
                title="Sign Out of Account"
                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors cursor-pointer shrink-0"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              id="sidebar-signin-btn"
              type="button"
              onClick={() => {
                onOpenAuth?.();
                onCloseMobile();
              }}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
            >
              <User className="w-3.5 h-3.5" />
              <span>Sign In / Register</span>
            </button>
          )}

          <div className="grid grid-cols-2 gap-2">
            {isAdmin ? (
              <button
                id="sidebar-run-tests-btn"
                type="button"
                onClick={() => {
                  onOpenTestModal();
                  onCloseMobile();
                }}
                className="flex items-center justify-center gap-1.5 p-2 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-xl text-[11px] font-semibold text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>System Suite</span>
              </button>
            ) : (
              <button
                id="sidebar-share-app-btn"
                type="button"
                onClick={() => {
                  onOpenInstallModal();
                  onCloseMobile();
                }}
                className="flex items-center justify-center gap-1.5 p-2 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-xl text-[11px] font-semibold text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Invite Class</span>
              </button>
            )}

            <button
              id="sidebar-install-app-btn"
              type="button"
              onClick={() => {
                onOpenInstallModal();
                onCloseMobile();
              }}
              className="flex items-center justify-center gap-1.5 p-2 bg-indigo-600/15 hover:bg-indigo-600/30 border border-indigo-500/30 rounded-xl text-[11px] font-semibold text-indigo-300 hover:text-white transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              <span>Install PWA</span>
            </button>
          </div>

          <div className="pt-2 border-t border-slate-800/60 text-center">
            <p className="text-[11px] text-slate-400 font-medium">
              Proudly made by <span className="text-indigo-400 font-bold">Ebenezer Kruah</span>
            </p>
          </div>
        </div>
      </aside>
    </>
  );
};
