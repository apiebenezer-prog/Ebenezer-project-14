import React, { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { SchoolLogo } from '../SchoolLogo';
import { 
  Shield, 
  Sparkles, 
  Lock, 
  Mail, 
  User, 
  AlertCircle, 
  ArrowRight, 
  ExternalLink,
  Camera,
  Upload,
  RefreshCw,
  Check,
  Eye,
  EyeOff,
  BookOpen,
  Calendar,
  X,
  Image as ImageIcon
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_AVATARS = [
  { id: 'av-1', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', label: 'Ebenezer' },
  { id: 'av-2', url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80', label: 'Sarah' },
  { id: 'av-3', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', label: 'Marcus' },
  { id: 'av-4', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', label: 'Elena' },
  { id: 'av-5', url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80', label: 'Aria' },
  { id: 'av-6', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80', label: 'David' },
];

const MAJORS = [
  'Computer Science & Engineering',
  'Software Engineering & DevOps',
  'Data Science & Artificial Intelligence',
  'Electrical & Electronic Engineering',
  'Mechanical Engineering',
  'Medicine & Health Sciences',
  'Business Administration & Finance',
  'Design, UX & Architecture',
  'Law & Public Policy',
  'Other / General Studies'
];

const YEARS = [
  'Year 1 (Freshman)',
  'Year 2 (Sophomore)',
  'Year 3 (Junior)',
  'Year 4 (Senior / Finalist)',
  'Master\'s Candidate',
  'PhD / Researcher',
  'Faculty / Instructor'
];

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { signInWithGoogle, signInWithEmail, signUpWithEmail, loginAsDemoUser } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup' | 'demo'>('signin');
  
  // Form fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState('');
  const [major, setMajor] = useState(MAJORS[0]);
  const [year, setYear] = useState(YEARS[1]);
  const [bio, setBio] = useState('');
  
  // Avatar upload state
  const [photoURL, setPhotoURL] = useState<string>('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80');
  const [isCustomUpload, setIsCustomUpload] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle local image file upload & compression
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file (PNG, JPG, WEBP, GIF).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setError('Image file is too large. Please select a photo under 5MB.');
      return;
    }

    setUploadProgress(true);
    setError(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Draw to a canvas to resize to square 200x200 for lightning performance
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const size = 250;
        canvas.width = size;
        canvas.height = size;

        // Calculate aspect fill crop
        const minDim = Math.min(img.width, img.height);
        const startX = (img.width - minDim) / 2;
        const startY = (img.height - minDim) / 2;

        if (ctx) {
          ctx.drawImage(img, startX, startY, minDim, minDim, 0, 0, size, size);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.88);
          setPhotoURL(compressedDataUrl);
          setIsCustomUpload(true);
        }
        setUploadProgress(false);
      };
      img.onerror = () => {
        setError('Failed to process image file.');
        setUploadProgress(false);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleRandomizeAvatar = () => {
    const randomSeed = Math.random().toString(36).substring(2, 9);
    const dicebearUrl = `https://api.dicebear.com/7.x/bottts/svg?seed=${randomSeed}&radius=50`;
    setPhotoURL(dicebearUrl);
    setIsCustomUpload(true);
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      await signInWithGoogle();
      onClose();
    } catch (err: any) {
      console.error('Sign-in error:', err);
      setError('Google Sign-In notice: Sandbox popup was blocked or restricted. You can continue below or open in a new tab.');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      if (mode === 'signup') {
        if (!name.trim()) throw new Error('Please enter your full name');
        if (!photoURL) throw new Error('Please choose or upload a profile picture');
        await signUpWithEmail(email, password, name, photoURL, major, year, bio || `${major} student at Classmate Hub`);
      } else {
        await signInWithEmail(email, password);
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async (role: 'admin' | 'student' | 'moderator', customName?: string, customPic?: string) => {
    setLoading(true);
    try {
      await loginAsDemoUser(role, customName, customPic);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  const openAppInNewTab = () => {
    window.open(window.location.href, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div 
        id="auth-modal-card"
        className="w-full max-w-lg bg-slate-900/95 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden my-auto"
      >
        {/* Glow ambient background accents */}
        <div className="absolute -top-32 -right-32 w-64 h-64 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-32 -left-32 w-64 h-64 bg-violet-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between mb-6 relative z-10">
          <div className="flex items-center gap-3">
            <SchoolLogo size="lg" showRing={true} />
            <div className="flex flex-col justify-center">
              <div className="flex items-center gap-2">
                <div className="flex flex-col">
                  <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight leading-tight font-['Outfit',sans-serif]">
                    11 Graders
                  </h2>
                  <span className="text-amber-400 font-['Cinzel',serif] tracking-widest text-sm sm:text-base font-bold drop-shadow-[0_0_10px_rgba(251,191,36,0.3)] leading-tight">
                    OF RICA
                  </span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-500/15 text-amber-300 rounded-full border border-amber-500/30 leading-none self-center">
                  RICA Portal
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed mt-1">Class of 11th Grade Study Network &amp; Cloud Locker</p>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={openAppInNewTab}
              title="Open in new browser tab for direct Google login"
              className="p-2 text-slate-400 hover:text-indigo-300 hover:bg-slate-800/80 rounded-xl transition-colors flex items-center gap-1 text-xs"
            >
              <ExternalLink className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-xl transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-5 p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-between gap-2.5 text-amber-300 text-xs">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
            <button
              type="button"
              onClick={() => setError(null)}
              className="text-[11px] font-semibold text-amber-400 hover:text-amber-200 shrink-0 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Mode switcher tabs */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950/80 rounded-2xl border border-slate-800/80 mb-6 text-xs font-semibold">
          <button
            id="auth-tab-signin"
            type="button"
            onClick={() => { setMode('signin'); setError(null); }}
            className={`py-2.5 rounded-xl transition-all ${mode === 'signin' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Sign In
          </button>
          <button
            id="auth-tab-signup"
            type="button"
            onClick={() => { setMode('signup'); setError(null); }}
            className={`py-2.5 rounded-xl transition-all ${mode === 'signup' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            New Account
          </button>
          <button
            id="auth-tab-demo"
            type="button"
            onClick={() => { setMode('demo'); setError(null); }}
            className={`py-2.5 rounded-xl transition-all ${mode === 'demo' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            Demo Profiles
          </button>
        </div>

        {/* 1. REGISTRATION FORM WITH PROFILE PICTURE UPLOAD */}
        {mode === 'signup' && (
          <form onSubmit={handleEmailSubmit} className="space-y-4 max-h-[62vh] overflow-y-auto pr-1">
            {/* Profile Picture Upload Section */}
            <div className="bg-slate-950/70 border border-slate-800/90 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Camera className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Choose or Upload Profile Picture</span>
                </label>
                <span className="text-[10px] text-emerald-400 font-medium bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                  Ready to preview
                </span>
              </div>

              {/* Main Avatar Display & Upload Actions */}
              <div className="flex items-center gap-4">
                <div className="relative group">
                  <div className="w-18 h-18 sm:w-20 sm:h-20 rounded-2xl p-1 bg-gradient-to-tr from-indigo-500 to-violet-500 shadow-xl shadow-indigo-500/20">
                    <img
                      src={photoURL}
                      alt="Profile preview"
                      className="w-full h-full rounded-xl object-cover bg-slate-900"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  {uploadProgress && (
                    <div className="absolute inset-0 bg-slate-950/80 rounded-2xl flex items-center justify-center">
                      <RefreshCw className="w-5 h-5 text-indigo-400 animate-spin" />
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute -bottom-1 -right-1 p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl shadow-lg border-2 border-slate-900 transition-all active:scale-95 cursor-pointer"
                    title="Upload photo from device"
                  >
                    <Camera className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex-1 space-y-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageFileChange}
                    className="hidden"
                  />
                  
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded-xl text-xs font-semibold transition-all active:scale-95 cursor-pointer"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload from Device</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleRandomizeAvatar}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-xl text-xs font-medium transition-all active:scale-95 cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Randomize</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Supports JPG, PNG, WEBP. Cropped & optimized automatically.
                  </p>
                </div>
              </div>

              {/* Preset Avatar Selector Gallery */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="text-[11px] font-semibold text-slate-400 mb-2">Or select from curated student presets:</div>
                <div className="grid grid-cols-6 gap-2">
                  {PRESET_AVATARS.map((av) => (
                    <button
                      key={av.id}
                      type="button"
                      onClick={() => {
                        setPhotoURL(av.url);
                        setIsCustomUpload(false);
                      }}
                      className={`relative rounded-xl overflow-hidden aspect-square border-2 transition-all cursor-pointer ${
                        photoURL === av.url && !isCustomUpload
                          ? 'border-indigo-500 ring-2 ring-indigo-500/30 scale-105' 
                          : 'border-slate-800 hover:border-slate-600 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img 
                        src={av.url} 
                        alt={av.label} 
                        className="w-full h-full object-cover" 
                        referrerPolicy="no-referrer"
                      />
                      {photoURL === av.url && !isCustomUpload && (
                        <div className="absolute inset-0 bg-indigo-600/30 flex items-center justify-center">
                          <Check className="w-3.5 h-3.5 text-white" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Name Input */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Full Name *</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  id="signup-name-input"
                  type="text"
                  required
                  placeholder="e.g. Ebenezer Api"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>
            </div>

            {/* Email Input */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Campus / Personal Email *</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  id="auth-email-input"
                  type="email"
                  required
                  placeholder="student@university.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>
            </div>

            {/* Password Input */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Password *</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  id="auth-password-input"
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-10 py-2.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Major and Year Dual Selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1 flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Major / Field</span>
                </label>
                <select
                  value={major}
                  onChange={(e) => setMajor(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  {MAJORS.map((m) => (
                    <option key={m} value={m} className="bg-slate-900 text-white">{m}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-violet-400" />
                  <span>Academic Level</span>
                </label>
                <select
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  {YEARS.map((y) => (
                    <option key={y} value={y} className="bg-slate-900 text-white">{y}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Optional Bio */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Study Bio (Optional)</label>
              <input
                type="text"
                placeholder="e.g. Preparing for software engineering & group study"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>

            {/* Submit Button */}
            <button
              id="auth-signup-submit-btn"
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-sm font-semibold rounded-2xl shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer active:scale-[0.99]"
            >
              <span>{loading ? 'Creating Profile...' : 'Complete Registration'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* 2. SIGN IN FORM */}
        {mode === 'signin' && (
          <div className="space-y-4">
            {/* Google Sign-in button */}
            <button
              id="google-signin-btn"
              type="button"
              disabled={loading}
              onClick={handleGoogleSignIn}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-white hover:bg-slate-100 text-slate-900 font-semibold text-sm rounded-2xl transition-all shadow-md active:scale-[0.99] disabled:opacity-50 cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
              </svg>
              <span>Continue with Google</span>
            </button>

            <div className="flex items-center gap-3 my-4">
              <div className="h-px flex-1 bg-slate-800" />
              <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">Or with Email</span>
              <div className="h-px flex-1 bg-slate-800" />
            </div>

            <form onSubmit={handleEmailSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="auth-email-input"
                    type="email"
                    required
                    placeholder="your.email@school.edu"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    id="auth-password-input"
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-10 py-2.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                id="auth-submit-btn"
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-sm font-semibold rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
              >
                <span>{loading ? 'Authenticating...' : 'Sign In to Campus Hub'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        {/* 3. MULTI-DEVICE DEMO PROFILES */}
        {mode === 'demo' && (
          <div className="space-y-3">
            <p className="text-xs text-slate-400 mb-2">
              Instantly test multi-device role synchronization with pre-configured classmate profiles:
            </p>

            <button
              id="demo-login-student"
              type="button"
              disabled={loading}
              onClick={() => handleDemoLogin('student', 'Sarah Ching', 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80')}
              className="w-full p-3.5 bg-slate-950 border border-slate-800 hover:border-emerald-500/50 rounded-2xl flex items-center justify-between text-left group transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80"
                    alt="Sarah Ching"
                    className="w-10 h-10 rounded-xl object-cover border border-emerald-400/40"
                  />
                  <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors flex items-center gap-1.5">
                    <span>Sarah Ching</span>
                    <span className="text-[10px] px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded font-medium">Demo Classmate</span>
                  </div>
                  <div className="text-xs text-slate-400">Class chat, cloud storage, study groups & assignments</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              id="demo-login-admin"
              type="button"
              disabled={loading}
              onClick={() => handleDemoLogin('admin', 'Ebenezer (Administrator)', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80')}
              className="w-full p-3.5 bg-indigo-950/40 border border-indigo-500/40 hover:border-indigo-500 rounded-2xl flex items-center justify-between text-left group transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
                    alt="Ebenezer"
                    className="w-10 h-10 rounded-xl object-cover border border-indigo-400/40"
                  />
                  <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors flex items-center gap-1.5">
                    <span>Ebenezer</span>
                    <span className="text-[10px] px-1.5 py-0.5 bg-indigo-500 text-white rounded font-bold">Administrator</span>
                  </div>
                  <div className="text-xs text-slate-400">Admin master console, channel moderation & user audit</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-indigo-400 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400 relative z-10">
          <span className="flex items-center gap-1.5 text-[11px]">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Proudly made by <strong className="text-indigo-400">Ebenezer Kruah</strong></span>
          </span>
          <button 
            type="button" 
            onClick={onClose}
            className="hover:text-slate-200 transition-colors cursor-pointer text-[11px]"
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
};
