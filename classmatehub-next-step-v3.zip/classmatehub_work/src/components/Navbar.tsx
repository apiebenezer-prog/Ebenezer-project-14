import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { SchoolLogo } from './SchoolLogo';
import { 
  Smartphone, 
  Monitor, 
  Tablet, 
  ShieldCheck, 
  Download, 
  LogOut, 
  User, 
  Bell, 
  Menu, 
  Check, 
  HardDrive,
  Sparkles,
  ChevronDown,
  Camera,
  Edit3,
  ExternalLink,
  Share2,
  Zap,
  FileArchive
} from 'lucide-react';
import { UserStatus } from '../types';

interface NavbarProps {
  onOpenAuth: () => void;
  onOpenEditProfile: () => void;
  onOpenTestModal: () => void;
  onOpenInstallModal: () => void;
  onToggleMobileSidebar: () => void;
  unreadAnnouncementsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAuth,
  onOpenEditProfile,
  onOpenTestModal,
  onOpenInstallModal,
  onToggleMobileSidebar,
  unreadAnnouncementsCount
}) => {
  const { userProfile, logout, updateUserStatus, isAdmin, isSuperAdmin } = useAuth();
  const [deviceType, setDeviceType] = useState<'ios' | 'android' | 'desktop' | 'tablet'>('desktop');
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const [dataSaverActive, setDataSaverActive] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('rica_data_saver_mode');
      if (saved !== null) return saved === 'true';
      return true; // Active by default for minimal data consumption
    } catch {
      return true;
    }
  });

  const toggleDataSaver = () => {
    const nextState = !dataSaverActive;
    setDataSaverActive(nextState);
    try {
      localStorage.setItem('rica_data_saver_mode', String(nextState));
    } catch {}
  };

  useEffect(() => {
    const ua = navigator.userAgent;
    if (/iPad|iPhone|iPod/.test(ua)) setDeviceType('ios');
    else if (/android/i.test(ua)) setDeviceType('android');
    else if (/tablet/i.test(ua)) setDeviceType('tablet');
    else setDeviceType('desktop');
  }, []);

  const getStatusColor = (status?: UserStatus) => {
    switch (status) {
      case 'online': return 'bg-emerald-500 shadow-emerald-500/50 shadow-sm';
      case 'studying': return 'bg-indigo-500 shadow-indigo-500/50 shadow-sm animate-pulse';
      case 'in_class': return 'bg-amber-500 shadow-amber-500/50 shadow-sm';
      case 'busy': return 'bg-rose-500 shadow-rose-500/50 shadow-sm';
      default: return 'bg-slate-500';
    }
  };

  const getStatusLabel = (status?: UserStatus) => {
    switch (status) {
      case 'online': return 'Online';
      case 'studying': return 'Studying';
      case 'in_class': return 'In Class';
      case 'busy': return 'Busy';
      default: return 'Offline';
    }
  };

  const formatBytes = (bytes = 0) => {
    if (bytes === 0) return '0 MB';
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB / 500 MB`;
  };

  return (
    <header className="h-16 border-b border-slate-800/80 bg-slate-900/80 backdrop-blur-xl px-4 flex items-center justify-between sticky top-0 z-30 shrink-0">
      {/* Left: Mobile Menu + App Branding */}
      <div className="flex items-center gap-3">
        <button
          id="mobile-menu-toggle-btn"
          onClick={onToggleMobileSidebar}
          className="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          aria-label="Toggle navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <SchoolLogo size="sm" showRing={true} />
          <div className="flex items-center gap-2">
            <span className="text-base sm:text-lg font-black text-amber-400 font-['Cinzel',serif] tracking-[0.22em] leading-none drop-shadow-[0_0_12px_rgba(251,191,36,0.4)]">
              RICA
            </span>
            {isAdmin && (
              <span className="text-[9px] font-extrabold px-1.5 py-0.5 bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-md shadow-sm border border-indigo-400/30 leading-none self-center">
                ADMIN
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Middle: Live Device Badge & Diagnostic Suite Quick-Link */}
      <div className="hidden md:flex items-center gap-2">
        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-950/70 border border-slate-800/90 rounded-full text-xs text-slate-300 backdrop-blur-md">
          {deviceType === 'ios' && <Smartphone className="w-3.5 h-3.5 text-indigo-400" />}
          {deviceType === 'android' && <Smartphone className="w-3.5 h-3.5 text-emerald-400" />}
          {deviceType === 'tablet' && <Tablet className="w-3.5 h-3.5 text-amber-400" />}
          {deviceType === 'desktop' && <Monitor className="w-3.5 h-3.5 text-indigo-400" />}
          <span className="capitalize">{deviceType} Cloud Sync</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
        </div>

        <button
          id="navbar-run-test-btn"
          onClick={onOpenTestModal}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/60 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/60 rounded-full text-xs font-semibold transition-all hover:border-emerald-500/50 shadow-sm cursor-pointer"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>System Suite</span>
        </button>

        <button
          id="navbar-data-saver-btn"
          type="button"
          onClick={toggleDataSaver}
          title={dataSaverActive ? "Data Saver: ON (Bandwidth conservation mode)" : "Data Saver: OFF (Click to turn on)"}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all border shadow-sm cursor-pointer ${
            dataSaverActive
              ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/50 hover:bg-emerald-900/60'
              : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 border-slate-700/60'
          }`}
        >
          <Zap className={`w-3.5 h-3.5 ${dataSaverActive ? 'text-emerald-400 fill-emerald-400/30' : 'text-slate-400'}`} />
          <span>{dataSaverActive ? 'Data Saver: ON' : 'Data Saver: OFF'}</span>
          <span className="text-[10px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-mono">
            -85%
          </span>
        </button>

        <a
          id="navbar-download-zip-btn"
          href="/classmatehub-website.zip"
          download="classmatehub-website.zip"
          title="Download full website source code archive (.zip)"
          className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-semibold transition-all shadow-sm cursor-pointer"
        >
          <FileArchive className="w-3.5 h-3.5 text-amber-400" />
          <span>Download .ZIP</span>
        </a>

        <button
          id="navbar-install-btn"
          onClick={onOpenInstallModal}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600/15 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded-full text-xs font-semibold transition-all shadow-sm cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-indigo-400" />
          <span>Install PWA</span>
        </button>
      </div>

      {/* Right: User Profile / Auth Actions */}
      <div className="flex items-center gap-2">
        <button
          id="navbar-mobile-data-saver-btn"
          type="button"
          onClick={toggleDataSaver}
          className={`md:hidden flex items-center gap-1 px-2 py-1.5 rounded-xl text-xs font-semibold transition-all border cursor-pointer ${
            dataSaverActive 
              ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40' 
              : 'bg-slate-800/60 text-slate-400 border-slate-700/60'
          }`}
          title={dataSaverActive ? "Data Saver: ON (-85% data)" : "Data Saver: OFF"}
        >
          <Zap className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[10px] font-mono font-bold">-85%</span>
        </button>

        <button
          id="navbar-mobile-install-btn"
          type="button"
          onClick={onOpenInstallModal}
          className="md:hidden flex items-center gap-1 px-2.5 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded-xl text-xs font-semibold transition-all cursor-pointer"
          title="Install App"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="text-[11px]">Install</span>
        </button>

        {userProfile ? (
          <div className="relative">
            <div className="flex items-center gap-2">
              {/* Status Picker Pill */}
              <div className="relative">
                <button
                  id="status-picker-trigger"
                  type="button"
                  onClick={() => setShowStatusMenu(!showStatusMenu)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-950/80 border border-slate-800/90 hover:border-slate-700 rounded-xl text-xs text-slate-300 transition-colors cursor-pointer"
                >
                  <span className={`w-2 h-2 rounded-full ${getStatusColor(userProfile.status)}`} />
                  <span className="hidden sm:inline font-medium">{getStatusLabel(userProfile.status)}</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {showStatusMenu && (
                  <div className="absolute right-0 mt-2 w-44 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl py-1.5 z-50 text-xs animate-in fade-in zoom-in-95 backdrop-blur-xl">
                    <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Update Campus Status
                    </div>
                    {(['online', 'studying', 'in_class', 'busy'] as UserStatus[]).map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => {
                          updateUserStatus(st);
                          setShowStatusMenu(false);
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-slate-800 flex items-center justify-between transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${getStatusColor(st)}`} />
                          <span className="text-slate-200 capitalize">{getStatusLabel(st)}</span>
                        </div>
                        {userProfile.status === st && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* User Avatar Button */}
              <button
                id="user-profile-menu-btn"
                type="button"
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-2.5 p-1 pl-1.5 pr-2.5 bg-slate-800/70 hover:bg-slate-800 border border-slate-700/70 hover:border-indigo-500/40 rounded-2xl transition-all cursor-pointer shadow-sm"
              >
                <div className="relative">
                  <div className="w-8 h-8 rounded-xl p-0.5 bg-gradient-to-tr from-indigo-500 to-violet-500 overflow-hidden shadow">
                    <img
                      src={userProfile.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${userProfile.uid}`}
                      alt={userProfile.displayName}
                      className="w-full h-full rounded-[10px] object-cover bg-slate-800"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-slate-900 ${getStatusColor(userProfile.status)}`} />
                </div>
                <div className="text-left hidden sm:block">
                  <div className="text-xs font-semibold text-white leading-tight truncate max-w-[110px]">
                    {userProfile.displayName}
                  </div>
                  <div className="text-[10px] text-slate-400 capitalize">{userProfile.role}</div>
                </div>
                <ChevronDown className="w-3 h-3 text-slate-400 hidden sm:block" />
              </button>
            </div>

            {/* Profile Dropdown */}
            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-72 bg-slate-900/95 border border-slate-800 rounded-3xl shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95 backdrop-blur-xl space-y-3">
                <div className="flex items-center gap-3 pb-3 border-b border-slate-800/80">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-2xl p-0.5 bg-gradient-to-tr from-indigo-500 to-violet-500 overflow-hidden shadow-lg">
                      <img
                        src={userProfile.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${userProfile.uid}`}
                        alt={userProfile.displayName}
                        className="w-full h-full rounded-[14px] object-cover bg-slate-800"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-bold text-white truncate flex items-center gap-1.5">
                      <span>{userProfile.displayName}</span>
                      {isAdmin && <span className="text-[9px] px-1.5 py-0.2 bg-indigo-600 text-white rounded font-bold">Admin</span>}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">{userProfile.email}</div>
                    <div className="text-[10px] text-indigo-300/80 truncate mt-0.5">{userProfile.major || 'Classmate Hub Member'}</div>
                  </div>
                </div>

                {/* Cloud Storage quota meter */}
                <div className="space-y-1.5 bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 flex items-center gap-1">
                      <HardDrive className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Cloud Locker Storage</span>
                    </span>
                    <span className="font-semibold text-slate-200">{formatBytes(userProfile.storageUsedBytes)}</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full" style={{ width: '18%' }} />
                  </div>
                </div>

                <div className="pt-1 space-y-1 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      setShowProfileMenu(false);
                      onOpenEditProfile();
                    }}
                    className="w-full px-3 py-2.5 text-left text-slate-200 hover:text-white hover:bg-indigo-600/20 hover:border-indigo-500/30 border border-transparent rounded-xl flex items-center gap-2.5 transition-all cursor-pointer font-medium"
                  >
                    <Edit3 className="w-4 h-4 text-indigo-400" />
                    <span>Edit Profile & Photo</span>
                  </button>

                  {isAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        setShowProfileMenu(false);
                        onOpenTestModal();
                      }}
                      className="w-full px-3 py-2.5 text-left text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl flex items-center gap-2.5 transition-colors cursor-pointer"
                    >
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      <span>Run Diagnostic Tests</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setShowProfileMenu(false);
                      onOpenInstallModal();
                    }}
                    className="w-full px-3 py-2.5 text-left text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl flex items-center gap-2.5 transition-colors cursor-pointer"
                  >
                    <Share2 className="w-4 h-4 text-indigo-400" />
                    <span>Share App & Invite Classmates</span>
                  </button>

                  <a
                    href="/classmatehub-website.zip"
                    download="classmatehub-website.zip"
                    onClick={() => setShowProfileMenu(false)}
                    className="w-full px-3 py-2.5 text-left text-amber-300 hover:text-amber-200 hover:bg-amber-500/10 rounded-xl flex items-center gap-2.5 transition-colors cursor-pointer"
                  >
                    <FileArchive className="w-4 h-4 text-amber-400" />
                    <span>Download Source Code (.ZIP)</span>
                  </a>

                  <button
                    id="logout-btn"
                    type="button"
                    onClick={async () => {
                      setShowProfileMenu(false);
                      await logout();
                    }}
                    className="w-full px-3 py-2.5 text-left text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-xl flex items-center gap-2.5 transition-colors mt-1 cursor-pointer font-medium"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <button
            id="nav-signin-btn"
            type="button"
            onClick={onOpenAuth}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold text-xs rounded-2xl shadow-lg shadow-indigo-600/30 hover:shadow-indigo-600/50 transition-all active:scale-[0.98] cursor-pointer"
          >
            <User className="w-3.5 h-3.5" />
            <span>Sign In / Register</span>
          </button>
        )}
      </div>
    </header>
  );
};
