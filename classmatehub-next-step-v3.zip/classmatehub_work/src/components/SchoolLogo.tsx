import React from 'react';
import { GraduationCap } from 'lucide-react';

interface SchoolLogoProps {
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showRing?: boolean;
  interactive?: boolean;
}

export const SchoolLogo: React.FC<SchoolLogoProps> = ({
  className = '',
  size = 'md',
  showRing = true,
  interactive = false,
}) => {
  const sizeClasses = {
    xs: 'w-6 h-6',
    sm: 'w-8 h-8 sm:w-9 sm:h-9',
    md: 'w-10 h-10',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  };

  const iconSizeClasses = {
    xs: 'w-3.5 h-3.5',
    sm: 'w-4 h-4 sm:w-5 sm:h-5',
    md: 'w-5 h-5',
    lg: 'w-6 h-6',
    xl: 'w-8 h-8',
  };

  const dimension = sizeClasses[size] || sizeClasses.md;
  const iconDim = iconSizeClasses[size] || iconSizeClasses.md;

  return (
    <div
      id="school-graduation-hat-logo"
      title="RICA Academic Graduation Emblem"
      className={`relative inline-flex items-center justify-center shrink-0 rounded-full bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-400 text-slate-950 shadow-md ${
        showRing ? 'ring-2 ring-amber-400/80 shadow-amber-500/25' : ''
      } ${interactive ? 'cursor-pointer hover:scale-105 transition-transform' : ''} ${dimension} ${className}`}
    >
      <GraduationCap className={`${iconDim} text-slate-950 stroke-[2.3] drop-shadow-sm`} />
    </div>
  );
};
