import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Shield, 
  Users, 
  Megaphone, 
  FolderLock, 
  Hash, 
  CheckCircle2, 
  Trash2, 
  Plus, 
  Activity, 
  HardDrive, 
  Lock, 
  Sparkles, 
  AlertTriangle,
  Award
} from 'lucide-react';
import { UserProfile, Channel, Announcement, CloudFile } from '../../types';

interface AdminPanelProps {
  allUsers: UserProfile[];
  channels: Channel[];
  announcements: Announcement[];
  allFiles: CloudFile[];
  onUpdateUserRole: (uid: string, role: UserProfile['role']) => Promise<void>;
  onToggleUserVerified: (uid: string, isVerified: boolean) => Promise<void>;
  onCreateAnnouncement: (title: string, content: string, isImportant: boolean) => Promise<void>;
  onDeleteAnnouncement: (annId: string) => Promise<void>;
  onCreateChannel: (name: string, description: string, category: Channel['category']) => Promise<void>;
  onDeleteChannel: (channelId: string) => Promise<void>;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  allUsers,
  channels,
  announcements,
  allFiles,
  onUpdateUserRole,
  onToggleUserVerified,
  onCreateAnnouncement,
  onDeleteAnnouncement,
  onCreateChannel,
  onDeleteChannel
}) => {
  const { userProfile, isSuperAdmin, cleanupDemoAccounts, deleteUserDoc } = useAuth();
  const [activeTab, setActiveTab] = useState<'users' | 'announcements' | 'channels' | 'storage'>('users');
  const [cleaningDemo, setCleaningDemo] = useState(false);
  const [cleanupMessage, setCleanupMessage] = useState<string | null>(null);
  const [deletingUid, setDeletingUid] = useState<string | null>(null);

  const handleCleanDemoAccounts = async () => {
    setCleaningDemo(true);
    try {
      const count = await cleanupDemoAccounts();
      setCleanupMessage(count > 0 ? `Successfully purged ${count} old demo accounts (retained Administrator and Sarah Ching).` : 'Database is clean! Only Administrator and Sarah Ching demo accounts exist.');
      setTimeout(() => setCleanupMessage(null), 4000);
    } catch (err: any) {
      setCleanupMessage('Error cleaning up demo accounts.');
    } finally {
      setCleaningDemo(false);
    }
  };

  const handleDeleteUser = async (uid: string, name: string) => {
    if (uid === userProfile?.uid) {
      alert('You cannot delete your own active account.');
      return;
    }
    setDeletingUid(uid);
    try {
      await deleteUserDoc(uid);
      setCleanupMessage(`Removed ${name} from class directory.`);
      setTimeout(() => setCleanupMessage(null), 3000);
    } catch (e) {
      alert('Failed to delete user.');
    } finally {
      setDeletingUid(null);
    }
  };

  // Announcement Form
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annImportant, setAnnImportant] = useState(true);

  // Channel Form
  const [chanName, setChanName] = useState('');
  const [chanDesc, setChanDesc] = useState('');
  const [chanCat, setChanCat] = useState<Channel['category']>('courses');

  const handlePostAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim() || !annContent.trim()) return;

    await onCreateAnnouncement(annTitle, annContent, annImportant);
    setAnnTitle('');
    setAnnContent('');
  };

  const handlePostChannel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chanName.trim()) return;

    await onCreateChannel(chanName.toLowerCase().replace(/\s+/g, '-'), chanDesc, chanCat);
    setChanName('');
    setChanDesc('');
  };

  const totalStorageBytes = allFiles.reduce((acc, f) => acc + (f.size || 0), 0);
  const totalStorageMB = (totalStorageBytes / (1024 * 1024)).toFixed(1);

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
      {/* Header */}
      <div className="p-4 md:p-6 border-b border-slate-800 bg-slate-900/50 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-600/25">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-white tracking-tight">Admin Master Console</h1>
              <span className="text-[10px] px-2 py-0.5 bg-indigo-500/20 text-indigo-300 font-bold rounded-full border border-indigo-500/30">
                Overall App Access
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Manage student permissions, moderate channels, publish announcements & audit cloud locker
            </p>
          </div>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="flex items-center gap-2 mt-5 overflow-x-auto pb-1 text-xs">
          <button
            id="admin-tab-users"
            type="button"
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl font-semibold transition-all shrink-0 ${
              activeTab === 'users' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Classmates ({allUsers.length})</span>
          </button>

          <button
            id="admin-tab-announcements"
            type="button"
            onClick={() => setActiveTab('announcements')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl font-semibold transition-all shrink-0 ${
              activeTab === 'announcements' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Megaphone className="w-3.5 h-3.5" />
            <span>Global Broadcasts ({announcements.length})</span>
          </button>

          <button
            id="admin-tab-channels"
            type="button"
            onClick={() => setActiveTab('channels')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl font-semibold transition-all shrink-0 ${
              activeTab === 'channels' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Hash className="w-3.5 h-3.5" />
            <span>Channel Moderation ({channels.length})</span>
          </button>

          <button
            id="admin-tab-storage"
            type="button"
            onClick={() => setActiveTab('storage')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl font-semibold transition-all shrink-0 ${
              activeTab === 'storage' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>Cloud Storage Audit ({allFiles.length} files)</span>
          </button>
        </div>
      </div>

      {/* Main Tab Views */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6">
        {/* Tab 1: User Management */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white">Registered Classmates & Permissions</h3>
                <span className="text-xs text-slate-400">Total: {allUsers.length} Enrolled Classmates</span>
              </div>

              <button
                id="purge-demo-accounts-btn"
                type="button"
                disabled={cleaningDemo}
                onClick={handleCleanDemoAccounts}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 hover:text-white rounded-xl text-xs font-semibold transition-all cursor-pointer disabled:opacity-50 self-start sm:self-auto shadow-sm"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{cleaningDemo ? 'Cleaning Database...' : 'Clean Up Demo Accounts'}</span>
              </button>
            </div>

            {cleanupMessage && (
              <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs rounded-xl flex items-center justify-between animate-in fade-in">
                <span>{cleanupMessage}</span>
                <button type="button" onClick={() => setCleanupMessage(null)} className="text-slate-400 hover:text-white">✕</button>
              </div>
            )}

            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] font-bold border-b border-slate-800">
                    <tr>
                      <th className="p-3.5">Student</th>
                      <th className="p-3.5">Role</th>
                      <th className="p-3.5">Verification</th>
                      <th className="p-3.5">Status</th>
                      <th className="p-3.5 text-right">Role & Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {allUsers.map((user) => (
                      <tr key={user.uid} className="hover:bg-slate-800/40 transition-colors">
                        <td className="p-3.5 flex items-center gap-3">
                          <img
                            src={user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`}
                            alt={user.displayName}
                            className="w-8 h-8 rounded-xl object-cover bg-slate-800 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0">
                            <div className="font-bold text-white truncate flex items-center gap-1.5">
                              <span>{user.displayName}</span>
                              {user.uid.startsWith('demo-') && (
                                <span className="text-[9px] px-1 py-0.2 bg-amber-500/20 text-amber-300 rounded font-mono">demo</span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-400 truncate">{user.email}</div>
                          </div>
                        </td>

                        <td className="p-3.5">
                          <span className={`px-2 py-0.5 rounded font-bold uppercase text-[10px] ${
                            user.role === 'admin' ? 'bg-indigo-500/20 text-indigo-300' :
                            user.role === 'moderator' ? 'bg-purple-500/20 text-purple-300' :
                            'bg-slate-800 text-slate-400'
                          }`}>
                            {user.role}
                          </span>
                        </td>

                        <td className="p-3.5">
                          <button
                            type="button"
                            onClick={() => onToggleUserVerified(user.uid, !user.isVerified)}
                            className={`flex items-center gap-1 text-[11px] font-medium transition-colors ${
                              user.isVerified ? 'text-cyan-400' : 'text-slate-500 hover:text-slate-300'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{user.isVerified ? 'Verified' : 'Unverified'}</span>
                          </button>
                        </td>

                        <td className="p-3.5">
                          <span className="capitalize text-slate-300">{user.status || 'Offline'}</span>
                        </td>

                        <td className="p-3.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {user.role !== 'admin' && (
                              <button
                                type="button"
                                onClick={() => onUpdateUserRole(user.uid, 'admin')}
                                className="px-2.5 py-1 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white rounded-lg font-semibold transition-colors"
                              >
                                Make Admin
                              </button>
                            )}
                            {user.role !== 'moderator' && (
                              <button
                                type="button"
                                onClick={() => onUpdateUserRole(user.uid, 'moderator')}
                                className="px-2.5 py-1 bg-purple-600/20 hover:bg-purple-600 text-purple-300 hover:text-white rounded-lg font-semibold transition-colors"
                              >
                                Make Mod
                              </button>
                            )}
                            {user.role !== 'student' && (
                              <button
                                type="button"
                                onClick={() => onUpdateUserRole(user.uid, 'student')}
                                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors"
                              >
                                Reset Student
                              </button>
                            )}
                            {user.uid !== userProfile?.uid && (
                              <button
                                type="button"
                                title="Delete user"
                                disabled={deletingUid === user.uid}
                                onClick={() => handleDeleteUser(user.uid, user.displayName)}
                                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Global Broadcasts */}
        {activeTab === 'announcements' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Create Announcement Form */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                <Megaphone className="w-4 h-4 text-indigo-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">Broadcast New Announcement</h3>
              </div>

              <form onSubmit={handlePostAnnouncement} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-300 mb-1">Headline</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Midterm Past Questions Vault Opened"
                    value={annTitle}
                    onChange={(e) => setAnnTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Announcement Body</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Details for all students..."
                    value={annContent}
                    onChange={(e) => setAnnContent(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="ann-important-check"
                    checked={annImportant}
                    onChange={(e) => setAnnImportant(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600"
                  />
                  <label htmlFor="ann-important-check" className="text-slate-300 font-medium">
                    Pin as High-Priority Urgent Notification
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl shadow-md transition-colors"
                >
                  Broadcast to All Classmates
                </button>
              </form>
            </div>

            {/* Existing Announcements */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Broadcasts</h3>
              {announcements.map((ann) => (
                <div
                  key={ann.id}
                  className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-2 relative"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      {ann.isImportant && (
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-rose-500/20 text-rose-300 rounded border border-rose-500/30">
                          URGENT
                        </span>
                      )}
                      <h4 className="text-xs font-bold text-white">{ann.title}</h4>
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteAnnouncement(ann.id)}
                      className="text-rose-400 hover:text-rose-300 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{ann.content}</p>
                  <div className="text-[10px] text-slate-500 pt-1">
                    Posted by {ann.createdByName} • {new Date(ann.createdAt).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Channel Moderation */}
        {activeTab === 'channels' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Create Channel */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                <Hash className="w-4 h-4 text-indigo-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">Create New Channel</h3>
              </div>

              <form onSubmit={handlePostChannel} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-300 mb-1">Channel Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. quantum-computing"
                    value={chanName}
                    onChange={(e) => setChanName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Category</label>
                  <select
                    value={chanCat}
                    onChange={(e) => setChanCat(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="general">General</option>
                    <option value="courses">Courses & Subjects</option>
                    <option value="projects">Projects & Teams</option>
                    <option value="exam-prep">Exam Prep & Past Papers</option>
                    <option value="social">Social & Campus</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Channel Description</label>
                  <textarea
                    rows={3}
                    placeholder="Purpose of this channel..."
                    value={chanDesc}
                    onChange={(e) => setChanDesc(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition-colors"
                >
                  Create & Launch Channel
                </button>
              </form>
            </div>

            {/* Manage Channels List */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Channels</h3>
              {channels.map((chan) => (
                <div
                  key={chan.id}
                  className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <Hash className="w-4 h-4 text-indigo-400 shrink-0" />
                    <div className="truncate">
                      <div className="text-xs font-bold text-white truncate">#{chan.name}</div>
                      <div className="text-[10px] text-slate-400 truncate">{chan.description}</div>
                    </div>
                  </div>

                  {chan.id !== 'general' && (
                    <button
                      type="button"
                      onClick={() => onDeleteChannel(chan.id)}
                      className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg shrink-0"
                      title="Delete channel"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Cloud Storage Audit */}
        {activeTab === 'storage' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
                <div className="text-xs text-slate-400">Total Cloud Files</div>
                <div className="text-2xl font-bold text-white mt-1">{allFiles.length}</div>
              </div>
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
                <div className="text-xs text-slate-400">Total Storage Consumed</div>
                <div className="text-2xl font-bold text-emerald-400 mt-1">{totalStorageMB} MB</div>
              </div>
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
                <div className="text-xs text-slate-400">Storage Security Policy</div>
                <div className="text-xs font-bold text-indigo-300 mt-2 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5" /> Private Isolation Active
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">All Uploaded Files (Global Audit)</h3>
              <div className="divide-y divide-slate-800">
                {allFiles.map((file) => (
                  <div key={file.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                    <div className="min-w-0">
                      <div className="font-semibold text-white truncate">{file.name}</div>
                      <div className="text-[10px] text-slate-400">
                        Owner: {file.userName} • {file.isPublic ? 'Shared Publicly' : 'Private Locker'} • {file.subject}
                      </div>
                    </div>
                    <span className="text-slate-400 shrink-0">{(file.size / (1024 * 1024)).toFixed(2)} MB</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
