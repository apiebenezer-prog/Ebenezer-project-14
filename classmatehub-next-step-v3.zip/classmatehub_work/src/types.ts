export type UserRole = 'student' | 'admin' | 'moderator';

export type UserStatus = 'online' | 'studying' | 'in_class' | 'offline' | 'busy';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  major?: string;
  year?: string;
  bio?: string;
  status: UserStatus;
  customStatusMessage?: string;
  lastSeen?: any;
  createdAt?: any;
  isVerified?: boolean;
  storageUsedBytes?: number;
}

export interface Channel {
  id: string;
  name: string;
  description: string;
  category: 'general' | 'courses' | 'projects' | 'exam-prep' | 'social';
  isPrivate?: boolean;
  isLocked?: boolean;
  createdBy: string;
  createdAt: any;
  icon?: string;
  unreadCount?: number;
  members?: string[];
}

export interface Attachment {
  name: string;
  size: number;
  type: string;
  url: string; // base64 or storage url
  fileCategory?: string;
}

export interface ChatMessage {
  id: string;
  channelId?: string;
  conversationId?: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  userRole?: UserRole;
  text: string;
  attachments?: Attachment[];
  reactions?: Record<string, string[]>; // emoji: [userIds]
  replyToId?: string;
  replyToText?: string;
  isPinned?: boolean;
  createdAt: any;
  status?: 'sending' | 'sent' | 'delivered' | 'read';
  deliveredCount?: number;
  deliveryStatus?: string;
  readBy?: string[]; // Array of user UIDs who have read this message (WhatsApp-style read tracking)
}

export interface DirectConversation {
  id: string;
  participants: string[]; // user UIDs
  participantDetails: Record<string, { displayName: string; photoURL?: string; email: string }>;
  lastMessage?: string;
  lastMessageAt?: any;
  lastMessageSenderId?: string;
  lastMessageReadBy?: string[];
  unreadCounts?: Record<string, number>;
}

export interface CloudFile {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  name: string;
  category: 'notes' | 'slides' | 'past_questions' | 'assignments' | 'code' | 'other';
  subject: string;
  size: number;
  mimeType: string;
  fileData?: string; // base64 content for local storage / cloud representation
  isPublic: boolean; // false = private (accessible by owner only), true = shared with all classmates
  channelId?: string;
  tags: string[];
  createdAt: any;
  downloadCount: number;
  description?: string;
}

export interface Assignment {
  id: string;
  title: string;
  subject: string;
  description: string;
  dueDate: string;
  priority: 'low' | 'medium' | 'high';
  createdBy: string;
  createdByName: string;
  createdAt: any;
  completedBy?: string[]; // list of user UIDs who marked it done
}

export interface StudyGroup {
  id: string;
  title: string;
  subject: string;
  description: string;
  targetExam?: string;
  members: string[]; // user UIDs
  meetingLink?: string;
  scheduledTime?: string;
  isLive?: boolean;
  activeTimerSeconds?: number;
}

export interface PollOption {
  id: string;
  text: string;
  votes: string[]; // user UIDs
}

export interface Poll {
  id: string;
  question: string;
  options: PollOption[];
  createdBy: string;
  createdByName: string;
  createdAt: any;
  expiresAt?: string;
  isClosed?: boolean;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  isImportant: boolean;
  createdBy: string;
  createdByName: string;
  createdAt: any;
  expiresAt?: string;
}

export interface DiagnosticItem {
  id: string;
  name: string;
  category: 'Auth' | 'Database' | 'Security' | 'Storage' | 'Realtime' | 'AI' | 'PWA';
  status: 'pending' | 'running' | 'success' | 'warning' | 'failed';
  latencyMs?: number;
  details: string;
}

export interface AIChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  modelUsed?: string;
  feedback?: 'up' | 'down';
}

export interface AIChatSession {
  id: string;
  userId?: string;
  title: string;
  subject: string;
  persona: 'solver' | 'coder' | 'professor' | 'exam_prep' | 'socratic';
  messages: AIChatMessage[];
  createdAt: string;
  updatedAt: string;
}
