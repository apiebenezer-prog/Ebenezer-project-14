import { Channel, CloudFile, Assignment, StudyGroup, Poll, Announcement } from '../types';

export const INITIAL_CHANNELS: Channel[] = [
  {
    id: 'general',
    name: 'general',
    description: 'Main chat for all classmates. Daily announcements, class updates, and open chatter.',
    category: 'general',
    createdBy: 'admin-ebenezer',
    createdAt: new Date().toISOString(),
    unreadCount: 0
  },
  {
    id: 'study-groups',
    name: 'study-groups',
    description: 'Find study partners, organize virtual study rooms, and coordinate review sessions.',
    category: 'study-groups' as any,
    createdBy: 'admin-ebenezer',
    createdAt: new Date().toISOString(),
    unreadCount: 2
  },
  {
    id: 'cs-and-algorithms',
    name: 'cs-and-algorithms',
    description: 'Data structures, algorithms, coding problem sets, and debugging discussions.',
    category: 'courses',
    createdBy: 'admin-ebenezer',
    createdAt: new Date().toISOString(),
    unreadCount: 0
  },
  {
    id: 'lecture-notes-hub',
    name: 'lecture-notes-hub',
    description: 'Share annotated lecture slides, voice transcripts, and high-yield summary documents.',
    category: 'courses',
    createdBy: 'admin-ebenezer',
    createdAt: new Date().toISOString(),
    unreadCount: 1
  },
  {
    id: 'exam-prep-vault',
    name: 'exam-prep-vault',
    description: 'Past examination papers, revision roadmaps, formula sheets, and practice quizzes.',
    category: 'exam-prep',
    createdBy: 'admin-ebenezer',
    createdAt: new Date().toISOString(),
    unreadCount: 3
  },
  {
    id: 'project-collaboration',
    name: 'project-collaboration',
    description: 'Find teammates, coordinate group presentations, and share research links.',
    category: 'projects',
    createdBy: 'admin-ebenezer',
    createdAt: new Date().toISOString(),
    unreadCount: 0
  }
];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Midterm Revision Schedule & Cloud Locker Active',
    content: 'Welcome to Classmate Hub! The shared repository is now active with past papers and lecture summaries. Please upload your revision notes to the Cloud Locker.',
    isImportant: true,
    createdBy: 'apiebenezer@gmail.com',
    createdByName: 'Ebenezer (Class Admin)',
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    expiresAt: '2026-09-01'
  },
  {
    id: 'ann-2',
    title: 'Virtual Group Study Session Tonight (8:00 PM)',
    content: 'Join the live Pomodoro Study Room under the Study Hub tab. We will review Chapter 4 algorithms and practice mock exam questions.',
    isImportant: false,
    createdBy: 'apiebenezer@gmail.com',
    createdByName: 'Ebenezer (Class Admin)',
    createdAt: new Date(Date.now() - 3600000 * 20).toISOString()
  }
];

export const INITIAL_FILES: CloudFile[] = [
  {
    id: 'file-1',
    userId: 'admin-ebenezer',
    userName: 'Ebenezer (Admin)',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    name: 'Algorithms_Midterm_Past_Paper_2025_Solutions.pdf',
    category: 'past_questions',
    subject: 'Algorithms & Data Structures',
    size: 2450000,
    mimeType: 'application/pdf',
    isPublic: true,
    tags: ['Algorithms', 'Past Exam', 'Midterm', 'Solved'],
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    downloadCount: 42,
    description: 'Complete step-by-step solved past questions for the 2025 midterm with complexity analysis.'
  },
  {
    id: 'file-2',
    userId: 'admin-ebenezer',
    userName: 'Ebenezer (Admin)',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    name: 'Distributed_Systems_Lecture_4_5_Cheatsheet.pdf',
    category: 'notes',
    subject: 'Distributed Systems',
    size: 1820000,
    mimeType: 'application/pdf',
    isPublic: true,
    tags: ['Consensus', 'Raft', 'Slides', 'Cheatsheet'],
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    downloadCount: 29,
    description: 'Summary formulas, consensus algorithm breakdowns, and CAP theorem trade-offs.'
  },
  {
    id: 'file-3',
    userId: 'demo-student',
    userName: 'Sarah Ching',
    userAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
    name: 'Database_Query_Optimization_CheatSheet.sql',
    category: 'code',
    subject: 'Database Systems',
    size: 420000,
    mimeType: 'text/plain',
    isPublic: true,
    tags: ['SQL', 'Indexes', 'B-Trees', 'Code'],
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    downloadCount: 18,
    description: 'SQL queries for testing EXPLAIN ANALYZE, indexing strategies, and execution plans.'
  }
];

export const INITIAL_ASSIGNMENTS: Assignment[] = [
  {
    id: 'assign-1',
    title: 'Assignment 3: B-Tree & Indexing Implementation',
    subject: 'Database Systems',
    description: 'Implement a disk-backed B+ tree index structure with node splitting and range queries.',
    dueDate: new Date(Date.now() + 86400000 * 4).toISOString().split('T')[0],
    priority: 'high',
    createdBy: 'demo-admin',
    createdByName: 'Ebenezer (Admin)',
    createdAt: new Date().toISOString(),
    completedBy: []
  },
  {
    id: 'assign-2',
    title: 'Distributed Consensus Case Study Report',
    subject: 'Distributed Systems',
    description: 'Compare Raft vs Paxos leader election under network partitions (max 5 pages).',
    dueDate: new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0],
    priority: 'medium',
    createdBy: 'demo-admin',
    createdByName: 'Ebenezer (Admin)',
    createdAt: new Date().toISOString(),
    completedBy: []
  },
  {
    id: 'assign-3',
    title: 'Machine Learning Project Milestone 1',
    subject: 'AI & Data Science',
    description: 'Submit dataset exploratory analysis, baseline model accuracy benchmarks, and pipeline repo.',
    dueDate: new Date(Date.now() + 86400000 * 10).toISOString().split('T')[0],
    priority: 'low',
    createdBy: 'demo-admin',
    createdByName: 'Ebenezer (Admin)',
    createdAt: new Date().toISOString(),
    completedBy: []
  }
];

export const INITIAL_POLLS: Poll[] = [
  {
    id: 'poll-1',
    question: 'When should we host the Midterm Revision Marathon session?',
    options: [
      { id: 'opt-1', text: 'Saturday 4:00 PM - 7:00 PM', votes: ['demo-student'] },
      { id: 'opt-2', text: 'Sunday 6:00 PM - 9:00 PM', votes: ['demo-admin'] },
      { id: 'opt-3', text: 'Monday 7:00 PM (Night before exam)', votes: [] }
    ],
    createdBy: 'demo-admin',
    createdByName: 'Ebenezer (Admin)',
    createdAt: new Date().toISOString(),
    isClosed: false
  }
];
