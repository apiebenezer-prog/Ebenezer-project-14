import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { ChannelChat } from './components/Chat/ChannelChat';
import { DirectMessages } from './components/Chat/DirectMessages';
import { CloudStorageLocker } from './components/Storage/CloudStorageLocker';
import { AIStudyAssistant } from './components/Study/AIStudyAssistant';
import { StudyGroupsAndTimer } from './components/Study/StudyGroupsAndTimer';
import { AssignmentsTracker } from './components/Assignments/AssignmentsTracker';
import { ClassmateDirectory } from './components/Directory/ClassmateDirectory';
import { ClassPolls } from './components/Polls/ClassPolls';
import { AdminPanel } from './components/Admin/AdminPanel';
import { AuthModal } from './components/Auth/AuthModal';
import { EditProfileModal } from './components/Auth/EditProfileModal';
import { SystemDiagnosticModal } from './components/Testing/SystemDiagnosticModal';
import { InstallAppModal } from './components/PWA/InstallAppModal';
import { CreateChannelModal } from './components/Chat/CreateChannelModal';

import { db } from './lib/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  where, 
  limit,
  limitToLast,
  serverTimestamp,
  arrayUnion,
  arrayRemove,
  runTransaction,
  writeBatch
} from 'firebase/firestore';

import { 
  INITIAL_CHANNELS, 
  INITIAL_ANNOUNCEMENTS, 
  INITIAL_FILES, 
  INITIAL_ASSIGNMENTS, 
  INITIAL_POLLS 
} from './lib/mockData';

import { 
  Channel, 
  ChatMessage, 
  DirectConversation, 
  CloudFile, 
  Assignment, 
  StudyGroup, 
  Poll, 
  Announcement, 
  Attachment,
  UserProfile
} from './types';
import { Megaphone, X, Sparkles, CheckCircle2 } from 'lucide-react';

// Helper to normalize messages from Firestore or cache, ensuring valid dates, status, and delivery counters
const normalizeMessage = (docId: string, data: any, fallbackIndex: number): ChatMessage => {
  let dateStr = new Date().toISOString();
  if (data.createdAt) {
    if (typeof data.createdAt === 'string') {
      dateStr = data.createdAt;
    } else if (typeof data.createdAt.toDate === 'function') {
      dateStr = data.createdAt.toDate().toISOString();
    } else if (data.createdAt.seconds) {
      dateStr = new Date(data.createdAt.seconds * 1000).toISOString();
    }
  }

  return {
    id: docId,
    channelId: data.channelId,
    conversationId: data.conversationId,
    userId: data.userId || 'student',
    userName: data.userName || 'Classmate',
    userAvatar: data.userAvatar,
    userRole: data.userRole,
    text: data.text || '',
    attachments: data.attachments || [],
    reactions: data.reactions || {},
    replyToId: data.replyToId,
    replyToText: data.replyToText,
    isPinned: !!data.isPinned,
    createdAt: dateStr,
    status: data.status || 'delivered',
    deliveredCount: typeof data.deliveredCount === 'number' ? data.deliveredCount : fallbackIndex,
    deliveryStatus: data.deliveryStatus,
    readBy: Array.isArray(data.readBy) ? data.readBy : (data.userId ? [data.userId] : [])
  };
};

function MainApp() {
  const { currentUser, userProfile, allUsers, isAdmin, isSuperAdmin } = useAuth();

  // Navigation State
  const [activeTab, setActiveTab] = useState<ActiveTab>('channels');
  const [selectedChannelId, setSelectedChannelId] = useState<string>('general');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Modals
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isEditProfileModalOpen, setIsEditProfileModalOpen] = useState(false);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [isCreateChannelModalOpen, setIsCreateChannelModalOpen] = useState(false);

  // Real-time Data
  const [channels, setChannels] = useState<Channel[]>(INITIAL_CHANNELS);
  const [channelMessages, setChannelMessages] = useState<ChatMessage[]>([]);
  const [directConversations, setDirectConversations] = useState<DirectConversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<DirectConversation | null>(null);
  const [directMessages, setDirectMessages] = useState<ChatMessage[]>([]);
  const [cloudFiles, setCloudFiles] = useState<CloudFile[]>(INITIAL_FILES);
  const [assignments, setAssignments] = useState<Assignment[]>(INITIAL_ASSIGNMENTS);
  const [studyGroups, setStudyGroups] = useState<StudyGroup[]>([
    {
      id: 'grp-1',
      title: 'Silent Library Focus Room (Pomodoro 25/5)',
      subject: 'All Courses',
      description: 'Quiet virtual room with synced focus timers and background ambient study sound.',
      members: ['admin-ebenezer'],
      isLive: true,
      scheduledTime: 'Always Open'
    },
    {
      id: 'grp-2',
      title: 'Algorithms Midterm Sprint Squad',
      subject: 'Algorithms',
      description: 'Reviewing graph theory, dynamic programming, and solving past exam questions together.',
      members: ['demo-student', 'demo-admin'],
      isLive: true,
      scheduledTime: 'Daily 7:00 PM'
    }
  ]);
  const [polls, setPolls] = useState<Poll[]>(INITIAL_POLLS);
  const [announcements, setAnnouncements] = useState<Announcement[]>(INITIAL_ANNOUNCEMENTS);
  const [dismissedAnnouncements, setDismissedAnnouncements] = useState<string[]>([]);

  // 1. Listen to Channels
  useEffect(() => {
    try {
      const q = query(collection(db, 'channels'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const list: Channel[] = [];
          snapshot.forEach(doc => list.push({ id: doc.id, ...doc.data() } as Channel));
          setChannels(list);
        } else {
          // Bootstrap default channels
          INITIAL_CHANNELS.forEach(async (ch) => {
            try {
              await setDoc(doc(db, 'channels', ch.id), ch);
            } catch (e) {}
          });
        }
      }, (err) => {
        console.warn('Channels listener offline fallback:', err);
      });
      return () => unsubscribe();
    } catch (e) {}
  }, []);

  // 2. Listen to Messages of Selected Channel (Saved Forever in Firestore + LocalStorage)
  useEffect(() => {
    if (!selectedChannelId) return;
    
    // Instant preload from local cache so messages are never blank on reload or logout/login
    try {
      const cached = localStorage.getItem(`classmate_cached_msgs_${selectedChannelId}`);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setChannelMessages(parsed);
        }
      }
    } catch (e) {}

    try {
      const messagesRef = collection(db, 'channels', selectedChannelId, 'messages');
      const q = query(messagesRef, limit(150));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const list: ChatMessage[] = [];
        let index = 0;
        snapshot.forEach(docSnap => {
          index++;
          list.push(normalizeMessage(docSnap.id, docSnap.data(), index));
        });

        // In-memory sort by parsed date to avoid compound index errors
        list.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        
        // If firestore messages are empty for this channel, provide starter seed for general and sync to Firestore
        if (list.length === 0 && selectedChannelId === 'general') {
          const starter: ChatMessage[] = [
            {
              id: 'msg-welcome-1',
              channelId: 'general',
              userId: 'demo-admin',
              userName: 'Ebenezer (Admin)',
              userRole: 'admin',
              userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
              text: 'Welcome to Classmate Hub for Grade 11! 👋\nThis is our shared campus communication portal. All messages are synchronized in real-time across all devices.',
              createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
              isPinned: true,
              status: 'delivered',
              deliveredCount: 1,
              readBy: ['demo-admin']
            },
            {
              id: 'msg-welcome-2',
              channelId: 'general',
              userId: 'demo-student',
              userName: 'Sarah Ching',
              userRole: 'student',
              userAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
              text: 'Excited for the midterm review session tonight! I uploaded the 2025 past papers with solutions to the Cloud Locker 📚',
              createdAt: new Date(Date.now() - 3600000).toISOString(),
              status: 'delivered',
              deliveredCount: 2,
              readBy: ['demo-student']
            }
          ];
          setChannelMessages(starter);
          try {
            localStorage.setItem(`classmate_cached_msgs_${selectedChannelId}`, JSON.stringify(starter));
          } catch (e) {}

          // Ensure starter messages are written to Firestore so all other devices see them
          starter.forEach(async (m) => {
            try {
              await setDoc(doc(db, 'channels', 'general', 'messages', m.id), m, { merge: true });
            } catch (e) {}
          });
        } else {
          setChannelMessages(list);
          try {
            localStorage.setItem(`classmate_cached_msgs_${selectedChannelId}`, JSON.stringify(list));
          } catch (e) {}
        }
      }, (err) => {
        console.warn('Channel messages listener offline fallback:', err);
      });
      return () => unsubscribe();
    } catch (e) {}
  }, [selectedChannelId]);

  // 3. Listen only to shared files and the signed-in user's own private files.
  // Firestore security rules cannot safely authorize an unfiltered query over private files.
  useEffect(() => {
    const uid = userProfile?.uid;
    if (!uid) return;
    let publicFiles: CloudFile[] = [];
    let ownFiles: CloudFile[] = [];
    const publishMergedFiles = () => {
      const byId = new Map<string, CloudFile>();
      [...publicFiles, ...ownFiles].forEach(file => byId.set(file.id, file));
      setCloudFiles(Array.from(byId.values()).sort((a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ));
    };
    const publicQuery = query(collection(db, 'user_files'), where('isPublic', '==', true), limit(50));
    const ownQuery = query(collection(db, 'user_files'), where('userId', '==', uid), limit(50));
    const unsubPublic = onSnapshot(publicQuery, snapshot => {
      publicFiles = snapshot.docs.map(fileDoc => ({ id: fileDoc.id, ...fileDoc.data() } as CloudFile));
      publishMergedFiles();
    }, err => console.warn('Shared files listener fallback:', err));
    const unsubOwn = onSnapshot(ownQuery, snapshot => {
      ownFiles = snapshot.docs.map(fileDoc => ({ id: fileDoc.id, ...fileDoc.data() } as CloudFile));
      publishMergedFiles();
    }, err => console.warn('Private files listener fallback:', err));
    return () => { unsubPublic(); unsubOwn(); };
  }, [userProfile?.uid]);

  // 4. Listen to Assignments
  useEffect(() => {
    try {
      const q = query(collection(db, 'assignments'), limit(50));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const list: Assignment[] = [];
          snapshot.forEach(doc => list.push({ id: doc.id, ...doc.data() } as Assignment));
          setAssignments(list);
        } else {
          INITIAL_ASSIGNMENTS.forEach(async (a) => {
            try {
              await setDoc(doc(db, 'assignments', a.id), a);
            } catch (e) {}
          });
        }
      }, (err) => {
        console.warn('Assignments listener fallback:', err);
      });
      return () => unsubscribe();
    } catch (e) {}
  }, []);

  // 5. Listen to polls and their per-user vote documents. Votes are stored separately
  // so a student cannot rewrite another student's vote array in the poll document.
  useEffect(() => {
    const voteUnsubscribers = new Map<string, () => void>();
    try {
      const q = query(collection(db, 'polls'), limit(30));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const list: Poll[] = [];
          snapshot.forEach(pollDoc => {
            const raw = pollDoc.data();
            const options = Array.isArray(raw.options) ? raw.options.map((option: any) => ({
              id: String(option.id), text: String(option.text ?? ''),
              // Legacy embedded votes are intentionally ignored; authoritative votes
              // come from polls/{pollId}/votes/{uid}.
              votes: [] as string[]
            })) : [];
            list.push({ id: pollDoc.id, ...raw, options } as Poll);
          });
          const nextIds = new Set(list.map(p => p.id));
          for (const [id, stop] of voteUnsubscribers) {
            if (!nextIds.has(id)) { stop(); voteUnsubscribers.delete(id); }
          }
          for (const poll of list) {
            if (voteUnsubscribers.has(poll.id)) continue;
            const stop = onSnapshot(collection(db, 'polls', poll.id, 'votes'), voteSnapshot => {
              const votesByOption = new Map<string, string[]>();
              voteSnapshot.forEach(voteDoc => {
                const optionId = voteDoc.data().optionId;
                if (typeof optionId !== 'string') return;
                const voters = votesByOption.get(optionId) || [];
                voters.push(voteDoc.id);
                votesByOption.set(optionId, voters);
              });
              setPolls(current => current.map(existing => existing.id !== poll.id ? existing : {
                ...existing,
                options: existing.options.map(option => ({ ...option, votes: votesByOption.get(option.id) || [] }))
              }));
            }, err => console.warn('Poll votes listener:', err));
            voteUnsubscribers.set(poll.id, stop);
          }
          setPolls(list);
        } else {
          INITIAL_POLLS.forEach(async (p) => {
            try {
              const pollRef = doc(db, 'polls', p.id);
              const existing = await getDoc(pollRef);
              if (!existing.exists()) await setDoc(pollRef, {
                ...p,
                options: p.options.map(({ id, text }) => ({ id, text })),
                // Trusted metadata is used by Firestore Rules to validate vote option IDs.
                optionIds: p.options.map(({ id }) => id)
              });
            } catch (e) {}
          });
        }
      }, (err) => console.warn('Polls listener fallback:', err));
      return () => {
        unsubscribe();
        voteUnsubscribers.forEach(stop => stop());
        voteUnsubscribers.clear();
      };
    } catch (e) {
      voteUnsubscribers.forEach(stop => stop());
    }
  }, []);

  // 6. Listen to Announcements
  useEffect(() => {
    try {
      const q = query(collection(db, 'announcements'), limit(30));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const list: Announcement[] = [];
          snapshot.forEach(doc => list.push({ id: doc.id, ...doc.data() } as Announcement));
          setAnnouncements(list);
        }
      }, (err) => {
        console.warn('Announcements listener fallback:', err);
      });
      return () => unsubscribe();
    } catch (e) {}
  }, []);

  // 6b. Listen to Study Groups (Saved Forever)
  useEffect(() => {
    try {
      const cached = localStorage.getItem('classmate_cached_studygroups');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setStudyGroups(parsed);
        }
      }
    } catch (e) {}

    try {
      const q = query(collection(db, 'study_groups'), limit(50));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        if (!snapshot.empty) {
          const list: StudyGroup[] = [];
          snapshot.forEach(doc => list.push({ id: doc.id, ...doc.data() } as StudyGroup));
          setStudyGroups(list);
          try {
            localStorage.setItem('classmate_cached_studygroups', JSON.stringify(list));
          } catch (e) {}
        } else {
          // Bootstrap default study groups
          const initialGroups: StudyGroup[] = [
            {
              id: 'grp-1',
              title: 'Silent Library Focus Room (Pomodoro 25/5)',
              subject: 'All Courses',
              description: 'Quiet virtual room with synced focus timers and background ambient study sound.',
              members: ['admin-ebenezer'],
              isLive: true,
              scheduledTime: 'Always Open'
            },
            {
              id: 'grp-2',
              title: 'Algorithms Midterm Sprint Squad',
              subject: 'Algorithms',
              description: 'Reviewing graph theory, dynamic programming, and solving past exam questions together.',
              members: ['demo-student', 'demo-admin'],
              isLive: true,
              scheduledTime: 'Daily 7:00 PM'
            }
          ];
          initialGroups.forEach(async (g) => {
            try {
              await setDoc(doc(db, 'study_groups', g.id), g);
            } catch (e) {}
          });
        }
      }, (err) => {
        console.warn('Study groups listener fallback:', err);
      });
      return () => unsubscribe();
    } catch (e) {}
  }, []);

  // 7. Direct Messages Listener for Active Conversation (Saved Forever)
  useEffect(() => {
    // Clear the previous conversation immediately when switching threads. Never show
    // one person's messages inside another conversation while the new query loads.
    setDirectMessages([]);
    if (!activeConversation) return;

    // Instant preload from local cache so direct messages are never blank on reload or logout/login
    try {
      const cached = localStorage.getItem(`classmate_cached_dm_msgs_${activeConversation.id}`);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setDirectMessages(parsed);
        }
      }
    } catch (e) {}

    try {
      const msgRef = collection(db, 'conversations', activeConversation.id, 'messages');
      const q = query(msgRef, limit(150));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const list: ChatMessage[] = [];
        let index = 0;
        const currentUid = userProfile?.uid;

        snapshot.forEach(docSnap => {
          index++;
          const data = docSnap.data();
          const normalized = normalizeMessage(docSnap.id, data, index);
          list.push(normalized);

          // WhatsApp read receipts: if this message was sent to the current user and not yet read
          if (currentUid && normalized.userId !== currentUid && !(normalized.readBy || []).includes(currentUid)) {
            updateDoc(doc(db, 'conversations', activeConversation.id, 'messages', docSnap.id), {
              readBy: arrayUnion(currentUid),
              status: 'read'
            }).catch(() => {});
          }
        });
        list.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
        // Always apply the server snapshot, including an empty result. Otherwise old
        // messages can remain visible when a conversation has no saved messages.
        setDirectMessages(list);
        try {
          localStorage.setItem(`classmate_cached_dm_msgs_${activeConversation.id}`, JSON.stringify(list));
        } catch (e) {}

        // Keep conversation last message read status in sync
        if (currentUid && activeConversation.id) {
          updateDoc(doc(db, 'conversations', activeConversation.id), {
            lastMessageReadBy: arrayUnion(currentUid)
          }).catch(() => {});
        }
      }, (e) => {
        console.warn('DM listener fallback:', e);
      });
      return () => unsubscribe();
    } catch (e) {}
  }, [activeConversation, userProfile?.uid]);

  // 8. Direct Conversations Listener (So all private conversation rooms stay forever)
  useEffect(() => {
    try {
      // Never restore another account's cached private conversation metadata.
      if (!userProfile?.uid) {
        setDirectConversations([]);
        return;
      }
      const cached = localStorage.getItem('classmate_cached_conversations');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) {
          setDirectConversations(parsed.filter((conversation: DirectConversation) =>
            Array.isArray(conversation.participants) && conversation.participants.includes(userProfile.uid)
          ));
        }
      }
    } catch (e) {}

    try {
      // Firestore rules require a participant filter for private conversations.
      // Do not query every conversation document: that could expose private metadata.
      const q = query(
        collection(db, 'conversations'),
        where('participants', 'array-contains', userProfile.uid),
        limit(50)
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const list: DirectConversation[] = [];
        snapshot.forEach(docSnap => {
          list.push({ id: docSnap.id, ...docSnap.data() } as DirectConversation);
        });
        setDirectConversations(list);
        try {
          localStorage.setItem('classmate_cached_conversations', JSON.stringify(list));
        } catch (e) {}
      }, (e) => {
        console.warn('Conversations listener fallback:', e);
      });
      return () => unsubscribe();
    } catch (e) {}
  }, [userProfile?.uid]);

  // Channel Actions
  const handleSendMessage = async (text: string, attachments?: Attachment[], replyTo?: ChatMessage) => {
    if (!userProfile) {
      setIsAuthModalOpen(true);
      return;
    }
    const nextCount = (channelMessages?.length || 0) + 1;
    const newMessage: Omit<ChatMessage, 'id'> = {
      channelId: selectedChannelId,
      userId: userProfile?.uid || 'guest',
      userName: userProfile?.displayName || 'Classmate',
      userAvatar: userProfile?.photoURL,
      userRole: userProfile?.role || 'student',
      text,
      attachments: attachments || [],
      replyToId: replyTo?.id,
      replyToText: replyTo?.text,
      createdAt: new Date().toISOString(),
      status: 'delivered',
      deliveredCount: nextCount
    };

    // Optimistic local update
    const tempId = `temp-${Date.now()}`;
    const fullMsg: ChatMessage = { id: tempId, ...newMessage };
    setChannelMessages(prev => {
      const next = [...prev, fullMsg];
      try {
        localStorage.setItem(`classmate_cached_msgs_${selectedChannelId}`, JSON.stringify(next));
      } catch (e) {}
      return next;
    });

    try {
      await addDoc(collection(db, 'channels', selectedChannelId, 'messages'), {
        ...newMessage,
        createdAt: new Date().toISOString(),
        serverCreatedAt: serverTimestamp(),
        status: 'delivered',
        deliveredCount: nextCount
      });
      if (userProfile?.uid) {
        setDoc(doc(db, 'users', userProfile.uid), {
          ...userProfile,
          lastSeen: serverTimestamp()
        }, { merge: true }).catch(() => {});
      }
    } catch (e) {
      console.warn('Firestore write fallback', e);
    }
  };

  const handleDeleteMessage = async (msgId: string) => {
    setChannelMessages(prev => {
      const updated = prev.filter(m => m.id !== msgId);
      try {
        localStorage.setItem(`classmate_cached_msgs_${selectedChannelId}`, JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    try {
      await deleteDoc(doc(db, 'channels', selectedChannelId, 'messages', msgId));
    } catch (e) {}
  };

  const handleTogglePinMessage = async (msgId: string, isPinned: boolean) => {
    setChannelMessages(prev => {
      const updated = prev.map(m => m.id === msgId ? { ...m, isPinned } : m);
      try {
        localStorage.setItem(`classmate_cached_msgs_${selectedChannelId}`, JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    try {
      await updateDoc(doc(db, 'channels', selectedChannelId, 'messages', msgId), { isPinned });
    } catch (e) {}
  };

  const handleToggleReaction = async (msgId: string, emoji: string) => {
    const uid = userProfile?.uid || 'guest';
    setChannelMessages(prev => {
      const updated = prev.map(m => {
        if (m.id !== msgId) return m;
        const current = m.reactions || {};
        const users = current[emoji] || [];
        const updatedUsers = users.includes(uid) ? users.filter(u => u !== uid) : [...users, uid];
        const updatedReactions = { ...current };
        if (updatedUsers.length > 0) updatedReactions[emoji] = updatedUsers;
        else delete updatedReactions[emoji];
        return { ...m, reactions: updatedReactions };
      });
      try {
        localStorage.setItem(`classmate_cached_msgs_${selectedChannelId}`, JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    try {
      const targetMsg = channelMessages.find(m => m.id === msgId);
      if (targetMsg) {
        const currentReactions = targetMsg.reactions || {};
        const users = currentReactions[emoji] || [];
        const has = users.includes(uid);
        await updateDoc(doc(db, 'channels', selectedChannelId, 'messages', msgId), {
          [`reactions.${emoji}`]: has ? arrayRemove(uid) : arrayUnion(uid)
        });
      }
    } catch (e) {}
  };

  // Direct Message Actions
  const handleStartDirectMessage = (targetUser: UserProfile) => {
    if (!userProfile) {
      setIsAuthModalOpen(true);
      return;
    }
    const convId = [userProfile.uid, targetUser.uid].sort().join('_');
    const existing = directConversations.find(c => c.id === convId);

    const convObj: DirectConversation = {
      id: convId,
      participants: [userProfile.uid, targetUser.uid],
      participantDetails: {
        ...(existing?.participantDetails || {}),
        [userProfile.uid]: { displayName: userProfile.displayName, email: userProfile.email, photoURL: userProfile.photoURL },
        [targetUser.uid]: { displayName: targetUser.displayName, email: targetUser.email, photoURL: targetUser.photoURL }
      },
      lastMessage: existing?.lastMessage || 'Direct conversation started',
      lastMessageAt: existing?.lastMessageAt || serverTimestamp(),
      lastMessageSenderId: existing?.lastMessageSenderId,
      lastMessageReadBy: existing?.lastMessageReadBy
    };

    setDirectConversations(prev => {
      const filtered = prev.filter(c => c.id !== convId);
      const next = [convObj, ...filtered];
      try {
        localStorage.setItem('classmate_cached_conversations', JSON.stringify(next));
      } catch (e) {}
      return next;
    });

    // Persist the conversation room before the user starts sending messages.
    // Surface failures rather than pretending that a room was created successfully.
    setDoc(doc(db, 'conversations', convId), convObj, { merge: true }).catch((e) => {
      console.error('Could not create direct conversation:', e);
    });

    setActiveConversation(convObj);
    setActiveTab('direct-messages');
  };

  const handleSendDirectMessage = async (convId: string, text: string) => {
    if (!userProfile) {
      setIsAuthModalOpen(true);
      return;
    }
    const currentUid = userProfile?.uid || 'guest';
    const nextCount = (directMessages?.length || 0) + 1;
    const newMsg: Omit<ChatMessage, 'id'> = {
      conversationId: convId,
      userId: currentUid,
      userName: userProfile?.displayName || 'Classmate',
      userAvatar: userProfile?.photoURL,
      text,
      createdAt: new Date().toISOString(),
      status: 'delivered',
      deliveredCount: nextCount,
      readBy: [currentUid]
    };

    const tempId = `dm-${Date.now()}`;
    const fullMsg: ChatMessage = { id: tempId, ...newMsg };
    setDirectMessages(prev => {
      const next = [...prev, fullMsg];
      try {
        localStorage.setItem(`classmate_cached_dm_msgs_${convId}`, JSON.stringify(next));
      } catch (e) {}
      return next;
    });

    try {
      const conversationRef = doc(db, 'conversations', convId);
      // Ensure the parent exists before the atomic message + conversation-preview write.
      // The same deterministic ID is shared by both participants.
      const conversationSnapshot = await getDoc(conversationRef);
      if (!conversationSnapshot.exists()) {
        const active = directConversations.find(c => c.id === convId) || activeConversation;
        if (!active || !active.participants.includes(currentUid)) {
          throw new Error('This conversation is unavailable. Reopen it and try again.');
        }
        await setDoc(conversationRef, active, { merge: true });
      }
      const messageRef = doc(collection(db, 'conversations', convId, 'messages'));
      const batch = writeBatch(db);
      batch.set(messageRef, {
        ...newMsg,
        createdAt: new Date().toISOString(),
        serverCreatedAt: serverTimestamp(),
        status: 'delivered',
        deliveredCount: nextCount,
        readBy: [currentUid]
      });
      batch.update(conversationRef, {
        lastMessage: text,
        lastMessageAt: serverTimestamp(),
        lastMessageSenderId: currentUid,
        lastMessageReadBy: [currentUid]
      });
      await batch.commit();
      // Replace optimistic cache ID with the real Firestore ID only after the cloud
      // batch succeeds; message and conversation preview now commit together.
      setDirectMessages(prev => {
        const next = prev.map(m => m.id === tempId ? { ...m, id: messageRef.id } : m);
        try { localStorage.setItem(`classmate_cached_dm_msgs_${convId}`, JSON.stringify(next)); } catch (e) {}
        return next;
      });
    } catch (e) {
      // A failed cloud write must not look like a successfully delivered message.
      setDirectMessages(prev => {
        const next = prev.filter(m => m.id !== tempId);
        try { localStorage.setItem(`classmate_cached_dm_msgs_${convId}`, JSON.stringify(next)); } catch (e) {}
        return next;
      });
      console.error('Direct message was not saved to the cloud:', e);
      throw new Error('Your message was not saved. Check your connection and try again.');
    }
  };

  // Storage Actions
  const handleUploadFile = async (fileData: Omit<CloudFile, 'id' | 'createdAt' | 'downloadCount'>) => {
    const fileId = `file-${Date.now()}`;
    const newFile: CloudFile = {
      id: fileId,
      ...fileData,
      createdAt: new Date().toISOString(),
      downloadCount: 0
    };

    setCloudFiles(prev => [newFile, ...prev]);
    try {
      await setDoc(doc(db, 'user_files', fileId), {
        ...newFile,
        createdAt: serverTimestamp()
      });
    } catch (e) {}
  };

  const handleDeleteFile = async (fileId: string) => {
    setCloudFiles(prev => prev.filter(f => f.id !== fileId));
    try {
      await deleteDoc(doc(db, 'user_files', fileId));
    } catch (e) {}
  };

  const handleIncrementDownload = async (fileId: string) => {
    setCloudFiles(prev => prev.map(f => f.id === fileId ? { ...f, downloadCount: f.downloadCount + 1 } : f));
  };

  // Assignment Actions
  const handleCreateAssignment = async (assign: Omit<Assignment, 'id' | 'createdAt' | 'completedBy'>) => {
    const newAssign: Assignment = {
      id: `assign-${Date.now()}`,
      ...assign,
      createdAt: new Date().toISOString(),
      completedBy: []
    };

    setAssignments(prev => [newAssign, ...prev]);
    try {
      await setDoc(doc(db, 'assignments', newAssign.id), {
        ...newAssign,
        createdAt: serverTimestamp()
      });
    } catch (e) {}
  };

  const handleToggleAssignmentDone = async (assignId: string) => {
    const uid = userProfile?.uid;
    if (!uid || uid === 'guest') return;
    const assignment = assignments.find(item => item.id === assignId);
    if (!assignment) return;
    const alreadyCompleted = (assignment.completedBy || []).includes(uid);
    const nextCompleted = alreadyCompleted
      ? (assignment.completedBy || []).filter(id => id !== uid)
      : [...(assignment.completedBy || []), uid];

    // Optimistic UI update; persist the individual user's membership atomically.
    setAssignments(prev => prev.map(item => item.id === assignId
      ? { ...item, completedBy: nextCompleted }
      : item));
    try {
      await updateDoc(doc(db, 'assignments', assignId), {
        completedBy: alreadyCompleted ? arrayRemove(uid) : arrayUnion(uid)
      });
    } catch (error) {
      // Roll back the optimistic change if the backend rejects the write.
      setAssignments(prev => prev.map(item => item.id === assignId
        ? { ...item, completedBy: assignment.completedBy || [] }
        : item));
      console.warn('Could not update assignment completion:', error);
    }
  };

  const handleDeleteAssignment = async (assignId: string) => {
    setAssignments(prev => prev.filter(a => a.id !== assignId));
    try {
      await deleteDoc(doc(db, 'assignments', assignId));
    } catch (e) {}
  };

  // Study Groups Actions
  const handleCreateStudyGroup = async (group: Omit<StudyGroup, 'id'>) => {
    const newGrp: StudyGroup = {
      id: `grp-${Date.now()}`,
      ...group
    };
    setStudyGroups(prev => {
      const next = [newGrp, ...prev];
      try {
        localStorage.setItem('classmate_cached_studygroups', JSON.stringify(next));
      } catch (e) {}
      return next;
    });

    try {
      await setDoc(doc(db, 'study_groups', newGrp.id), {
        ...newGrp,
        createdAt: serverTimestamp()
      });
    } catch (e) {}
  };

  const handleJoinStudyGroup = async (groupId: string) => {
    const uid = userProfile?.uid || 'guest';
    let targetGroup: StudyGroup | undefined;
    setStudyGroups(prev => {
      const next = prev.map(g => {
        if (g.id !== groupId) return g;
        const members = g.members || [];
        const updated = members.includes(uid) ? members.filter(u => u !== uid) : [...members, uid];
        targetGroup = { ...g, members: updated };
        return targetGroup;
      });
      try {
        localStorage.setItem('classmate_cached_studygroups', JSON.stringify(next));
      } catch (e) {}
      return next;
    });

    if (targetGroup) {
      try {
        await updateDoc(doc(db, 'study_groups', groupId), {
          members: targetGroup.members
        });
      } catch (e) {}
    }
  };

  // Polls Actions
  const handleCreatePoll = async (question: string, optionTexts: string[]) => {
    const uid = currentUser?.uid;
    if (!uid || !userProfile || uid !== userProfile.uid || uid.startsWith('demo-')) {
      throw new Error('Sign in with a real account before creating a poll.');
    }
    if (!isAdmin) {
      throw new Error('Only an authorized class moderator or administrator can create polls.');
    }

    const newPoll: Poll = {
      id: `poll-${Date.now()}`,
      question,
      options: optionTexts.map((text, i) => ({ id: `opt-${i + 1}`, text, votes: [] })),
      createdBy: uid,
      createdByName: userProfile.displayName || 'Classmate',
      createdAt: new Date().toISOString(),
      isClosed: false
    };

    try {
      await setDoc(doc(db, 'polls', newPoll.id), {
        ...newPoll,
        options: newPoll.options.map(({ id, text }) => ({ id, text })),
        // Keep an explicit string list so security rules can verify optionId membership.
        optionIds: newPoll.options.map(({ id }) => id),
        createdAt: serverTimestamp()
      });
      // Display the poll locally only after Firestore confirms it was saved.
      setPolls(prev => [newPoll, ...prev]);
    } catch (error) {
      console.warn('Could not create poll:', error);
      throw new Error('The poll was not saved. Confirm your moderator/admin access and try again.');
    }
  };

  const handleVotePoll = async (pollId: string, optionId: string) => {
    const uid = userProfile?.uid;
    if (!uid || uid === 'guest' || uid.startsWith('demo-')) return;

    const pollRef = doc(db, 'polls', pollId);
    const voteRef = doc(db, 'polls', pollId, 'votes', uid);
    try {
      await runTransaction(db, async transaction => {
        const pollSnapshot = await transaction.get(pollRef);
        const voteSnapshot = await transaction.get(voteRef);
        if (!pollSnapshot.exists()) throw new Error('This poll no longer exists.');
        const poll = pollSnapshot.data();
        if (poll.isClosed) throw new Error('This poll is closed.');
        if (!Array.isArray(poll.options) || !poll.options.some((option: any) => option.id === optionId)
          || !Array.isArray(poll.optionIds) || !poll.optionIds.includes(optionId)) {
          throw new Error('That poll option is unavailable. Refresh the poll or ask a moderator to update it.');
        }
        // One vote document per authenticated UID means a user can only alter their own vote.
        if (voteSnapshot.exists() && voteSnapshot.data().optionId === optionId) {
          transaction.delete(voteRef); // tap the selected option again to withdraw the vote
        } else {
          transaction.set(voteRef, { userId: uid, optionId, updatedAt: serverTimestamp() });
        }
      });
    } catch (error) {
      console.warn('Could not save poll vote:', error);
      const message = error instanceof Error ? error.message : 'Please check your connection and try again.';
      if (typeof window !== 'undefined') window.alert(`Your vote was not saved. ${message}`);
    }
  };

  const handleDeletePoll = async (pollId: string) => {
    if (!currentUser || !isAdmin || !userProfile || userProfile.uid !== currentUser.uid || currentUser.uid.startsWith('demo-')) {
      if (typeof window !== 'undefined') window.alert('Only an authorized class moderator or administrator can delete polls.');
      return;
    }
    try {
      await deleteDoc(doc(db, 'polls', pollId));
      setPolls(prev => prev.filter(p => p.id !== pollId));
    } catch (error) {
      console.warn('Could not delete poll:', error);
      if (typeof window !== 'undefined') window.alert('The poll was not deleted. Confirm your moderator/admin access and try again.');
    }
  };

  // Admin Actions
  const handleUpdateUserRole = async (uid: string, role: UserProfile['role']) => {
    try {
      await updateDoc(doc(db, 'users', uid), { role });
    } catch (e) {}
  };

  const handleToggleUserVerified = async (uid: string, isVerified: boolean) => {
    try {
      await updateDoc(doc(db, 'users', uid), { isVerified });
    } catch (e) {}
  };

  const handleCreateAnnouncement = async (title: string, content: string, isImportant: boolean) => {
    const newAnn: Announcement = {
      id: `ann-${Date.now()}`,
      title,
      content,
      isImportant,
      createdBy: userProfile?.email || 'admin',
      createdByName: userProfile?.displayName || 'Admin',
      createdAt: new Date().toISOString()
    };

    setAnnouncements(prev => [newAnn, ...prev]);
    try {
      await setDoc(doc(db, 'announcements', newAnn.id), {
        ...newAnn,
        createdAt: serverTimestamp()
      });
    } catch (e) {}
  };

  const handleDeleteAnnouncement = async (annId: string) => {
    setAnnouncements(prev => prev.filter(a => a.id !== annId));
    try {
      await deleteDoc(doc(db, 'announcements', annId));
    } catch (e) {}
  };

  const handleCreateChannel = async (name: string, description: string, category: Channel['category'], isPrivate?: boolean) => {
    const newChan: Channel = {
      id: name.toLowerCase().replace(/\s+/g, '-'),
      name,
      description,
      category,
      isPrivate: !!isPrivate,
      createdBy: userProfile?.uid || 'admin',
      createdAt: new Date().toISOString()
    };

    setChannels(prev => [...prev, newChan]);
    try {
      await setDoc(doc(db, 'channels', newChan.id), {
        ...newChan,
        createdAt: serverTimestamp()
      });
    } catch (e) {}
  };

  const handleDeleteChannel = async (channelId: string) => {
    if (channelId === 'general') return;
    setChannels(prev => prev.filter(c => c.id !== channelId));
    if (selectedChannelId === channelId) {
      setSelectedChannelId('general');
    }
    try {
      await deleteDoc(doc(db, 'channels', channelId));
    } catch (e) {}
  };

  // Find active channel
  const currentChannel = channels.find(c => c.id === selectedChannelId) || channels[0] || INITIAL_CHANNELS[0];

  // Active top announcement
  const activeAnnouncement = announcements.find(a => !dismissedAnnouncements.includes(a.id));

  return (
    <div className="flex flex-col h-[100dvh] min-h-[100svh] w-full max-w-[100vw] bg-slate-950 text-slate-100 overflow-hidden font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Navigation */}
      <Navbar
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenEditProfile={() => setIsEditProfileModalOpen(true)}
        onOpenTestModal={() => setIsTestModalOpen(true)}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        onToggleMobileSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        unreadAnnouncementsCount={announcements.length}
      />

      {/* Global Broadcast Banner */}
      {activeAnnouncement && (
        <div className={`px-4 py-2 flex items-center justify-between text-xs transition-colors shrink-0 ${
          activeAnnouncement.isImportant 
            ? 'bg-gradient-to-r from-rose-950/80 to-purple-950/80 border-b border-rose-500/30 text-rose-200' 
            : 'bg-indigo-950/70 border-b border-indigo-500/30 text-indigo-200'
        }`}>
          <div className="flex items-center gap-2 truncate">
            <Megaphone className="w-4 h-4 shrink-0 text-indigo-400" />
            <strong className="font-semibold">{activeAnnouncement.title}:</strong>
            <span className="truncate opacity-90">{activeAnnouncement.content}</span>
          </div>
          <button
            type="button"
            onClick={() => setDismissedAnnouncements(prev => [...prev, activeAnnouncement.id])}
            className="p-1 hover:text-white rounded ml-2"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main App Canvas */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          channels={channels}
          selectedChannelId={selectedChannelId}
          onSelectChannel={(id) => setSelectedChannelId(id)}
          onOpenCreateChannel={() => setIsCreateChannelModalOpen(true)}
          onOpenTestModal={() => setIsTestModalOpen(true)}
          onOpenInstallModal={() => setIsInstallModalOpen(true)}
          unreadCountMap={{
            'exam-prep-vault': 3,
            'study-groups': 2,
            'lecture-notes-hub': 1
          }}
          isOpenMobile={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
          onOpenAuth={() => setIsAuthModalOpen(true)}
        />

        {/* Center / Right Content Panel */}
        <main className="flex-1 flex flex-col min-w-0 bg-slate-950 overflow-hidden">
          {activeTab === 'channels' && (
            <ChannelChat
              channel={currentChannel}
              messages={channelMessages}
              onSendMessage={handleSendMessage}
              onDeleteMessage={handleDeleteMessage}
              onTogglePinMessage={handleTogglePinMessage}
              onToggleReaction={handleToggleReaction}
            />
          )}

          {activeTab === 'direct-messages' && (
            <DirectMessages
              conversations={directConversations}
              activeConversation={activeConversation}
              onSelectConversation={setActiveConversation}
              onStartNewConversationWithUser={handleStartDirectMessage}
              messages={directMessages}
              onSendDirectMessage={handleSendDirectMessage}
              allUsers={allUsers}
            />
          )}

          {activeTab === 'storage-locker' && (
            <CloudStorageLocker
              files={cloudFiles}
              onUploadFile={handleUploadFile}
              onDeleteFile={handleDeleteFile}
              onIncrementDownload={handleIncrementDownload}
            />
          )}

          {activeTab === 'ai-assistant' && (
            <AIStudyAssistant />
          )}

          {activeTab === 'study-hub' && (
            <StudyGroupsAndTimer
              studyGroups={studyGroups}
              allUsers={allUsers}
              onCreateGroup={handleCreateStudyGroup}
              onJoinGroup={handleJoinStudyGroup}
            />
          )}

          {activeTab === 'assignments' && (
            <AssignmentsTracker
              assignments={assignments}
              onCreateAssignment={handleCreateAssignment}
              onToggleAssignmentDone={handleToggleAssignmentDone}
              onDeleteAssignment={handleDeleteAssignment}
            />
          )}

          {activeTab === 'directory' && (
            <ClassmateDirectory
              allUsers={allUsers}
              onStartDirectMessage={handleStartDirectMessage}
            />
          )}

          {activeTab === 'polls' && (
            <ClassPolls
              polls={polls}
              onCreatePoll={handleCreatePoll}
              onVotePoll={handleVotePoll}
              onDeletePoll={handleDeletePoll}
            />
          )}

          {activeTab === 'admin' && (
            <AdminPanel
              allUsers={allUsers}
              channels={channels}
              announcements={announcements}
              allFiles={cloudFiles}
              onUpdateUserRole={handleUpdateUserRole}
              onToggleUserVerified={handleToggleUserVerified}
              onCreateAnnouncement={handleCreateAnnouncement}
              onDeleteAnnouncement={handleDeleteAnnouncement}
              onCreateChannel={handleCreateChannel}
              onDeleteChannel={handleDeleteChannel}
            />
          )}
        </main>
      </div>

      {/* App Bottom Footer */}
      <footer 
        id="app-footer-credit-bar" 
        className="bg-slate-950/95 border-t border-slate-800/80 px-4 py-2 flex items-center justify-between text-xs text-slate-400 shrink-0 z-20 leading-tight transition-all duration-300 ease-out hover:border-slate-700/80 hover:shadow-[0_-4px_20px_rgba(0,0,0,0.45)]"
      >
        <div 
          className="group flex items-center gap-2.5 px-3 py-1.5 -my-0.5 rounded-lg border border-transparent transition-all duration-300 ease-out hover:bg-slate-900/80 hover:border-slate-800/80 hover:shadow-md hover:shadow-emerald-950/30 cursor-default select-none"
        >
          <div className="relative flex items-center justify-center">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse transition-all duration-300 group-hover:bg-emerald-300 group-hover:scale-110 shadow-sm shadow-emerald-400/50"></span>
            <span className="absolute w-3.5 h-3.5 rounded-full bg-emerald-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-ping pointer-events-none"></span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-slate-300 font-['Outfit',sans-serif] leading-tight transition-colors duration-300 group-hover:text-white">
              11 Graders
            </span>
            <span className="text-[11px] text-amber-400 font-['Cinzel',serif] font-bold leading-tight tracking-widest transition-all duration-300 group-hover:text-amber-300 group-hover:drop-shadow-[0_1px_6px_rgba(251,191,36,0.35)]">
              OF RICA
            </span>
          </div>
          <span className="text-[10px] text-slate-500 hidden sm:inline leading-none ml-1 transition-colors duration-300 group-hover:text-slate-300">
            • Campus Network
          </span>
        </div>

        <div 
          className="group flex items-center gap-2 text-xs font-medium px-3 py-1.5 -my-0.5 rounded-lg border border-transparent transition-all duration-300 ease-out hover:bg-slate-900/80 hover:border-slate-800/80 hover:shadow-md hover:shadow-indigo-950/40 cursor-pointer select-none"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-400/70 transition-all duration-300 group-hover:text-indigo-300 group-hover:rotate-12 group-hover:scale-110" />
          <span className="text-slate-400 transition-colors duration-300 group-hover:text-slate-200">
            Proudly made by
          </span>
          <span className="text-indigo-400 font-bold tracking-wide transition-all duration-300 group-hover:text-indigo-300 group-hover:drop-shadow-[0_2px_8px_rgba(129,140,248,0.4)]">
            Ebenezer Kruah
          </span>
        </div>
      </footer>

      {/* Global Modals */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      <EditProfileModal
        isOpen={isEditProfileModalOpen}
        onClose={() => setIsEditProfileModalOpen(false)}
      />

      <SystemDiagnosticModal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
        onOpenInstall={() => setIsInstallModalOpen(true)}
      />

      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />

      <CreateChannelModal
        isOpen={isCreateChannelModalOpen}
        onClose={() => setIsCreateChannelModalOpen(false)}
        onCreateChannel={handleCreateChannel}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
