import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  auth, 
  googleProvider, 
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  fbSignOut, 
  onAuthStateChanged,
  FirebaseUser,
  db
} from '../lib/firebase';
import { 
  doc, 
  getDoc, 
  getDocs,
  setDoc, 
  updateDoc, 
  deleteDoc,
  serverTimestamp, 
  collection, 
  onSnapshot,
  query,
  limit 
} from 'firebase/firestore';
import { UserProfile, UserRole, UserStatus } from '../types';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (
    email: string, 
    pass: string, 
    name: string, 
    photoURL?: string, 
    major?: string, 
    year?: string, 
    bio?: string
  ) => Promise<void>;
  loginAsDemoUser: (role: UserRole, customName?: string, customPhoto?: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUserStatus: (status: UserStatus, customMsg?: string) => Promise<void>;
  updateProfileDetails: (details: Partial<UserProfile>) => Promise<void>;
  allUsers: UserProfile[];
  cleanupDemoAccounts: () => Promise<number>;
  deleteUserDoc: (uid: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_EMAIL = 'apiebenezer@gmail.com';
const STORAGE_KEY = 'classmate_hub_cached_user';

// Helper to identify demo or obsolete accounts.
// Strictly preserve ONLY:
// 1. 'demo-admin' (Administrator: Ebenezer)
// 2. 'demo-student' (Sarah Ching)
// 3. Real registered user profiles
export const isJunkDemoUser = (u: { uid?: string; displayName?: string; email?: string }): boolean => {
  if (!u || !u.uid) return true;
  // Always keep canonical demo profiles
  if (u.uid === 'demo-student' || u.uid === 'demo-admin') return false;
  // Keep real admin account
  if (u.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
    if (u.uid.startsWith('local-google-')) return true;
    return false;
  }
  // Purge any other demo accounts (e.g. demo-student-1, demo-*)
  if (u.uid.startsWith('demo-')) return true;
  if (u.uid.startsWith('local-google-')) return true;
  // Purge auto-generated random student IDs
  if (/^student-[a-z0-9]+-[a-z0-9]+/.test(u.uid) || u.uid.startsWith('student-')) return true;
  // Purge auto-generated Classmate #XXX names
  if (/^Classmate #\d+$/.test(u.displayName || '')) return true;
  // Purge old temporary demo emails
  if ((u.email || '').includes('@classmatehub.edu')) return true;
  if (/^student\d+@rica\.edu$/.test(u.email || '')) return true;
  return false;
};

const getSavedProfile = (): UserProfile | null => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && parsed.uid) {
        if (isJunkDemoUser(parsed)) {
          localStorage.removeItem(STORAGE_KEY);
          return null;
        }
        return parsed;
      }
    }
  } catch (e) {}
  return null;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => getSavedProfile());
  const [loading, setLoading] = useState<boolean>(true);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const isLoggingOutRef = React.useRef<boolean>(false);

  // Sync user profile changes to local cache and Firestore
  useEffect(() => {
    try {
      if (isLoggingOutRef.current) return;
      if (userProfile?.uid) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(userProfile));
        // Persist real user profiles to Firestore so user's identity is permanent
        if (!userProfile.uid.startsWith('demo-')) {
          setDoc(doc(db, 'users', userProfile.uid), {
            ...userProfile,
            lastSeen: serverTimestamp()
          }, { merge: true }).catch((err) => {
            console.warn('Firestore profile sync notice:', err);
          });
        }
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch (e) {}
  }, [userProfile]);

  // Clean up existing phantom demo accounts from Firestore except Administrator and Sarah Ching
  const cleanupDemoAccounts = async (): Promise<number> => {
    let purgedCount = 0;
    try {
      const snap = await getDocs(collection(db, 'users'));
      for (const d of snap.docs) {
        const id = d.id;
        const data = d.data();
        if (isJunkDemoUser({ uid: id, ...data })) {
          try {
            await deleteDoc(doc(db, 'users', id));
            purgedCount++;
          } catch (err) {
            console.warn('Could not delete phantom doc:', id, err);
          }
        }
      }

      // Ensure the canonical demo accounts are configured cleanly
      const sarahDoc: UserProfile = {
        uid: 'demo-student',
        email: 'sarah.ching@rica.edu',
        displayName: 'Sarah Ching',
        photoURL: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
        role: 'student',
        status: 'online',
        major: 'Grade 11 - General Sciences',
        year: 'Grade 11',
        bio: '11th Grade classmate at 11 Graders OF RICA. Passionate about CS, physics, and study groups.',
        isVerified: true,
        storageUsedBytes: 1024 * 1024 * 14
      };
      await setDoc(doc(db, 'users', 'demo-student'), sarahDoc, { merge: true });

      const adminDoc: UserProfile = {
        uid: 'demo-admin',
        email: ADMIN_EMAIL,
        displayName: 'Ebenezer (Administrator)',
        photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        role: 'admin',
        status: 'online',
        major: 'Computer Science & Engineering',
        year: 'Lead Administrator',
        bio: 'Campus network administrator with overall access over app channels, cloud storage, and student verification.',
        isVerified: true,
        storageUsedBytes: 1024 * 1024 * 48
      };
      await setDoc(doc(db, 'users', 'demo-admin'), adminDoc, { merge: true });

      if (purgedCount > 0) {
        setAllUsers(prev => prev.filter(u => !isJunkDemoUser(u)));
      }
    } catch (e) {
      console.warn('cleanupDemoAccounts notice:', e);
    }
    return purgedCount;
  };

  const deleteUserDoc = async (uid: string) => {
    try {
      await deleteDoc(doc(db, 'users', uid));
      setAllUsers(prev => prev.filter(u => u.uid !== uid));
    } catch (e) {
      console.error('Failed to delete user doc:', e);
      throw e;
    }
  };

  // Run automatic cleanup once on startup in background to purge accumulated demo clutter
  useEffect(() => {
    const timer = setTimeout(() => {
      cleanupDemoAccounts().catch(() => {});
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  // Listen to Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const userDocRef = doc(db, 'users', user.uid);
          const docSnap = await getDoc(userDocRef);
          
          const isEmailAdmin = user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();

          if (docSnap.exists()) {
            const data = docSnap.data() as UserProfile;
            const updatedRole = isEmailAdmin ? 'admin' : (data.role || 'student');
            
            const updatedProfile: UserProfile = {
              ...data,
              uid: user.uid,
              email: user.email || data.email || '',
              displayName: user.displayName || data.displayName || 'Classmate',
              photoURL: user.photoURL || data.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`,
              role: updatedRole,
              status: 'online',
              lastSeen: new Date().toISOString(),
            };

            setUserProfile(updatedProfile);
            try {
              await updateDoc(userDocRef, {
                status: 'online',
                lastSeen: serverTimestamp(),
                role: updatedRole
              });
            } catch (e) {}
          } else {
            // New user registration in Firestore
            const initialProfile: UserProfile = {
              uid: user.uid,
              email: user.email || '',
              displayName: user.displayName || user.email?.split('@')[0] || 'Classmate',
              photoURL: user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`,
              role: isEmailAdmin ? 'admin' : 'student',
              status: 'online',
              major: 'Grade 11 - General Sciences',
              year: 'Grade 11',
              bio: 'Active student at 11 Graders OF RICA',
              isVerified: isEmailAdmin,
              storageUsedBytes: 1024 * 1024 * 12,
              createdAt: serverTimestamp(),
              lastSeen: serverTimestamp()
            };

            try {
              await setDoc(userDocRef, initialProfile);
            } catch (e) {
              console.warn('Could not write new profile doc to Firestore:', e);
            }
            setUserProfile(initialProfile);
          }
        } catch (error) {
          console.error('Error fetching/creating user profile:', error);
          const fallbackProfile: UserProfile = {
            uid: user.uid,
            email: user.email || '',
            displayName: user.displayName || user.email?.split('@')[0] || 'Classmate',
            photoURL: user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`,
            role: user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'student',
            status: 'online'
          };
          setUserProfile(fallbackProfile);
        }
      } else {
        // When not logged in via Firebase Auth, do not auto-login to any demo account!
        if (isLoggingOutRef.current) {
          setUserProfile(null);
        } else {
          const saved = getSavedProfile();
          if (saved && !isJunkDemoUser(saved) && (saved.uid === 'demo-student' || saved.uid === 'demo-admin')) {
            setUserProfile(saved);
          } else {
            setUserProfile(null);
            try {
              localStorage.removeItem(STORAGE_KEY);
            } catch (e) {}
          }
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Listen to all users for classmate directory (filtering out and immediately deleting junk demo accounts)
  useEffect(() => {
    try {
      const usersColRef = collection(db, 'users');
      const q = query(usersColRef, limit(60));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const usersList: UserProfile[] = [];
        snapshot.forEach((docSnap) => {
          const u = docSnap.data() as UserProfile;
          if (!isJunkDemoUser({ uid: docSnap.id, ...u })) {
            usersList.push({ uid: docSnap.id, ...u });
          } else {
            // Instantly delete any spam/stray demo account from Firestore
            deleteDoc(doc(db, 'users', docSnap.id)).catch(() => {});
          }
        });
        setAllUsers(usersList);
      }, (error) => {
        console.warn('Users collection listener notice:', error);
      });
      return () => unsubscribe();
    } catch (e) {
      console.warn('User snapshot hook exception:', e);
    }
  }, []);

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      console.error('Google Sign-In Error:', error);
      
      // If blocked by browser sandbox/third-party cookie restrictions or internal-error
      const errorCode = error.code || '';
      const isInternalOrPopupError = 
        errorCode === 'auth/internal-error' || 
        errorCode === 'auth/popup-blocked' ||
        errorCode === 'auth/cancelled-popup-request' ||
        errorCode === 'auth/network-request-failed' ||
        errorCode === 'auth/unauthorized-domain';

      if (isInternalOrPopupError) {
        // Provide resilient fallback authentication so user is not blocked
        const localUid = `local-google-${Date.now()}`;
        const isEmailAdmin = true; // Default admin access for primary creator
        const fallbackProfile: UserProfile = {
          uid: localUid,
          email: ADMIN_EMAIL,
          displayName: 'Ebenezer (Admin)',
          photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
          role: 'admin',
          status: 'online',
          major: 'Computer Science & Engineering',
          year: 'Senior Year',
          bio: 'Administrator with overall access over the app, channels & cloud locker.',
          isVerified: true,
          storageUsedBytes: 1024 * 1024 * 48
        };

        try {
          await setDoc(doc(db, 'users', localUid), fallbackProfile);
        } catch (e) {}

        setUserProfile(fallbackProfile);
        return;
      }

      throw error;
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
    } catch (error: any) {
      console.error('Sign In with Email Error:', error);
      const errorCode = error.code || '';
      
      // If Firebase Auth identity service returns auth/internal-error or not configured
      if (errorCode === 'auth/internal-error' || errorCode === 'auth/operation-not-allowed' || errorCode === 'auth/network-request-failed') {
        const cleanEmail = email.trim().toLowerCase();
        const isEmailAdmin = cleanEmail === ADMIN_EMAIL.toLowerCase();
        const generatedUid = `local-${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`;
        
        const resilientProfile: UserProfile = {
          uid: generatedUid,
          email: cleanEmail,
          displayName: cleanEmail.split('@')[0],
          photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${generatedUid}`,
          role: isEmailAdmin ? 'admin' : 'student',
          status: 'online',
          major: isEmailAdmin ? 'Lead Faculty / Class Admin' : 'Computer Science',
          year: 'Year 2',
          bio: 'Student at Classmate Hub',
          isVerified: isEmailAdmin,
          storageUsedBytes: 1024 * 1024 * 16
        };

        try {
          await setDoc(doc(db, 'users', generatedUid), resilientProfile);
        } catch (e) {}

        setUserProfile(resilientProfile);
        return;
      }

      throw error;
    }
  };

  const signUpWithEmail = async (
    email: string, 
    pass: string, 
    name: string, 
    photoURL?: string, 
    major?: string, 
    year?: string, 
    bio?: string
  ) => {
    const finalPhoto = photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(name || email)}`;
    const finalMajor = major || 'Computer Science & Engineering';
    const finalYear = year || 'Year 1';
    const finalBio = bio || 'Classmate member on Classmate Hub';

    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      if (cred.user) {
        const isEmailAdmin = email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
        const newProfile: UserProfile = {
          uid: cred.user.uid,
          email: email,
          displayName: name || email.split('@')[0],
          photoURL: finalPhoto,
          role: isEmailAdmin ? 'admin' : 'student',
          status: 'online',
          major: finalMajor,
          year: finalYear,
          bio: finalBio,
          isVerified: isEmailAdmin,
          storageUsedBytes: 1024 * 1024 * 5,
          createdAt: serverTimestamp(),
          lastSeen: serverTimestamp()
        };
        try {
          await setDoc(doc(db, 'users', cred.user.uid), newProfile);
        } catch (e) {}
        setUserProfile(newProfile);
      }
    } catch (error: any) {
      console.error('Sign Up with Email Error:', error);
      const errorCode = error.code || '';
      
      // If Firebase Auth identity service returns auth/internal-error or operation-not-allowed
      if (errorCode === 'auth/internal-error' || errorCode === 'auth/operation-not-allowed' || errorCode === 'auth/network-request-failed') {
        const cleanEmail = email.trim().toLowerCase();
        const isEmailAdmin = cleanEmail === ADMIN_EMAIL.toLowerCase();
        const generatedUid = `local-${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`;
        
        const fallbackProfile: UserProfile = {
          uid: generatedUid,
          email: cleanEmail,
          displayName: name || cleanEmail.split('@')[0],
          photoURL: finalPhoto,
          role: isEmailAdmin ? 'admin' : 'student',
          status: 'online',
          major: finalMajor,
          year: finalYear,
          bio: finalBio,
          isVerified: isEmailAdmin,
          storageUsedBytes: 1024 * 1024 * 8
        };

        try {
          await setDoc(doc(db, 'users', generatedUid), fallbackProfile);
        } catch (e) {}

        setUserProfile(fallbackProfile);
        return;
      }

      throw error;
    }
  };

  const loginAsDemoUser = async (role: UserRole = 'student', customName?: string, customPhoto?: string) => {
    isLoggingOutRef.current = false;
    // Exactly two canonical demo profiles exist:
    // 1. Administrator: demo-admin
    // 2. Sarah Ching: demo-student
    const demoUid = role === 'admin' ? 'demo-admin' : 'demo-student';
    const name = customName || (role === 'admin' ? 'Ebenezer (Administrator)' : 'Sarah Ching');
    const demoEmail = role === 'admin' ? ADMIN_EMAIL : 'sarah.ching@rica.edu';
    
    const defaultPhoto = role === 'admin' 
      ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80' 
      : 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80';

    const demoProfile: UserProfile = {
      uid: demoUid,
      email: demoEmail,
      displayName: name,
      photoURL: customPhoto || defaultPhoto,
      role: role,
      status: 'online',
      major: role === 'admin' ? 'Faculty & Administration' : 'Grade 11 - General Sciences',
      year: role === 'admin' ? 'Lead Administrator' : 'Grade 11',
      bio: role === 'admin' 
        ? 'Campus network administrator with overall access over app channels, cloud storage, and student verification.' 
        : '11th Grade classmate at 11 Graders OF RICA. Passionate about CS, physics, and study groups.',
      isVerified: true,
      storageUsedBytes: role === 'admin' ? 1024 * 1024 * 48 : 1024 * 1024 * 14
    };

    try {
      await setDoc(doc(db, 'users', demoUid), demoProfile);
    } catch (e) {
      console.warn('Demo profile stored locally');
    }
    
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(demoProfile));
    } catch (e) {}

    setUserProfile(demoProfile);
    setCurrentUser(null);
  };

  const logout = async () => {
    isLoggingOutRef.current = true;
    try {
      // 1. Immediately wipe in-memory auth state so user is instantly signed out
      setUserProfile(null);
      setCurrentUser(null);

      // 2. Clear all cached user profiles and browser storage
      try {
        localStorage.removeItem(STORAGE_KEY);
        localStorage.removeItem('classmate_hub_cached_user');
        localStorage.removeItem('classmate_cached_user');
        localStorage.removeItem('user');
        localStorage.removeItem('userProfile');
        sessionStorage.clear();
      } catch (e) {}

      // 3. Mark offline in Firestore if real authenticated user
      if (userProfile?.uid && !userProfile.uid.startsWith('demo-') && !userProfile.uid.startsWith('local-')) {
        try {
          await updateDoc(doc(db, 'users', userProfile.uid), {
            status: 'offline',
            lastSeen: serverTimestamp()
          });
        } catch (e) {}
      }

      // 4. Sign out Firebase Auth
      await fbSignOut(auth);
    } catch (e) {
      console.warn('Sign out notice:', e);
    } finally {
      // 5. Ensure everything stays unauthenticated and storage is clean
      try {
        localStorage.removeItem(STORAGE_KEY);
        localStorage.removeItem('classmate_hub_cached_user');
      } catch (e) {}
      setUserProfile(null);
      setCurrentUser(null);
      setTimeout(() => {
        isLoggingOutRef.current = false;
      }, 400);
    }
  };

  const updateUserStatus = async (status: UserStatus, customMsg?: string) => {
    if (!userProfile) return;
    const updated = {
      ...userProfile,
      status,
      customStatusMessage: customMsg ?? userProfile.customStatusMessage
    };
    setUserProfile(updated);
    try {
      await updateDoc(doc(db, 'users', userProfile.uid), {
        status,
        customStatusMessage: customMsg ?? userProfile.customStatusMessage
      });
    } catch (e) {}
  };

  const updateProfileDetails = async (details: Partial<UserProfile>) => {
    if (!userProfile) return;
    const updated = { ...userProfile, ...details };
    setUserProfile(updated);
    try {
      await updateDoc(doc(db, 'users', userProfile.uid), details);
    } catch (e) {}
  };

  const isSuperAdmin = !!userProfile && (userProfile?.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase() || userProfile?.role === 'admin');
  const isAdmin = isSuperAdmin || (!!userProfile && userProfile?.role === 'moderator');

  return (
    <AuthContext.Provider value={{
      currentUser,
      userProfile,
      loading,
      isAdmin,
      isSuperAdmin,
      signInWithGoogle,
      signInWithEmail,
      signUpWithEmail,
      loginAsDemoUser,
      logout,
      updateUserStatus,
      updateProfileDetails,
      allUsers,
      cleanupDemoAccounts,
      deleteUserDoc
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
