import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');
const manifest = JSON.parse(read('public/manifest.json'));
const sw = read('public/sw.js');
const html = read('index.html');
const appSource = read('src/App.tsx');
const rules = read('firestore.rules');
const server = read('server.ts');
const errors = [];

if (!manifest.name || !manifest.short_name) errors.push('PWA manifest must include name and short_name.');
if (manifest.start_url !== '/' || manifest.scope !== '/') errors.push('Expected root start_url and scope.');
if (!['standalone', 'fullscreen', 'minimal-ui'].includes(manifest.display)) errors.push('PWA display mode should be installable.');
for (const icon of manifest.icons ?? []) {
  const file = path.join(root, 'public', icon.src.replace(/^\//, ''));
  if (!fs.existsSync(file)) errors.push(`Missing manifest icon: ${icon.src}`);
}
if (!html.includes('rel="manifest"')) errors.push('index.html does not link to the PWA manifest.');
if (!html.includes("navigator.serviceWorker.register('/sw.js')")) errors.push('index.html does not register the service worker.');
if (!sw.includes("url.pathname.startsWith('/api/')")) errors.push('Service worker should bypass API requests.');
if (!sw.includes('url.origin !== self.location.origin')) errors.push('Service worker should bypass cross-origin requests.');
if (!sw.includes('caches.match(\'/index.html\')')) errors.push('Service worker should provide an offline navigation fallback.');
if (!appSource.includes('optionIds: p.options.map(({ id }) => id)')) errors.push('Seeded polls should store optionIds for vote validation.');
if (!appSource.includes('optionIds: newPoll.options.map(({ id }) => id)')) errors.push('New polls should store optionIds for vote validation.');
if (!rules.includes('optionId in poll.optionIds')) errors.push('Firestore rules should verify vote option IDs against poll metadata.');
if (!rules.includes('request.resource.data.updatedAt == request.time')) errors.push('Firestore vote writes should require a server timestamp.');
if (!rules.includes('allow delete: if isSelf(uid) && parentPollOpen()')) errors.push('Closed polls should not allow votes to be withdrawn.');
if (!appSource.includes('Only an authorized class moderator or administrator can create polls.')) errors.push('Poll creation should explain the required role instead of silently failing.');
if (!server.includes("app.use('/api/ai', (req, res, next) =>")) errors.push('AI endpoints should have request-guard middleware.');
if (!server.includes('AI_MAX_REQUESTS_PER_WINDOW = 60')) errors.push('AI endpoint rate limit should be configured.');
if (!server.includes('AI_MAX_TOTAL_HISTORY_CHARS = 40_000')) errors.push('AI chat history should have a total character bound.');

if (errors.length) {
  console.error('ClassmateHub release checks FAILED:');
  for (const error of errors) console.error(`- ${error}`);
  process.exitCode = 1;
} else {
  console.log('ClassmateHub focused release checks passed: PWA metadata/icons, service-worker behavior, poll vote validation, and AI request size/rate guards.');
  console.log('Note: these checks do not replace a full TypeScript/Vite build or live Firebase/Gemini integration tests.');
}
