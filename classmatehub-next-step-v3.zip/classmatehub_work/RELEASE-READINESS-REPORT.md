# ClassmateHub release-readiness report

Date: 2026-10-24

## Security changes made in this pass

- Replaced permissive Firestore rules with authenticated access and default-deny rules for unlisted collections.
- Restricted user profile creation to the authenticated owner and prevented users from changing their own role or verification state.
- Privileged writes rely on trusted Firebase Auth custom claims (`admin` / `moderator`) or the explicitly configured owner email; editable profile role fields are not treated as authority.
- Limited direct conversation access to listed participants, including nested messages.
- Limited AI chat history to its owning `userId`.
- Limited private files to their owner/admin and shared files to authenticated classmates.
- Restricted system settings to administrators.
- Updated the direct-conversation listener to query only conversations containing the signed-in UID.
- Updated Cloud Locker listeners to separately query public files and files owned by the signed-in user, so the client query matches the security rules.
- Scoped local AI chat history to the active account and filtered remote AI chat reads by `userId`.
- Filtered cached direct-conversation metadata to conversations in which the current UID is a participant.

## Important deployment prerequisite

These Firestore rules are a safer starting point, but they have **not** been deployed or run through the Firebase Emulator Suite. Test the rules against the app's actual flows before production. In particular:

- Create Firebase Auth custom claims for approved moderators/admins if those roles are needed. The UI's editable profile `role` field alone does not grant backend privileges.
- Review old Firestore documents for role escalation or data written while the previous rules were permissive.
- Check that every existing shared file has `isPublic: true` and an accurate `userId`; private files need an owner `userId`.
- The application contains demo/local fallback profiles that are not Firebase Auth identities. These cannot access protected Firestore data under the new rules; use real authenticated test accounts for backend testing.
- Poll voting and study-group membership updates still need stricter per-field validation and emulator tests before treating them as tamper-proof.

## Checks completed

- `node --check public/sw.js`
- `node --check scripts/verify-release.mjs`
- JSON parsing for `package.json` and `public/manifest.json`
- PWA verification script (previous release pass)
- ZIP archive integrity (rerun on the generated archive)

## Build status

A fresh `npm install --ignore-scripts --no-audit --no-fund --prefer-offline` attempt timed out in this environment. There is no complete production build result, and `npm run lint` has not been completed. Firebase rules syntax and live integration have not been emulator-tested. This archive remains a security-focused release candidate, not a production-certified release.

## Before publishing

1. Install dependencies successfully, then run `npm run lint`, `npm run check:pwa`, and `npm run build`.
2. Test Firestore rules with Firebase Emulator Suite and separate student/teacher/admin accounts.
3. Finish rule validation for poll votes and study-group membership.
4. Confirm Firebase authorized domains and production environment secrets.
5. Test authentication, direct messages, uploads, assignments, polls, and AI requests end to end.
6. Test PWA installation and offline behavior on Android, Windows, and iPhone.

## Additional functional pass (2026-10-24)

- Poll voting now persists to Firestore using a transaction, checks that the poll exists and is open, validates the selected option, and ensures each signed-in user has at most one selected option in the saved poll state. Guests/demo profiles cannot submit votes to Firestore.
- Assignment completion now persists via Firestore `arrayUnion` / `arrayRemove` instead of changing only local React state. The UI rolls back its optimistic update if the backend rejects the write. Guest/demo profiles cannot submit completion updates.
- Firestore assignment completion rules now limit student writes to the `completedBy` field and permit only the signed-in user's own UID to be added or removed.
- Firestore study-group membership rules now permit ordinary users to add/remove only their own UID from the membership list; moderator/admin overrides remain available.

## Validation for this pass

- `node scripts/verify-release.mjs`: passed.
- `node --check public/sw.js`: passed.
- `node --check scripts/verify-release.mjs`: passed.
- Original ZIP integrity check: passed.
- TypeScript is available globally for syntax transpilation, but Vite/esbuild dependencies are not installed in this runtime. Full project type-check/build and Firebase Emulator tests remain outstanding.
- Poll votes are still stored as nested vote arrays in each poll document. Because Firestore Rules cannot conveniently iterate through every option to prove that only the current user's vote changed, the current rules still need a follow-up redesign (e.g. per-user vote documents plus a trusted aggregate) before polls can be described as tamper-proof. Do not deploy these rules as a production security guarantee until emulator tests and this poll authorization gap are resolved.

## Poll vote isolation pass (2026-10-24)

- Changed poll voting from editing a shared `options[].votes` array on the poll document to one vote document per authenticated user at `polls/{pollId}/votes/{uid}`.
- Poll listeners aggregate those vote documents into the existing UI's `options[].votes` shape, keeping the current poll component API compatible.
- Poll definitions can now only be updated/deleted by moderators/admins under the Firestore rules; students can create/update only their own vote document, and vote writes require the parent poll to remain open.
- The client validates the poll and option in a transaction before setting or withdrawing the current user's vote.
- Legacy embedded vote arrays are not automatically migrated. Existing votes stored only in poll documents will not appear in totals until an administrator performs a deliberate migration. This avoids trusting old, user-editable vote arrays as authoritative data.

### Validation update

- `node scripts/verify-release.mjs`: passed.
- `node --check public/sw.js`: passed.
- `node --check scripts/verify-release.mjs`: passed.
- TypeScript transpilation syntax check for `src/App.tsx`: passed (syntax-only, not full type checking).
- `tsc --noEmit` remains blocked because project dependencies/types (React, Firebase, Express, Vite, Node types) are not installed in this environment. Do not treat this as a successful full build.
- Firestore rules still require Firebase Emulator Suite testing. In particular, add explicit option-ID validation via trusted poll metadata or a callable backend before public production use; current rules isolate vote ownership but only validate that `optionId` is a non-empty string.

## Latest hardening pass (2026-10-24)

- Added an explicit `optionIds` list to newly created and seeded polls. Firestore vote rules now require a selected ID to appear in that trusted parent-poll list, require the server timestamp, and prevent changing or withdrawing a vote after the poll closes.
- Poll voting now gives the user visible failure feedback instead of only logging denied writes. Poll creation no longer inserts a temporary local poll before Firestore confirms the write, and poll deletion updates the screen only after the backend confirms deletion.
- Poll-management controls are limited in the UI to real accounts whose profile is marked as a moderator/administrator; Firestore custom-claim/owner-email rules remain the authority, and can still reject a profile whose backend privileges are not configured.
- Added a process-local AI API guard for the `/api/ai` routes: 60 requests per IP per minute, bounded prompt/context/persona/subject/action lengths, a maximum of 80 chat-history messages, a per-message limit, and a total history character limit. This mitigates oversized and accidental bursts, but it is not a replacement for authenticated per-user quotas or a shared rate limiter across multiple server instances.
- Extended `npm run check:pwa` (the existing dependency-free release check) to verify poll option validation and the AI request guards.

### Validation completed in this pass

- `node --check public/sw.js`: passed.
- `node --check scripts/verify-release.mjs`: passed.
- `node scripts/verify-release.mjs`: passed.
- Global TypeScript syntax transpilation across 25 `.ts`/`.tsx` files, including `server.ts`: 0 syntax errors. This checks syntax only; it is not a full type-check or production build.
- ZIP integrity is checked again after the final archive is assembled.

### Remaining release blockers / important limitations

- A complete dependency install and Vite/esbuild production build have not succeeded in this environment. The offline install failed because the dependencies were not cached; the earlier online install timed out. Do not describe this archive as a fully built or production-certified release.
- Firebase Emulator Suite tests and live Firebase/Gemini end-to-end tests have not been run. The actual deployment account also reported a daily AppDeploy credit limit below the minimum deployment cost, so no live deployment has been performed.
- **Existing poll documents need a deliberate migration.** Older polls that lack `optionIds` will not accept votes under the stricter rule. Add an `optionIds` array to each existing poll containing the exact IDs already present in its `options` array, using an authorized administrator process. Old embedded `options[].votes` are not automatically trusted or imported.
- **Poll vote records are not anonymous in Firestore.** The current votes subcollection is readable by authenticated classmates so the frontend can aggregate counts; a technically capable signed-in student could inspect the voter UID and selected option. If polls must be confidential, move aggregation to a trusted backend and restrict vote-document reads before public release.
- The AI guard is process-local and keyed by `req.ip`. Depending on hosting proxy configuration, multiple classmates might share an IP bucket; a multi-instance production deployment needs a shared limiter, and the routes should be tied to verified Firebase identity before introducing stronger per-user quotas.
- Firestore role rules require trusted custom claims (or the configured owner email); setting the profile `role` field alone does not grant actual database permissions.
