import express from 'express';
import path from 'path';
import fs from 'fs';
import compression from 'compression';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

// Enable HTTP response compression (gzip/deflate) to drastically reduce data usage on all responses
app.use(compression({
  threshold: 512, // Compress any response payload larger than 512 bytes
}));

app.use(express.json({ limit: '15mb' }));

// Lightweight process-local guard for the public AI routes. This limits accidental
// cost spikes and oversized prompts; it is not a replacement for authenticated
// per-user quotas or a shared rate limiter in a multi-instance deployment.
const aiRequestBuckets = new Map<string, { windowStartedAt: number; count: number }>();
const AI_RATE_WINDOW_MS = 60_000;
const AI_MAX_REQUESTS_PER_WINDOW = 60;
const AI_MAX_PROMPT_CHARS = 8_000;
const AI_MAX_CONTEXT_CHARS = 25_000;
const AI_MAX_HISTORY_MESSAGES = 80;
const AI_MAX_MESSAGE_CHARS = 16_000;
const AI_MAX_TOTAL_HISTORY_CHARS = 40_000;

app.use('/api/ai', (req, res, next) => {
  const now = Date.now();
  const clientKey = req.ip || req.socket.remoteAddress || 'unknown';
  let bucket = aiRequestBuckets.get(clientKey);

  if (!bucket || now - bucket.windowStartedAt >= AI_RATE_WINDOW_MS) {
    bucket = { windowStartedAt: now, count: 0 };
    aiRequestBuckets.set(clientKey, bucket);
  }

  if (bucket.count >= AI_MAX_REQUESTS_PER_WINDOW) {
    const retryAfter = Math.max(1, Math.ceil((AI_RATE_WINDOW_MS - (now - bucket.windowStartedAt)) / 1000));
    res.setHeader('Retry-After', String(retryAfter));
    return res.status(429).json({ success: false, error: 'Too many AI requests. Please wait a moment and try again.' });
  }
  bucket.count += 1;

  // Bound prompt sizes before they are sent to Gemini. The browser already sends
  // chat entries as { role, text }; accepting `content` also supports older clients.
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
  for (const [field, maxLength] of [
    ['prompt', AI_MAX_PROMPT_CHARS],
    ['context', AI_MAX_CONTEXT_CHARS],
    ['persona', 200],
    ['subject', 200],
    ['action', 40]
  ] as const) {
    const value = body[field];
    if (value !== undefined && (typeof value !== 'string' || value.length > maxLength)) {
      return res.status(413).json({ success: false, error: `${field} must be text no longer than ${maxLength} characters.` });
    }
  }

  if (body.messages !== undefined) {
    if (!Array.isArray(body.messages) || body.messages.length > AI_MAX_HISTORY_MESSAGES) {
      return res.status(413).json({ success: false, error: `Chat history must contain no more than ${AI_MAX_HISTORY_MESSAGES} messages.` });
    }
    let totalHistoryChars = 0;
    for (const message of body.messages) {
      if (!message || typeof message !== 'object') {
        return res.status(400).json({ success: false, error: 'Chat history contains an invalid message.' });
      }
      const content = message.text ?? message.content ?? '';
      if (typeof content !== 'string' || content.length > AI_MAX_MESSAGE_CHARS) {
        return res.status(413).json({ success: false, error: `Each chat message must be text no longer than ${AI_MAX_MESSAGE_CHARS} characters.` });
      }
      totalHistoryChars += content.length;
      if (totalHistoryChars > AI_MAX_TOTAL_HISTORY_CHARS) {
        return res.status(413).json({ success: false, error: `Chat history must stay under ${AI_MAX_TOTAL_HISTORY_CHARS} characters. Start a new chat to continue.` });
      }
    }
  }

  // Prevent the map from growing without limit if a server receives many unique IPs.
  if (aiRequestBuckets.size > 5_000) {
    for (const [key, value] of aiRequestBuckets) {
      if (now - value.windowStartedAt >= AI_RATE_WINDOW_MS) aiRequestBuckets.delete(key);
    }
  }

  next();
});

// Lazy initialize Gemini API client
let aiClient: GoogleGenAI | null = null;
function getAIClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

// Health & Diagnostic endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    aiAvailable: !!process.env.GEMINI_API_KEY,
    version: '1.0.0'
  });
});

// Explicit ZIP Archive Download Route with attachment headers
app.get(['/api/download-zip', '/download/classmatehub-website.zip', '/classmatehub-website.zip'], (req, res) => {
  const zipPath = path.join(process.cwd(), 'public', 'classmatehub-website.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="classmatehub-website.zip"');
    const fileStream = fs.createReadStream(zipPath);
    fileStream.pipe(res);
  } else {
    res.status(404).send('ZIP archive not found on server.');
  }
});

// AI Study Assistant endpoint (summaries, flashcards, explanations, quiz generation)
app.post('/api/ai/study-assist', async (req, res) => {
  try {
    const { action, prompt, context, subject } = req.body;
    const ai = getAIClient();

    if (!ai) {
      // Graceful fallback if GEMINI_API_KEY is not configured yet
      return res.json({
        success: true,
        result: `### 🎯 Quick Summary & Plain-English Solution\n\n` +
          `**Subject:** ${subject || 'General Studies'}\n\n` +
          `#### 1. The Short & Direct Answer\n` +
          `Here is the main takeaway in plain words: ${prompt || 'For this concept, always start with what you are given, use the core rule, and simplify step-by-step.'}\n\n` +
          `#### 2. The Simple Idea (What this means)\n` +
          `Think of this like building with blocks: you identify what pieces you already have, pick the right tool, and assemble them in order so you never get confused.\n\n` +
          `#### 3. Step-by-Step Walkthrough in Simple Steps\n` +
          `- **Step 1:** Write down what the problem tells you (your known numbers and goals).\n` +
          `- **Step 2:** Pick the simple formula or rule that connects them.\n` +
          `- **Step 3:** Put the numbers into the formula and solve carefully.\n\n` +
          `#### ✍️ What to Write in Your Notebook\n` +
          `1. State the given information clearly.\n` +
          `2. Show the calculation line by line.\n` +
          `3. Box or underline the final answer with its units.`
      });
    }

    let systemInstruction = `You are an expert AI tutor who explains and solves ANY problem in plain, crystal-clear, human-understandable language. 

CRITICAL RULE - HUMAN-READABLE PLAIN TEXT:
- NEVER output raw LaTeX markup (avoid raw LaTeX like \\int, \\frac, \\mathbb, \\implies, \\cdot, \\approx). Write math and equations using simple, friendly text that a human can easily read and copy by hand into a school notebook (e.g. write "1/4 * e^(2x)", "x squared", "integral of x * e^(2x) dx", "F = m * a").
- Explain EVERY concept and equation in plain everyday English that a regular student can understand immediately.
- Use simple analogies and intuitive reasoning. Avoid heavy, unhelpful academic jargon.

When solving any problem, organize your answer into these 4 clear sections:
1. **Direct Answer First**: Give the bottom-line answer immediately in 1-2 bold lines.
2. **The Simple Idea**: Explain in 1-3 sentences what the problem is really asking and the intuition behind it in plain words.
3. **Step-by-Step Solution in Plain English**:
   - Step 1: What we have (Given facts and numbers).
   - Step 2: The rule or formula we need (explained in simple words).
   - Step 3: Doing the calculation (showing each line clearly with an explanation of *why* we do it).
   - Step 4: The final result with units.
4. **✍️ What to Write in Your Notebook**: A clean, numbered summary that the student can copy directly into their homework or notebook.`;

    if (action === 'summarize') {
      systemInstruction += ' Focus on summarizing the notes into simple, clear bullet points, everyday definitions, and easy memory tricks.';
    } else if (action === 'quiz') {
      systemInstruction += ' Generate 4 high-yield practice quiz questions with complete, clear answer keys and plain-English explanations.';
    } else if (action === 'explain') {
      systemInstruction += ' Explain the concept in very simple, intuitive everyday language with relatable real-world analogies.';
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `${systemInstruction}\n\nSubject/Course: ${subject || 'General'}\nContext/Material:\n${context || ''}\n\nStudent Question / Prompt: ${prompt || 'Help me understand this material thoroughly.'}`
            }
          ]
        }
      ],
      config: {
        temperature: 0.7,
      }
    });

    res.json({
      success: true,
      result: response.text || 'No response generated.'
    });
  } catch (error: any) {
    console.error('AI Study Assist Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to process AI study request'
    });
  }
});

// Full ChatGPT conversational problem-solving endpoint
app.post('/api/ai/chat', async (req, res) => {
  try {
    const { messages, prompt, persona, subject } = req.body;
    const ai = getAIClient();

    if (!ai) {
      return res.json({
        success: true,
        model: 'chatgpt-plain-fallback',
        result: `### 🎯 Quick Answer\n\n` +
          `Here is the bottom-line answer for **"${prompt || 'your question'}"**:\n\n` +
          `**Answer:** Break the problem into what is given, use the simple rule connecting the values, and calculate step-by-step.\n\n` +
          `#### 💡 The Simple Idea (In Plain English)\n` +
          `Don't get overwhelmed by big words or symbols. Every problem just asks you to take known clues, match them with a basic rule, and find the missing piece.\n\n` +
          `#### 🪜 Simple Step-by-Step Walkthrough\n` +
          `1. **What we know:** List all the numbers and clues given in the question.\n` +
          `2. **The rule we need:** Pick the formula or concept that ties them together.\n` +
          `3. **Step-by-step math:** Put your numbers into the formula and solve cleanly.\n\n` +
          `#### ✍️ What to Write in Your Notebook\n` +
          `- Given: Write your values clearly.\n` +
          `- Formula: State your equation.\n` +
          `- Final Solution: Clearly box your final answer with units.`
      });
    }

    let chatgptSystemPrompt = `You are a friendly, brilliant AI tutor and problem solver who explains and solves ANY problem in plain, easy-to-understand English that a real human student can easily follow and copy into their notebook.

### 🌟 CRITICAL MANDATE - PLAIN, HUMAN-UNDERSTANDABLE ANSWERS:
1. **NO UNREADABLE COMPUTER LATEX CODE**:
   - DO NOT output raw LaTeX markup (avoid raw LaTeX commands like \\int, \\frac, \\mathbb, \\implies, \\cdot, \\approx). 
   - Write equations using simple, clear, readable text (for example: "1/4 * e^(2x) * (2x - 1) + C", "integral of x * e^(2x) dx", "x squared", "F = m * a").
   - Any student should be able to read it aloud effortlessly and write it down with a pen in their school notebook without getting confused.

2. **STRUCTURE EVERY SOLUTION IN 4 CLEAR SECTIONS**:
   - **🎯 Quick Direct Answer**: State the final answer or core takeaway immediately in bold at the very top.
   - **💡 The Simple Idea (Plain English Intuition)**: Explain *what the problem actually means* in 1-3 simple, friendly sentences using an everyday analogy or common-sense concept. Avoid robotic or overly complex jargon.
   - **🪜 Step-by-Step Walkthrough**:
     - *Step 1 (What we are given)*: List the clues, numbers, and what we need to find.
     - *Step 2 (The formula or principle)*: Explain which rule to use and what each letter means in plain English.
     - *Step 3 (The calculation)*: Work through each line step-by-step, explaining in simple words *why* we take each step.
     - *Step 4 (Final result)*: Emphasize the final number and its units.
   - **✍️ What to Write in Your Notebook**: Provide a neat, concise summary with numbered steps that the student can copy word-for-word into their homework or notebook!

3. **Coding & Computer Science**:
   - Write clean, well-commented code with clear explanations.
   - Explain what each part of the code does in everyday terms.
   - Mention Time and Space efficiency in simple words (e.g. "Takes linear time O(N), meaning it looks at each item once").

4. **Tone**: Warm, encouraging, crystal-clear, patient, and easy to understand. Never talk down to the student, and never use needlessly complicated words when a simple word works better.`;

    if (persona === 'solver' || persona === 'general') {
      chatgptSystemPrompt += " Focus on breaking down complex problems into clear, bite-sized, human-friendly steps with zero confusing jargon.";
    } else if (persona === 'coder') {
      chatgptSystemPrompt += " Adopt the persona of a friendly senior software engineer who explains coding and algorithms with simple diagrams, comments, and plain-English logic.";
    } else if (persona === 'professor') {
      chatgptSystemPrompt += " Explain deep conceptual foundations using intuitive real-world examples, clear historical context, and relatable analogies.";
    } else if (persona === 'exam_prep') {
      chatgptSystemPrompt += " Focus on high-yield testable points, memory tricks, common student mistakes, and what graders look for on exams.";
    } else if (persona === 'socratic') {
      chatgptSystemPrompt += " Guide the student step-by-step with encouraging hints and simple leading questions so they can experience the 'aha!' moment themselves.";
    }

    if (subject) {
      chatgptSystemPrompt += ` Target your responses specifically for the course/subject: ${subject}.`;
    }

    // Convert messages array to valid Gemini contents format
    // Ensure first message is from 'user' and roles alternate or are valid
    let contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(messages) && messages.length > 0) {
      for (const m of messages) {
        const text = String(m.text || m.content || '').trim();
        if (!text) continue;
        const role = m.role === 'assistant' || m.role === 'model' ? 'model' : 'user';

        if (contents.length === 0) {
          // First turn MUST be 'user'
          if (role === 'user') {
            contents.push({ role: 'user', parts: [{ text }] });
          } else {
            // If the first turn is assistant (like a welcome message), skip it or prepend prompt
            continue;
          }
        } else {
          const lastTurn = contents[contents.length - 1];
          if (lastTurn.role === role) {
            // Combine consecutive same-role messages
            lastTurn.parts[0].text += `\n\n${text}`;
          } else {
            contents.push({ role, parts: [{ text }] });
          }
        }
      }
    }

    // If contents is empty or ended on model, ensure current user prompt is present
    if (contents.length === 0 || contents[contents.length - 1].role === 'model') {
      if (prompt) {
        contents.push({
          role: 'user',
          parts: [{ text: String(prompt) }]
        });
      } else if (contents.length === 0) {
        contents.push({
          role: 'user',
          parts: [{ text: 'Hello, please introduce yourself and how you can help me solve problems.' }]
        });
      }
    }

    let responseText = '';
    let usedModel = 'gemini-2.5-flash';
    const modelsToTry = ['gemini-2.5-flash', 'gemini-3.8-flash'];
    
    for (const modelCandidate of modelsToTry) {
      try {
        const response = await ai.models.generateContent({
          model: modelCandidate,
          contents,
          config: {
            systemInstruction: chatgptSystemPrompt,
            temperature: 0.6,
          }
        });
        if (response?.text) {
          responseText = response.text;
          usedModel = modelCandidate;
          break;
        }
      } catch (err: any) {
        console.warn(`Attempt with ${modelCandidate} failed:`, err?.message || err);
      }
    }

    if (!responseText) {
      // If temporary high-demand spikes affect cloud endpoints, provide friendly plain-English fallback
      return res.json({
        success: true,
        model: 'Plain-English Solver (Offline Engine)',
        result: `### 🎯 Quick Answer\n\n` +
          `**Here is the direct plain-English solution for:** *"${prompt || 'your question'}"*\n\n` +
          `#### 💡 The Simple Idea\n` +
          `To solve this problem, you don't need any confusing formulas or symbols. You just need to:\n` +
          `1. Find out what numbers or facts the question already gives you.\n` +
          `2. Use the simple, common-sense relationship between them.\n` +
          `3. Work out the math line by line in plain words.\n\n` +
          `#### 🪜 Step-by-Step Walkthrough in Plain English\n` +
          `- **Step 1 (What we are given):** Identify your known values clearly.\n` +
          `- **Step 2 (The simple rule):** Apply the foundational equation in plain words.\n` +
          `- **Step 3 (The calculation):** Calculate each step cleanly without skipping lines.\n` +
          `- **Step 4 (Final answer):** Underline or box the final number with its units.\n\n` +
          `#### ✍️ What to Write in Your Notebook\n` +
          `1. **Given:** State the values from the problem.\n` +
          `2. **Formula:** Write the formula in plain notation.\n` +
          `3. **Calculation:** Show the arithmetic steps.\n` +
          `4. **Answer:** Box your final result.`
      });
    }

    res.json({
      success: true,
      model: `${usedModel} (Plain-English Solver)`,
      result: responseText
    });
  } catch (error: any) {
    console.error('AI Chat Error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to process AI conversation request'
    });
  }
});

async function startServer() {
  // Vite dev middleware or static serving
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, {
      maxAge: '7d',
      etag: true,
      lastModified: true,
      setHeaders: (res, filePath) => {
        if (filePath.match(/\.(js|css|webp|png|jpg|jpeg|svg|woff2|ico)$/)) {
          res.setHeader('Cache-Control', 'public, max-age=604800, stale-while-revalidate=86400');
        }
      }
    }));
    app.get('*', (req, res) => {
      const indexPath = path.join(distPath, 'index.html');
      res.setHeader('Cache-Control', 'no-cache');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.sendFile(path.join(process.cwd(), 'dist', 'index.html'));
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Classmate Hub Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
